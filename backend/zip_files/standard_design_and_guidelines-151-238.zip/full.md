## 7.3.9 Design philosophy for fire detection and alarm system

## 7.3.9.1 General

i) One (1) no. PLC panel along with two nos. operator works station – one operating & one engineering shall be provided in fire water pump house to indicate the status of each pump, healthiness of power supplies, etc. Alarms from these panels shall also be available to operator at repeater panel in fire station and at main fire detection and alarm panel in unit control room.

ii) The main fire detection and alarm panel to be located in unit control room shall cover the fire detection and protection system of the complete plant. This shall give audio-visual alarms for fire in each of the risk area / equipment, status of the fire detectors and protection system, etc. In addition, hooter/sounder shall be activated in each of the respective area provided with fire/smoke detection system.

The fire alarm panel shall have separate LCD display to indicate the address of each device and clear text about the location of the alarm/ trouble. It shall record the event within the non-volatile system historical memory. All devices shall be individually identifiable for its type, its zone location, alarm set value, alarm and trouble indication by a unique alpha numerical label.

iii) One (1) fire alarm panel each at coal handling control room, ESP control room, switchyard control room, service building & administrative building shall be provided to exhibit alarms from detection and protection from respective areas

iv) Alarms from all the panels shall be repeated at repeater panel in fire station.

v) Complete fire detection, alarm and monitoring system from the panels shall be operated on DC supply. The panels shall be provided with 2x100% batteries and 2x100% battery chargers with provision for automatic change over from mains to batteries, automatic charging etc.

vi) All control cables/power cables for fire protection, detection and alarm system shall be1100 V grade, 1.5mm<sup>2</sup> core size, stranded tinned copper conductor, PVC insulated, PVC sheathed, GI armoured and overall FRLS PVC sheathed.

vii) The fire alarm system of each unit shall be provided with necessary interface hardware and software for interconnection with DDCMIS for exchange of signals to the unit control room through a serial link.

viii) The control system shall be Programmable Logic Control based. The control system for pumps shall be PLC based, while fire alarm & detection system shall be microprocessor based addressable type.

ix) All types of smoke & heat detectors shall be of addressable type. Conventional smoke and heat detectors with interface modules are not acceptable. Each zone of LHSC (linear heat sensing cable) detector and each IR (infra-red) detector shall be provided with interface module.

## 7.3.9.2 Smoke Detection System

i) The design coverage area for smoke detectors to be considered shall not exceed 25 M<sup>2</sup> for A/C area per each type of detector and 35-40 M<sup>2</sup> per detector for non-A/C areas.

ii) Wherever both the multi-sensor type & photo - electric type smoke detection systems are provided, cross zoning of the signal shall be employed to initiate the fire extinguishing system of that area.

iii) Multisensor type detectors shall be provided for return air ducts of each room which shall consist of intake probe, detector housing, and exhaust pipe etc. The detector shall be mounted outside the duct.

## 7.3.9.3 Detection System for Coal Conveyors

i) The LHS cable detector for each conveyor shall be provided for forward and return conveyors & rollers.

ii) The detection zone/loop divisions of LHSC system shall match with the MVW spray system. Upon detection of fire by LHSC detector, the spray system shall be initiated. It shall also initiate spray system for the two adjacent zones after a time delay settable at site. Wet type Q.B. detectors can also be used in addition to LHS cable.

iii) The LHSC detector may be either Digital or analogue type.

iv) The infra red type (IR) detectors shall be suitable for detecting moving fires in coal conveyors and at least one detector shall be provided for each of the conveyor. IR detectors shall trip the running coal conveyor in case of detection of fire as well as give audio-visual annunciation locally and as well in fire alarm panel.

v) The IR detector shall be outdoor type weather proof and shall be able to function continuously in heavily coal-dust prone atmosphere without regular maintenance.

vi) The IR detector shall be designed to reject deceptive phenomenon such as electric arc, heaters, artificial light sources (HPSV/LPSV/incandescent lamps etc.)

vii) Each of the IR detector shall be provided with purging arrangement.

## 7.3.9.4 Detection system of cable galleries

i) In cable galleries, MVW spray system shall be actuated either by detection of fire by linear heat sensing cable detectors or by fire signal from smoke (after cross zoning) detection system. Apart from the automatic operation of spray system in the detected zone the adjacent two zones shall also be sprayed with water automatically after a set time delay simultaneously. Cable trays in auxiliary pump houses etc. shall be provided with smoke detection system.

ii) LHSC detector shall run in a zig-zag fashion (with an included angle of minimum 90<sup>0</sup> in tray.

iii) The detection zone/loop divisions shall match with MVW spray zones.

## 7.3.10 Design requirement for piping and valves

i) Piping for all fire protection systems shall generally be laid under ground. At cable trench/rail/road crossings, fire water pipes shall be laid inside hume pipes of suitable ratings.

ii) Material of Construction

a. Buried Pipes Mild steel as per IS:1239 (Part-I) heavy grade (upto 150 NB) & as per IS:3589 Gr.410 (above 200 NB)

b. Overground pipes Mild steel as per IS:1239 (Part-I) medium grade (upto 150 NB) & as normally full of per IS:3589 Gr.410 (above 200 NB) water :

c. Over Ground These shall be galvanised as per 4736 medium grade. pipes normally empty but with periodically charge of water &air

iii) To prevent soil corrosion buried pipes shall be properly lagged with corrosion protection as per S: 10221 / IS:15337. Over ground pipes shall be provided with one coat of primer and three coats of Synthetic enamel paint. However, in case of corrosive environment, overground pipes shall be provided with one coat of epoxy resin based zinc phosphate primer followed up with three coats of epoxy resin based paint pigmented with titanium di-oxide.

# STANDARD DESIGN CRITERIA/GUIDELINES FOR BALANCE OF PLANT OF THERMAL POWER PROJECT 2x (500MW OR ABOVE) SECTION-8 : ELECTRICAL AND CONTROL & INSTRUMENTATION SYSTEM

## 8.0 ELECTRICAL AND CONTROL & INSTRUMENTATION SYSTEM :

Electrical and C&I system for Balance of Plant equipment shall meet the following requirements :

## 8.1 Electrical System - Design Criteria :

8.1.1 11kV/ 3.3kV incomers from station switchgears to 11kV/ 3.3kV station auxiliary plant/ system switchgear shall be through adequately rated cables. 3.3kV switchgear shall be fed from transformer either through cable or busduct. For 415V system, busduct shall be used for incoming connection from transformers to the switchgear wherever transformer rating is 1000kVA and above.

8.1.2 Each switchgear/ MCC/ distribution board shall be fed by 2xl00% transformers/ feeders and, these shall be rated to carry the maximum load expected to be imposed. Each of the above boards shall be sectionalized.

8.1.3 Each BOP system shall be provided with two incomers, each from separate switchboard/source so that failure of one supply does not jeopardise the operation of the system.

8.1.4 All equipments viz. switchgears and all auxiliary transformers shall be sized with 10% margin at all ambient from 0<sup>0</sup> to 50<sup>0</sup>C after considering operating load requirements at corresponding ambients.

8.1.5 The voltage ratio, taps, impedances and tolerances of transformers shall be optimised to ensure that the auxiliary system voltages are always within permissible limits under the various grid and loading conditions and the equipment are not subjected to unacceptable voltages during operation and starting of motors viz. BFP etc.

8.1.6 All 11kV, 3.3kV buses shall have facility for auto/ manual live changeover facility. All 415V switchgears fed from transformers shall be provided with live manual changeover. Auto changeover to the reserve supply source shall be arranged for critical 415V switchgears/ MCCs to prevent the loss of unit or to ensure the equipment safety.

8.1.7 11kV, 3.3kV and 415V switchgears, MCC’s and DB’s shall be provided with interlock to ensure that the different supplies and transformers are never operated in parallel and to avoid the fault level to exceed the switchgear capability, except during momentary paralleling in case of on-load changeover.

8.1.8 The motors of rating 110kW and above (except CHP area, where it shall be 160kW) shall be provided with remote controlled electrical circuit breakers. Other motors shall be provided with switch-fuse contactor feeders.

8.1.9 A typical single line diagram (Drg. no. CEA-TETD-EL-01) of the power supply arrangement is enclosed.

8.2 Electrical System - General Technical Requirements :

## 8.2.1 Transformers :

8.2.1.1 The transformers shall be provided with delta-connected primary and a star–connected secondary with the star point brought out and resistance earthed for 3.3kV system and solidly earthed for 415V system.

8.2.1.2 The transformers shall have following technical parameters :

<table><tr><td>a) b)</td><td>Type Service</td><td>Two winding Outdoor (oil filled) /</td></tr><tr><td></td><td></td><td>Indoor (dry type : epoxy cast resin/ resin encapsulated type)(1)</td></tr><tr><td>c)</td><td>Number of phases</td><td>Three</td></tr><tr><td>d) e)</td><td>Frequency</td><td>50 Hz ONAN for oil filled/ AN for dry type</td></tr><tr><td></td><td>Type of cooling</td><td></td></tr><tr><td>f)</td><td>Ratings</td><td>As per system requirement.</td></tr><tr><td>g) h)</td><td>Impedance Duty</td><td>As per system requirement. Continuous</td></tr><tr><td>i)</td><td>Over load</td><td>As per IS:6600</td></tr><tr><td>j)</td><td>System fault level(2)</td><td></td></tr><tr><td></td><td>11 kV</td><td>40 kA for 1 second</td></tr><tr><td></td><td>3.3 kV</td><td>40 kA for 1 second</td></tr><tr><td></td><td>415V</td><td>50 kA for 1 second</td></tr><tr><td></td><td></td><td></td></tr></table>

<table><tr><td>k) Windings Insulation</td><td>11 kV</td><td>3.3 kV</td><td>433V</td></tr><tr><td>- Power frequency test level</td><td></td><td>-----Uniform----</td><td></td></tr><tr><td>(kV rms)</td><td>28</td><td>10</td><td>3</td></tr><tr><td>- Basic impulse level (kV peak)</td><td>75</td><td>40</td><td></td></tr><tr><td>- Highest voltage for each winding (kV)</td><td>12</td><td>3.6</td><td>1.1</td></tr></table>

a) 415V : solidly grounded, b) 11kV, 3.3kV: earthed through resistance to limit the current to 300A or high resistance grounding through artificial earthing transformer and earthing resistance.

<table><tr><td rowspan="2">m)</td><td rowspan="2">Tap changer</td><td colspan="3">Off circuit tap changer with ±5% in steps</td></tr><tr><td colspan="3">of 2.5 % on HV side</td></tr><tr><td rowspan="6">n)</td><td>Bushing</td><td>11 kV</td><td>3.3 kV</td><td>0.433 kV</td></tr><tr><td>- Rated voltage(kV)</td><td>12</td><td>3.6</td><td>1.1</td></tr><tr><td>- Basic Impulse level (kVp) -Wet, dry power withstand</td><td>75</td><td>40</td><td></td></tr><tr><td>voltage (kV)</td><td>28</td><td>10</td><td>3</td></tr><tr><td>- Min. creepage distance (mm)</td><td>300</td><td>90</td><td>25</td></tr><tr><td>- Mounting (mm) Terminal details</td><td>Tank / Transformer body</td><td></td><td></td></tr><tr><td rowspan="4">0)</td><td>-High Voltage(3.3 &amp;11 kV)</td><td>Cable</td><td></td><td></td></tr><tr><td>- 433V phase and neutral</td><td>Busduct/ Cable box</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td></tr><tr><td>shall be provided.</td><td></td><td>However, non-segregated busduct for transformers rated 1000kVA and above</td><td></td></tr></table>

Note :

<sup>(1)</sup> Indoor (dry type) shall be preferred

<sup>(2)</sup> For units of rating above 500MW, higher fault level, if required, may be considered

## 8.2.1.3 Temperature rise over an ambient of $5 0 ^ { \circ } \mathrm { C }$

a) Out-door transformers :

In top oil (measured by thermometer) $5 0 ^ { \circ } \mathrm { C }$

In winding (measured by resistance) $5 5 ^ { \mathrm { { 0 } } } \mathrm { { C } }$

b) In-door transformers :

In winding (by resistance method) 90<sup>0</sup>C or lower as permissible for class of insulation offered

## 8.2.1.4 Class of insulation

F or better (for dry type transformers)

B or better (for oil filled transformers)

## 8.2.1.5 Noise level at rated voltage and frequency

As per NEMA Pub TR-1

## 8.2.1.6 Neutral Grounding Resistor :

a) Resistance (ohm) As per requirements

b) Rated current and duration 300A for 10 seconds

c) Application Grounding of 11kV and 3.3 kV system

d) Service Outdoor

e) Resistor materials Punched stainless steel grid element

f) Max. allowable temp. rise

350<sup>0</sup>C

g) Mounting 12kV grade insulator (for 11kV)/

3.6kV grade insulator (for3.3 kV)

h) Enclosure degree of protection IP-33 as per IEC/ IS-60947

Terminal bushing Rated voltage 12kV grade insulator (for 11kV)/ 3.6kV

<table><tr><td colspan="2"></td><td>grade insulator (for3.3 kV)</td></tr><tr><td rowspan="7">j)</td><td>Rated current</td><td>300 A</td></tr><tr><td>Basic Impulse level</td><td>75kVp (for 11kV)/ 20kVp (for 3.3kV)</td></tr><tr><td>Quantity</td><td>Two each</td></tr><tr><td>Mounting</td><td>Roof of enclosure</td></tr><tr><td>Terminal details :</td><td></td></tr><tr><td>- To transformer neutral</td><td>Copper flat of minimum 50mm x 6 mm</td></tr><tr><td>- To earth</td><td>Through GS flat of size 50mm x 10mm</td></tr></table>

## 8.2.1.7 Codes and Standards :

<table><tr><td>IS:2026(Part I to IV)</td><td>Power transformers</td></tr><tr><td>IS:6600/BS:CP:1010</td><td>Guide for loading of oil immersed transformers</td></tr><tr><td>IS:335</td><td>New insulating oil for transformers and switchgears</td></tr><tr><td>IS:3639</td><td>Fittings and accessories for power transformers</td></tr><tr><td>IS:2099</td><td>High voltage porcelain bushings</td></tr><tr><td>IS:2705</td><td>Current transformers</td></tr><tr><td>IS:3347</td><td>Dimensions for porcelain transformer bushings</td></tr><tr><td>IS:13947</td><td>Degree of protection</td></tr><tr><td>IS:2071</td><td>Method of high voltage testing</td></tr><tr><td>IS:3637</td><td>Gas operated relays</td></tr><tr><td>IS:1271</td><td>Classification of insulating materials for electrical machinery and apparatus in relation to their stability in service</td></tr><tr><td>IS:5</td><td>Colours for ready mixed points</td></tr><tr><td>IS:10028 Part I, II, III</td><td>Code of practice for selection, installation and maintenance of</td></tr><tr><td>IS:5561</td><td>transformers.</td></tr><tr><td></td><td>Electric power connectors</td></tr><tr><td>CBIP publication 295</td><td>Manual on transformers</td></tr></table>

## 8.2.2 11kV and 3.3kV Busducts :

8.2.2.1 The technical parameters of 11kV and 3.3kV bus ducts are given below :

<table><tr><td></td><td></td><td>11kV</td><td>3.3 kV</td></tr><tr><td>a)</td><td>Number of phase</td><td>3</td><td>3</td></tr><tr><td>b)</td><td>Frequency</td><td>50 Hz</td><td>50 Hz</td></tr><tr><td>c)</td><td>Nominal voltage</td><td>11kV</td><td>3.3 kV</td></tr><tr><td>d)</td><td>Highest system voltage</td><td>12 kV</td><td>3.6 kV</td></tr><tr><td>e)</td><td>One minute power frequency withstand</td><td>28 kV</td><td>10 kV</td></tr><tr><td>f)</td><td>voltage (dry and wet) Impulse voltage withstand value with 1.2/50 micro-sec wave shape</td><td>75 kV</td><td>40 kV</td></tr><tr><td>g)</td><td>Continuous current rating</td><td>as required</td><td>as required</td></tr><tr><td>h)</td><td>Short time current rating for 1 second(1)</td><td>40kA</td><td>40kA</td></tr><tr><td>i)</td><td>Dynamic current withstand rating (1)</td><td>100 kA(peak)</td><td>100kA(peak)</td></tr><tr><td>j)</td><td>Type of cooling</td><td>Natural</td><td>Natural</td></tr><tr><td>k)</td><td>Type of bus enclosure</td><td>Phase segregated</td><td>Phase segregated</td></tr></table>

Section- 8 (Electrical and Control & Instrumentation System)
<table><tr><td>1)</td><td>Service</td><td>Indoor/ Outdoor</td><td>Indoor/ Outdoor</td></tr><tr><td>n)</td><td>Clearance of live parts in air</td><td>As per IS</td><td>As per IS</td></tr><tr><td></td><td>Phase to phase -</td><td>---do---</td><td>---do--</td></tr><tr><td></td><td>- Phase to earth</td><td>---do---</td><td>---do--</td></tr><tr><td>0)</td><td>Busbar material</td><td>Aluminum alloy</td><td>Aluminum alloy</td></tr><tr><td>p)</td><td>Enclosure and partition material</td><td>Aluminum alloy</td><td>Aluminum alloy</td></tr><tr><td>q)</td><td>Minimum thickness of enclosure</td><td>3 mm</td><td>3 mm</td></tr><tr><td>r)</td><td>Minimum thickness of partition</td><td>2 mm</td><td>2 mm</td></tr><tr><td>s)</td><td>Insulators and bushings - Rated voltage</td><td>12 kV</td><td>3.6 kV</td></tr><tr><td></td><td>- One minute power frequency withstand voltage</td><td></td><td></td></tr><tr><td></td><td>- Dry</td><td>35 kV</td><td>20 kV</td></tr><tr><td></td><td>- Wet</td><td>35 kV</td><td>20 kV</td></tr><tr><td></td><td>Impulse voltage withstand value with -</td><td>75 kV</td><td>40 kV</td></tr><tr><td></td><td>1.2/50 micro sec. wave shape. - Minimum creepage distance</td><td></td><td></td></tr><tr><td></td><td>- Material of insulator</td><td>240 mm Porcelain/ Epoxy</td><td>130 mm Porcelain/ Epoxy</td></tr><tr><td>t)</td><td>Size of earthing conductor</td><td>65mmx8mm</td><td>65mmx6mm</td></tr><tr><td></td><td>(mild steel)</td><td>galvanized</td><td>galvanized</td></tr><tr><td>u) v)</td><td>Design ambient temperature.</td><td>50℃</td><td>50℃</td></tr><tr><td></td><td>Maximum temperature when carrying</td><td></td><td></td></tr><tr><td></td><td>rated current continuously - Bus conductor:</td><td></td><td></td></tr><tr><td></td><td>Bolted joints (Plain or tinned)</td><td>90℃</td><td>90℃</td></tr><tr><td></td><td></td><td>105℃</td><td>105℃</td></tr><tr><td></td><td>Bolted joints (silver plated)</td><td></td><td></td></tr><tr><td>Note :</td><td>- Bus duct enclosure</td><td>80℃</td><td>80℃</td></tr></table>

<sup>(1)</sup> For units of rating above 500MW, higher fault level, if required, may be considered

8.2.2.2 The bus ducts will be installed partially indoor and partially outdoor and shall be suitable for hot, humid and tropical atmosphere.

8.2.2.3 The maximum temperature of the bus conductor and enclosure shall be as mentioned above when operating at maximum ambient temperature and carrying rated current continuously. For outdoor portions, the effect of solar radiation shall also be considered.

## 8.2.2.4 Codes and Stadards :

<table><tr><td>IS:226</td><td>Structural steel (Standard quality)</td></tr><tr><td>IS:737</td><td>Specification for wrought aluminum and aluminum alloys, sheet and strip (for engineering purpose).</td></tr><tr><td>IS:800</td><td>Code of practice for use of structural steel in general building construction.</td></tr><tr><td>IS:1367 Part-13</td><td>Hot dip galvanised coatings on threaded fasteners.</td></tr><tr><td>IS:2099</td><td>Bushing for A.C. voltage above 1000 volts.</td></tr><tr><td>IS:13947 Part-1</td><td>Low voltage switchgear and controlgear</td></tr><tr><td>IS:2544</td><td>Porcelain post Insulators for system with normal voltage greater</td></tr><tr><td></td><td>than 1000 volts.</td></tr><tr><td>IS:2633</td><td>Methods of testing uniformity of coating on zinc coated articles</td></tr><tr><td>IS:4759</td><td>Hoot dip zinc coating on structural steel and allied products.</td></tr><tr><td>IS:5082</td><td>Specification for wrought Aluminum alloys bars, rods, tubes and sections for electrical purposes.</td></tr><tr><td>IS:8084</td><td>Interconnecting bus bars for A.C. voltage above 1KV upto and including 36KV.</td></tr><tr><td>ANSI C-37:23</td><td>Metal enclosed bus.</td></tr><tr><td>ANSI C-37:24</td><td>Effect of Solar radiation on metal enclosed bus.</td></tr></table>

## 8.2.3 Motors :

8.2.3.1 All the motors shall be suitable for an ambient temperature of 50<sup>0</sup>C and relative humidity of 95%. The motors shall be suitable for operation in a highly polluted environment.

## 8.2.3.2 Voltage and Frequency variations :

Frequency (+) 3% and (-)5% Voltage a. (±) 6% for 11kV/ 3.3 kV b. (±) 10% for 415 V Combined 10% (absolute sum)

8.2.3.3 Voltage level :

<table><tr><td>1)</td><td>Upto 200 KW</td><td>415V</td></tr><tr><td>2) 3)</td><td>&gt; 200kW &amp; upto 1500kW &gt; 1500 kW</td><td>3.3 kV 11 kV</td></tr></table>

Note : For far-off areas viz. CHP and AHP etc. motors upto 160kW only shall be rated at 415V level to restrict the voltage drop within permissible limit of 2.5%.

8.2.3.4 The motor terminal box shall be suitable for with-standing the maximum system fault current for a duration of at least 0.25 second.

## 8.2.3.5 System grounding

1) 11 kV and 3.3 kV Earthed through resistance to limit the current to 300A or high resistance grounding through artificial earthing transformer and earthing resistance   
2) 415V Solidly grounded   
3) 220V DC Ungrounded

## 8.2.3.6 Degree of protection :

1) Indoor motors IP 54   
2) Outdoor motors IP 55   
3) Cable box – indoor area IP 54   
4) Cable box – outdoor area IP 55

## 8.2.3.7 Type :

a) AC Motors:

\- Squirrel cage induction motor suitable for direct-on-line starting.

\- Crane duty motors shall be slip ring type induction motor

b) DC Motors: Shunt wound.

## 8.2.3.8 Rating

a) Continuously rated (S1). However, crane motors shall be rated for S4 duty i.e. 40% cyclic duration factor.

b) Maximum continuous motor ratings shall be at least 10% above the maximum load demand of the driven equipment unless otherwise specified, under entire operating range including voltage and frequency variations.

c) Motors starting shall be as per IS:325/ IEC-60034 (part 12)

## 8.2.3.9 Temperature Rise

Air cooled motors

70<sup>0</sup>C by resistance method for both class 130(B) and   
155(F) insulation.

Water cooled motors

80<sup>0</sup>C over inlet cooling water temperature, by resistance method for both class 130(B) and 155(F) insulation.

## 8.2.3.10 a) Starting voltage requirement

All motors (except mill motors) :

85% of rated voltage for motors upto 1000 kW

80% of rated voltage for motors above 1000kW and upto 4000 kW

75% of rated voltage for motors above 4000 kW

For mill motors :

85% of rated voltage for motors above 1000 kW

90% of rated voltage for motors upto 1000 kW

b) Breakway starting current :

All motors (except BFP) : six (6) times the rated full load current

## 8.2.3.11 The motor shall be capable of withstanding the electro dynamic stress and heating imposed if it is started alongwith the driven equipment at voltage of 110% of the rated value.

8.2.3.12 All motors shall be either totally enclosed fan cooled (TEFC) or totally enclosed tube ventilated (TETV) or closed air circuit air cooled (CACA) type. However, motors rated 3000 kW or above can be closed air circuit water cooled (CACW).

8.2.3.13 For hazardous location such as fuel oil facilities area, the enclosure of motors shall have flame proof construction conforming to Group – IIB of IS:2148.

## 8.2.3.14 Winding and Insulation :

1) Type Non-hygroscopic, oil resistant, flame resistant

2) Starting duty Two hot starts ( 3 starts for conveyor motors) in succession, with motor initially at normal running temperature

3) 11kV, 3.3 kV AC motors Class 155(F) : with winding temperature rise limited to class 130(B). They shall withstand 1.2/50microsec. Impulse Voltage wave of 4U+5 kV (U=Line voltage in kV). The coil inter-turn insulation shall be as per IEC-60034-Part 15 followed by 1 min power frequency high voltage test of appropriate voltage on inter turn insulation. The insulation shall be Vacuum Impregnated (VIP) type.

4) 415V AC and 220V DC Class 130 (B) motors

## 8.2.3.15 Energy Conservation :

a. Motors of energy efficient design shall be preferred subject to application and technoeconomic considerations and mutual agreement between the supplier and purchaser.

b. For conservation of energy during part load operation in respect of large capacity auxiliary motors, variable frequency drive (thyristor control) may be employed.

8.2.3.16 Noise level and vibration shall be limited within the limits prescribed in IS:12065 and IS: 12075 respectively.

8.2.3.17 Motors rated above 1000kW shall have suitable measures to prevent flow of shaft currents.

8.2.3.18 Motors above 1000kW rating shall have 2 sets (i.e. 6 nos.) of PS class CTs for differential protection.

## 8.2.3.19 Codes and Standards :

IS:325, IEC:60034

Three phase induction motors

IS:996, IEC:60034

Single phase AC motors

IS:3177, IEC600:34

Crane duty motors

IS:4722

DC motors

IS-12615

Energy efficient motors

## 8.2.4 11kV and 3.3kV Switchgears<sup>1</sup> :

8.2.4.1 The switchgears shall be indoor, metal clad, draw out type. The motor feeders above 2000kW rating shall have vacuum/ $\mathrm { S F } _ { 6 }$ breakers. The motor feeders below 2000kW rating shall have either vacuum/ $\mathrm { S F } _ { 6 }$ breakers or vacuum/ SF6 contactors backed up by HRC fuses. However, in an application, where frequent start/ stop operations are required, vacuum contactors/ breakers shall be preferred. The operating mechanism of the circuit breakers shall be of the stored energy type DC motor operated charging springs.

8.2.4.2 10% spare feeders with at least one of each type of highest rating shall be provided in each switchgear.

8.2.4.3 The circuit breaker, contactor and switchgear assembly shall have the following technical parameters :

<table><tr><td colspan="1" rowspan="1">a)</td><td colspan="4" rowspan="1">System parameters</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">1)</td><td colspan="1" rowspan="1">Nominal System voltage</td><td colspan="1" rowspan="1">11 kV</td><td colspan="1" rowspan="1">3.3 kV</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">2)</td><td colspan="1" rowspan="1">Highest System voltage</td><td colspan="1" rowspan="1">12 kV</td><td colspan="1" rowspan="1">3.6 kV</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">3)</td><td colspan="1" rowspan="1">Rated Frequency</td><td colspan="1" rowspan="1">50 Hz</td><td colspan="1" rowspan="1">50 Hz</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">4)</td><td colspan="1" rowspan="1">Number of phases</td><td colspan="1" rowspan="1">Three</td><td colspan="1" rowspan="1">Three</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">5)</td><td colspan="1" rowspan="1">System neutral earthing</td><td colspan="2" rowspan="1">Earthed through resistance to limit faultcurrent to 300AorHigh resistance grounding throughartificial1 earthing  transformer  andearthing resistor</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">6)</td><td colspan="1" rowspan="1">One minute power frequencywithstand voltage</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">- for Type tests</td><td colspan="1" rowspan="1">28</td><td colspan="1" rowspan="1">10</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">- for Routine tests</td><td colspan="1" rowspan="1">28</td><td colspan="1" rowspan="1">10</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">7)</td><td colspan="1" rowspan="1">1.2/50   microsecond   Impulsewithstand voltage</td><td colspan="1" rowspan="1">75 kV (peak)</td><td colspan="1" rowspan="1">40 kV(peak)</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">8)</td><td colspan="1" rowspan="1">Maximum systemfault levelincluding      initial       motorcontribution</td><td colspan="1" rowspan="1">40 kA for1 second</td><td colspan="1" rowspan="1">40 kA for1 second</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">9)</td><td colspan="1" rowspan="1">Dynamic withstand rating</td><td colspan="1" rowspan="1">100 kA (peak)</td><td colspan="1" rowspan="1">100 kA (peak)</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">10)</td><td colspan="1" rowspan="1">Control supply voltage</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">- Trip and closing coils</td><td colspan="2" rowspan="1">220V DC</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">- Spring charging motor</td><td colspan="2" rowspan="1">-220V DC(240V AC can be accepted for off-siteareas)</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">Space heaters</td><td colspan="2" rowspan="1">240V AC</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">11)</td><td colspan="1" rowspan="1">Ambient temperature</td><td colspan="2" rowspan="1">50℃</td></tr><tr><td colspan="1" rowspan="1">b)</td><td colspan="4" rowspan="1">Busbars</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">1)</td><td colspan="1" rowspan="1">Continuous current rating at 50°℃ambient</td><td colspan="2" rowspan="1">as per system requirements</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">2)</td><td colspan="1" rowspan="1">Temperature rise</td><td colspan="2" rowspan="1">- 40ºC for plain joints- 65C for silver plated joints</td></tr><tr><td colspan="1" rowspan="1">c)</td><td colspan="4" rowspan="1">Constructional requirements</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">1)</td><td colspan="1" rowspan="1">Cable entry</td><td colspan="2" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">- Power cables</td><td colspan="2" rowspan="1">Bottom</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">Control cables</td><td colspan="2" rowspan="1">Bottom</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">2)</td><td colspan="1" rowspan="1">Bus duct entry</td><td colspan="2" rowspan="1">Top--</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">3)</td><td colspan="1" rowspan="1">Earthing conductor</td><td colspan="2" rowspan="1">Galvanised steel strip</td></tr><tr><td colspan="1" rowspan="1">d)</td><td colspan="4" rowspan="1">Circuit breakers</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">1)</td><td colspan="1" rowspan="1">Short circuit breaking current</td><td colspan="2" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">AC component</td><td colspan="2" rowspan="1">40 kA</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">DC component</td><td colspan="2" rowspan="1">As per IS 13118 or IEC 62271</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">2)</td><td colspan="1" rowspan="1">Short circuit making current</td><td colspan="2" rowspan="1">100 kA (peak)</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">3)</td><td colspan="1" rowspan="1">Operating Duty</td><td colspan="2" rowspan="1">B − 3min − MB − 3min − MB</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">4)</td><td colspan="1" rowspan="1">Total break time</td><td colspan="2" rowspan="1">Not more than 4 cycles</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">5)</td><td colspan="1" rowspan="1">Total make time</td><td colspan="2" rowspan="1">Not more than 5 cycles</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">6)</td><td colspan="1" rowspan="1">Operating Mechanism</td><td colspan="2" rowspan="1">Motor wound spring charged  storedenergy type as per IEC 62271</td></tr><tr><td colspan="1" rowspan="1">e)</td><td colspan="4" rowspan="1">Relays</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">"One minute power frequency</td><td colspan="1" rowspan="1">2.0 kV (rms)</td><td colspan="1" rowspan="1">2.0 kV (rms)</td></tr><tr><td colspan="1" rowspan="1">f)</td><td colspan="4" rowspan="1">Meters</td></tr></table>

<table><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">1)</td><td colspan="2" rowspan="1">Accuracy class forEnergy accounting and audit meters- on each incoming feeder of 11kV/3.3kV buses-on all 11kV and 3.3kV motor feeder- other metersAll meters shall also meet CEAregulations on MeteringIn case, numerical relays having built-infeatures of energy measurement ofrequisite accuracy are provided inswitchgear, separate energy meter is notnecessary.</td><td colspan="2" rowspan="1">Not inferior to 1.0S----do---1.0</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">2)</td><td colspan="2" rowspan="1">One minute power frequency</td><td colspan="2" rowspan="1">2.0 kV (rms)</td></tr><tr><td colspan="1" rowspan="1">g)</td><td colspan="5" rowspan="1">Current Transformer</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">1)</td><td colspan="2" rowspan="1">Class of Insulation</td><td colspan="2" rowspan="1">Class E or better</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">2)</td><td colspan="2" rowspan="1">Rated output of each</td><td colspan="2" rowspan="1">Adequate for the relays anddevices connected, but not lessthan five (5) VA.</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">3)</td><td colspan="2" rowspan="1">Accuracy class</td><td colspan="2" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="2" rowspan="1">Measurement    core   for   energyaccounting and audit meterson each incoming feeder of 11kV/3.3kV buses-on all 11kV and 3.3kV motor feeder- other metersAll CT's shall also meet  CEAregulations on Metering</td><td colspan="2" rowspan="1">Not inferior to 1.0S----do---1.0</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="2" rowspan="1">Protection core- differential and core balance CTsother protection CTs</td><td colspan="2" rowspan="1">PS5P20</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">4)</td><td colspan="2" rowspan="1">Minimum primary earth fault current tobe detected by core balance CT</td><td colspan="2" rowspan="1">3A</td></tr><tr><td colspan="1" rowspan="1">h)</td><td colspan="5" rowspan="1">Voltage Transformers</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">1)</td><td colspan="1" rowspan="1">Rated voltage factor</td><td colspan="3" rowspan="1">1.2 continuous for all VTs, and 1.9 for30 sec. for star connected VTs</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">2)</td><td colspan="1" rowspan="1">Measurement- for energy accounting and audit- for othersAll VT's shall also meet CEAregulations on Metering</td><td colspan="3" rowspan="1">Not inferior to 1.0S1.0</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">3)</td><td colspan="1" rowspan="1">Protection</td><td colspan="3" rowspan="1">3P</td></tr><tr><td colspan="1" rowspan="1">i)</td><td colspan="5" rowspan="1">Fuses</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">Voltage class</td><td colspan="2" rowspan="1">11kV</td><td colspan="1" rowspan="1">3.3kV</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="2" rowspan="1">Rupturing Capacity</td><td colspan="2" rowspan="1">Adequate for 100 kA (peak)</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="2" rowspan="1">Rated current</td><td colspan="2" rowspan="1">As per application</td></tr><tr><td colspan="1" rowspan="1">j)</td><td colspan="5" rowspan="1">Surge arresters</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="2" rowspan="1"></td><td colspan="1" rowspan="1">11 kV</td><td colspan="1" rowspan="1">3.3kV</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">1)</td><td colspan="2" rowspan="1">Nominal discharge current (8x20micro second)</td><td colspan="1" rowspan="1">5kA</td><td colspan="1" rowspan="1">5kA</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">2)</td><td colspan="2" rowspan="1">Maximum system voltage</td><td colspan="1" rowspan="1">12 kV</td><td colspan="1" rowspan="1">3.6kV</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">3)</td><td colspan="2" rowspan="1">Max. standard impulse spark overvoltage (peak) (without anypositive tolerance)</td><td colspan="1" rowspan="1">25kV</td><td colspan="1" rowspan="1">10 kV</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">4)</td><td colspan="2" rowspan="1">Residual voltage at nominaldischarge current</td><td colspan="1" rowspan="1">25 kV</td><td colspan="1" rowspan="1">8kV</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">5)</td><td colspan="2" rowspan="1">Temporary     over     voltagecapability (rms)</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="2" rowspan="1">Continuous</td><td colspan="1" rowspan="1">12 kV</td><td colspan="1" rowspan="1">3.6kV</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="2" rowspan="1">For 10 seconds</td><td colspan="1" rowspan="1">9.9kV</td><td colspan="1" rowspan="1">3.3kV</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">6)</td><td colspan="2" rowspan="1">Installation</td><td colspan="2" rowspan="1">Inside the switchgear panel</td></tr><tr><td colspan="1" rowspan="1">k)</td><td colspan="5" rowspan="1">Contactors</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">1)</td><td colspan="2" rowspan="1">Nominal system voltage</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">3.3kV</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">2)</td><td colspan="2" rowspan="1">Highest system voltage</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">3.6kV</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">3)</td><td colspan="2" rowspan="1">Rated frequency</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">50Hz</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">4)</td><td colspan="2" rowspan="1">Control supply voltage</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">220 V DC</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">5)</td><td colspan="2" rowspan="1">Utilization category</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">AC-3</td></tr><tr><td colspan="1" rowspan="1">1)</td><td colspan="5" rowspan="1">Transducers</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">1)</td><td colspan="4" rowspan="1">Current transducers</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">a)</td><td colspan="1" rowspan="1">Input</td><td colspan="2" rowspan="1">0-1 A (CT secondary)</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">b)</td><td colspan="1" rowspan="1">Rated frequency</td><td colspan="2" rowspan="1">50 Hz</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">c)</td><td colspan="1" rowspan="1">Output</td><td colspan="2" rowspan="1">4-20 mA (2 Nos. decoupled)</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">d)</td><td colspan="1" rowspan="1">Accuracy</td><td colspan="2" rowspan="1">0.5%</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">2)</td><td colspan="4" rowspan="1">Voltage transducers</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">a)</td><td colspan="1" rowspan="1">Input</td><td colspan="2" rowspan="1">110V, 50 Hz (from VT secondary)</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">b)</td><td colspan="1" rowspan="1">Output</td><td colspan="2" rowspan="1">4-20 mA (2 Nos. de-coupled)</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">c)</td><td colspan="1" rowspan="1">Accuracy</td><td colspan="2" rowspan="1">0.5%</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">3)</td><td colspan="4" rowspan="1">VAR transducers</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">a)</td><td colspan="1" rowspan="1">Input</td><td colspan="2" rowspan="1">3 phase, 3-wire 1 A (CT secondary)110 V (VT secondary)</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">b)</td><td colspan="1" rowspan="1">Rated frequency</td><td colspan="2" rowspan="1">50 Hz</td></tr></table>

Section- 8 (Electrical and Control & Instrumentation System)
<table><tr><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>c)</td><td rowspan=1 colspan=1>Output</td><td rowspan=1 colspan=1>4-20 mA (2 nos. de-coupled)</td></tr><tr><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>d)</td><td rowspan=1 colspan=1>Accuracy</td><td rowspan=1 colspan=1>0.5%</td></tr><tr><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>4)</td><td rowspan=1 colspan=3>Watt transducers</td></tr><tr><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>a)</td><td rowspan=1 colspan=1>Input</td><td rowspan=1 colspan=1>3 phase, 3-wire 1A (CT secondary)110V (VT secondary)</td></tr><tr><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>b)</td><td rowspan=1 colspan=1>Rated frequency</td><td rowspan=1 colspan=1>50 Hz</td></tr><tr><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>c)</td><td rowspan=1 colspan=1>Output</td><td rowspan=1 colspan=1>4-20 mA (2 nos. decoupled)</td></tr><tr><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>d)</td><td rowspan=1 colspan=1>Accuracy</td><td rowspan=1 colspan=1>0.5%</td></tr><tr><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>5)</td><td rowspan=1 colspan=3>Frequency transducers</td></tr><tr><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>a)</td><td rowspan=1 colspan=1>Input</td><td rowspan=1 colspan=1>110V (VT secondary)</td></tr><tr><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>b)</td><td rowspan=1 colspan=1>Rated frequency</td><td rowspan=1 colspan=1>50 Hz</td></tr><tr><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>c)</td><td rowspan=1 colspan=1>Range</td><td rowspan=1 colspan=1>45 to 55 Hz</td></tr><tr><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>d)</td><td rowspan=1 colspan=1>Output</td><td rowspan=1 colspan=1>4-20 mA (2 nos. decoupled)</td></tr><tr><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>e)</td><td rowspan=1 colspan=1>Accuracy</td><td rowspan=1 colspan=1>0.5%</td></tr><tr><td rowspan=1 colspan=5>Note :(1)For units of rating above 500MW, higher fault level, if required, may be considered</td></tr></table>

## 8.2.4.4 Protection :

a) Incomer, bus-coupler and outgoing feeders except motor and transformer feeders

Time graded over-current protection

Under voltage protection for bus to trip motors under sustained under voltage conditions

Earth fault relays shall be provided for selective tripping of feeders

## b) Outgoing 11kV/3.3kV, 11kV/433V auxiliary service transformers feeders

Inverse/ Definite time over-current protection (with instantaneous element)

Buchholz protection (for oil filled transformers)

Zero sequence/ earth fault current protection for transformer feeder protection

Winding temperature high (alarm and trip)

Oil temperature high (alarm and trip) (for oil filled transformers)

Zero sequence protection on LV side (neutral CT to be provided in case of solid grounding)

Differential current protection (for 5MVA and above)

Restricted earth fault protection for LV side (if applicable for 1MVA and above)

c) Outgoing 11kV, 3.3kV motor feeders :

Instantaneous short- circuit protection

Over-load protection with unbalance current feature

Differential protection (for motors above 1000KW)

Locked rotor protection, if not covered by the overload protection

Zero sequence current protection

Winding/ bearing temperature protection by means of RTDs connecting the same to DDCMIS.

## 8.2.4.5 Surge arrestor :

The surge arrestors shall be provided for all motor/ transformer feeders and shall be metal oxide, gapped or gap less type generally in accordance with IEC 60099-1 and suitable for indoor duty. These shall be mounted within the switchgear cubicle between line and earth, preferably in the cable compartment. Surge arrestor selected shall be suitable for non-effectively earthed system and rating shall be in such a way that the value of steep fronted switching over voltage generated at the switchgear terminals shall be limited to the requirements of switchgear.

## 8.2.4.6 Metering :

The energy meters shall be provided as per the Central Electricity Authority (Installation and Operation of Meters) Regulations,2006 and its amendments. However, the energy accounting and audit meters shall be provided in general :

\- on each incoming feeder of 11kV and 3.3kV buses.

\- on all 11kV and 3.3kV motor feeders.

Energy accounting and audit meters shall be of accuracy class of 1.0S. The accuracy class of CTs and VTs shall not be inferior to that of associated meters. In case, numerical relays having built-in features of energy measurement of requisite accuracy are provided in switchgear, separate energy meter is not necessary.

## 8.2.4.7 Relays and meters :

a) The protective relays shall be static or numerical type. However, numerical type shall be preferred. All relays, auxiliary relays and devices shall be of reputed make and types proven for the application and shall be subject to purchaser approval. The relays and timers shall have appropriate setting ranges, accuracy, resetting ratio, transient over-reach and other characteristics to provide required sensitivity to the satisfaction of the owner.

b) Relays shall be suitable for efficient and reliable operation of the protection scheme. Necessary auxiliary relays, timers, trip relays, etc. required for complete scheme, interlocking, alarm, logging, etc. shall be provided. Control relay shall not trip the circuit breaker when relay is de-energized.

c) Relays shall be flush mounted on the front with connections at the rear shall be draw-out or plug-in type/ modular case with proper testing facilities. Provision shall be made for easy isolation of trip circuits for testing and maintenance.

d) Auxiliary relays shall be provided in the trip circuits of protections located outside the board, such as buchholz relay, temperature indicators, fire protection, etc. Alternatively, binary signals from protections located outside the board may be taken directly to the numerical protection relays provided in the board without providing auxiliary relays

e) The closing coils and other auxiliary devices shall operate satisfactorily at all voltages between 85-110% of the rated control voltage and trip coils between 70- 110% of rated control voltage.

f) Control circuits shall operate at suitable voltage of 110V AC or 220V DC. Necessary control supply transformers having primary and secondary fuses shall be provided for each MCC, 2x100% per section. However the breakers shall operate on 220V DC. The auxiliary bus bars for control supply shall be segregated from main bus bars. The control supplies shall be monitored.

g) Contractor shall fully co-ordinate overload and short circuit tripping of breaker with upstream and down stream breakers/ fuses/ MCCBs motor starters. Various equipments shall meet requirement of Type-II class of coordination as per IEC.

h) In case of remote controlled breaker panels, following shall be provided.

Each feeder shall have local/ remote selector switch. Closing from local shall be possible only in test position whereas closing from remote shall be possible in either service or test position. Tripping from local shall be possible only when local/ remote selector switch is in local position. Tripping from remote shall be possible when breaker is in service position or selector switch is in remote position.

i) Suitable self powered transducers as per IS : 12784 Part – I (if required) for feeding signals to panel mounted electrical meters (ammeters, voltmeters, VAR meters and watt meters etc.) and DCCMIS shall be provided. Alternatively, analog signals from numerical relays shall be directly used.

j) The motor feeders for essential auxiliaries shall have contactors with delayed drop-out feature adjustable up to three seconds.

## 8.2.4.8 Codes and Standards :

IS : 722 AC electricity meters

IS : 996 Single phase small AC and universal electrical motors.

IS : 1248 Direct Acting indicating analogue electrical measuring instruments and Accessories

IS : 13947 Degree of protection provided by enclosures for low voltage switchgear

<table><tr><td>IS : 2544</td><td>and control gear Porcelain post insulators for systems with nominal voltages greater than 1000V</td></tr><tr><td>IS : 2705</td><td>Current transformers.</td></tr><tr><td>IS : 3156</td><td>Voltage Transformers</td></tr><tr><td>IS : 3231</td><td>Electrical relays for power system protection</td></tr><tr><td>IS : 3427</td><td>Metal enclosed switchgear and control gear</td></tr><tr><td>IS : 5082</td><td>Specification for wrought aluminium and aluminium alloy bars, rods,</td></tr><tr><td></td><td>tubes and selections for electrical purposes. Code of practice for phosphating of iron and steel.</td></tr><tr><td>IS : 6005 IS : 8686</td><td>Specification for static protective relays.</td></tr><tr><td>IS : 9046</td><td>AC contactors for voltages above 1000 volts and upto and including</td></tr><tr><td></td><td>11000V.</td></tr><tr><td>IS : 9224 IS : 9385</td><td>Low voltage fuses HV fuses</td></tr><tr><td>IS :9431</td><td>Specification for indoor post insulators of organic material for system</td></tr><tr><td>IS : 9921</td><td>with nominal voltages greater than 1000 V upto and including 300 kV AC dis-connectors (isolators) and earthing switches for voltages above</td></tr><tr><td>IS :11353</td><td>1000V Guide for uniform system of marking and identification of conductors</td></tr><tr><td></td><td>and apparatus terminals.</td></tr><tr><td>IS:13118 IEC-60099</td><td>Specification for high voltage AC circuit breakers. Metal oxide surge arrestor without gap for AC system</td></tr><tr><td>part 4</td><td></td></tr><tr><td>IEC-62271- 100</td><td>High voltage alternating current circuit breakers.</td></tr><tr><td>IEC-60099-1</td><td>Non-linear resistor type gapped arrestor for AC systems</td></tr><tr><td>IEC-60298</td><td>High voltage metal enclosed switchgear and control gear.</td></tr><tr><td></td><td></td></tr><tr><td>CIGRE WG 13.02 Ch.-3</td><td>Recommendation for substitute test for switching over voltage test</td></tr></table>

## 8.2.5 415V Switchgears and 415V Non Segregated Busduct :

## 8.2.5.1 The switchgears shall be indoor, metal clad having following features :

Circuit Breakers Air break, three pole, spring charged, horizontal drawout type, suitable for electrical operation   
Switchgear Fully drawout type, single front   
MCC/ VDDC Fully drawout type, single front/ double front   
ACDB/ DCDB Fixed type, single front/ double front

## 8.2.5.2 System parameters

<table><tr><td>1)</td><td>Nominal system voltage</td><td>415VAC</td><td>220V DC</td></tr><tr><td>2)</td><td>Highest system voltage</td><td>433V</td><td>240V DC</td></tr><tr><td>3)</td><td>Voltage variation</td><td>± 10%</td><td>187 – 242V DC</td></tr><tr><td>4)</td><td>Rated frequency</td><td>50 Hz</td><td>--</td></tr><tr><td>5)</td><td>Frequency variation</td><td>(+) 3 to (-) 5%</td><td>--</td></tr></table>

Section- 8 (Electrical and Control & Instrumentation System)
<table><tr><td>6)</td><td>System earthing</td><td>solidly grounded</td><td>Unearthed</td></tr><tr><td>7)</td><td>Maximum system fault</td><td>50kA for</td><td>25kA for</td></tr><tr><td>level</td><td></td><td>1 seconds</td><td>1 second</td></tr></table>

## 8.2.5.3 All 415V switchgears, AC and DC distribution boards (DBs), etc shall have following features :

a) Shall be of single front, fully draw-out, metal enclosed, indoor, floor mounted and free standing type.

b) All frames and load bearing members shall be fabricated using mild steel structural sections or pressed and shaped cold rolled sheet steel of thickness not less than 2mm.

c) Frame shall be enclosed in cold rolled sheet steel of thickness not less than 2mm (CR). Doors and covers shall also be of cold rolled sheet steel of thickness not less than 1.6 mm. Stiffeners shall be provided wherever necessary. Removable gland plates of thickness 3mm (hot/ cold rolled sheet steel) or 4 mm (nonmagnetic material) shall be provided for all panels.

d) For motors above 110kW (except for CHP, where it shall be 160kW), remote controlled electrical circuit breakers, and for smaller motors, switch-fuse contactor feeders shall be provided. The other outgoing feeders would be switchfuse units or moulded case circuit breakers.

e) The switchboards/ MCC/ DBs of 1600A and above rating shall be of DOP IP42 and of IP52 for less than 1600A rating.

f) Minimum air clearance in air between phases and phase-earth shall be 25 mm for busbars and cable terminations. For all other components, the Clearances shall be at least 10mm. Wherever above is not possible except for horizontal and vertical busbars, insulation shall be provided by anti tracking sleeving or barriers. However for horizontal and vertical busbars, clearances specified above shall be maintained even when busbars are insulated/ sleeved. Entire bus system shall be insulated with PVC sleeves (cable terminals in the cable alley shall be designed to meet for IV(b) of Type 7 as per IEC:60439 for safety purpose). In case of DCDBs/ fuse boards, the busbar system shall be insulated or physically segregated with barriers to prevent interpole short circuit.

## 8.2.5.4 Metering :

The energy meters shall be provided on LV side of each incoming transformer feeder of 415V buses as per the Central Electricity Authority (Installation and Operation of Meters) Regulations,2006 and its amendments.

Energy accounting and audit meters shall be of accuracy class not inferior to 1.0S as per CEA regulations. The accuracy class of CTs and VTs shall not be inferior to that of associated meters. In case, numerical relays having built-in features of energy

measurement of requisite accuracy are provided in switchgear, separate energy meter is not necessary.

## 8.2.5.5 Relays :

a) The protective relays shall be static or numerical type. However, numerical type shall be preferred. All relays, auxiliary relays and devices shall be of reputed make and types proven for the application and shall be subject to purchaser approval. The relays and timers shall have appropriate setting ranges, accuracy, resetting ratio, transient over-reach and other characteristics to provide required sensitivity to the satisfaction of the owner.

b) Relays shall be suitable for efficient and reliable operation of the protection scheme. Necessary auxiliary relays, timers, trip relays, etc. required for complete scheme, interlocking, alarm, logging, etc. shall be provided. Control relay shall not trip the circuit breaker when relay is de-energized.

c) Relays shall be flush mounted on the front with connections at the rear shall be draw-out or plug-in type/ modular case with proper testing facilities. Provision shall be made for easy isolation of trip circuits for testing and maintenance.

d) Auxiliary relays shall be provided in the trip circuits of protections located outside the board, such as buchholz relay, temperature indicators, fire protection, etc.

e) Control circuits shall operate at suitable voltage of 110V AC or 220V DC. Necessary control supply transformers having primary and secondary fuses shall be provided for each MCC, 2x100% per section. However the breakers shall operate on 220V DC. The auxiliary bus bars for control supply shall be segregated from main bus bars. The control supplies shall be monitored.

f) Contractor shall fully co-ordinate overload and short circuit tripping of breaker with upstream and down stream breakers/ fuses/ MCCBs motor starters. Various equipments shall meet requirement of Type-II class of coordination as per IEC.

g) In case of remote controlled breaker panels, following shall be provided.

Each feeder shall have local/ remote selector switch. Closing from local shall be possible only in test position whereas closing from remote shall be possible in either service or test position. Tripping from local shall be possible only when local/ remote selector switch is in local position. Tripping from remote shall be possible when breaker is in service position or selector switch is in remote position.

h) Suitable self powered transducers as per IS : 12784 Part - I (if required) for feeding signals to panel mounted electrical meters (ammeters, voltmeters, VAR meters and watt meters etc.) and DCCMIS shall be provided. Alternatively, analog signals from numerical relays shall be directly used.

i) The motor feeders for essential auxiliaries shall have contactors with delayed drop-out feature adjustable up to three seconds.

## 8.2.5.6 Protection :

a) 415V AC and 220V DC Incomers

Time graded short circuit protection on incoming supply feeder circuit breakers to main switchgears (PCCs and MCCs)

Instantaneous over-current protection on all outgoing feeders

Under- voltage protection for 415V bus

Sensitive earth fault detectors shall be provided in DC system to annunciate earth faults

## b) 415 Volts motor feeders

## 1) Contactor controlled motor feeders :

\- Instantaneous short circuit protection on all phases through HRC cartridge type fuses rated for 80 kA rms (prospective breaking capacity at 415V).

\- Thermal overload protection

\- Single phasing protection for motors protected by fuses

2) Breaker controlled motors feeders :

\- Instantaneous short circuit protection on all phases

\- Overload protection on two phases

\- Over load alarm on third phase

\- Earth fault protection

\- Under voltage protection

\- Hand reset lockout relay with a blue lamp for monitoring

8.2.5.7 Spare feeders - 20% spare outgoing feeders with atleast one of each type and rating shall be provided in each switchgear.

## 8.2.5.8 415V Non-segregated phase busduct :

a) The entire bus duct shall be designed for dust, vermin and weather proof construction. A suitable aluminium sheet flange-protection hood shall be provided to cover all outdoor bus duct enclosure joints to facilitate additional protection against rain water ingress. All horizontal runs of bus duct shall have a suitable sloped enclosure top to prevent retention of water for both indoor and out door portion of bus ducts. Bus duct enclosure shall have a degree of protection of IP-55. b)

b) The material of the conductor shall be aluminium. The bus bars shall be rated in accordance with the service conditions and the rated continuous and short time current ratings.

c) All steel structures required for bus duct support shall be hot dip galvanised.

d) The temperature rise of the bus bars and joints when carrying ninety percent (90%) of the rated current along the full run shall not exceed 40<sup>0</sup>C over an ambient of $5 0 ^ { 0 } \mathrm { C } ,$ . The maximum temperature rise during short circuit conditions shall not exceed 200<sup>0</sup>C.

e) Technical Data

i) Type Non-segregated

ii) 1 min. power freq. withstand voltage 2.5 kV

iii) Max. short circuit withstand current 45kA/ 50kA for 1 second

iv) Momentary dynamic current withstand 94.5/ 105kA (Peak)

## 8.2.5.9 Codes and Standards :

IS : 5 Colours for ready-mixed paints and enamels.

IS: 694 PVC insulated cables for working voltages upto and including 1100V

IS : 722 AC Electricity Meters

IS : 1248 Electrical Indicating instruments

IS : 13947 Part 1 Degree of protection provided by enclosures for low voltage Switchgear and Control gear

IS : 13947Part-2 / AC Circuit Breakers

IS : 2551 Danger Notice Plates

IS : 2629 Hot dip galvanising

IS : 2705 Current Transformers

IS : 13947Pt 4,Sec-1 Contactors and motors starter for voltages not exceeding 1000

(IEC-60947) V AC or 1200 V DC

IS : 3043 Code of practice for earthing

IS : 3072 Code of practice for installation and maintenance of Switchgear

IS : 3156 Voltage Transformers

IS : 3202 Code of practice for climate proofing of electrical equipment IS : 3231 Electrical relays for power system protection

IS : 13947 Air-Break Switches, air break disconnectors, air Break disconnector and fuse combination units for voltages not exceeding 1000V AC or 1200 V DC.

IS : 13947 Pt. - I General Requirements for Switchgear and Control gear for

IEC –60947 voltages <1000 V

IS : 5082 Wrought Aluminium and Aluminium alloys for electrical purposes.

IS : 6005 Code of practice of phosphating of iron and steel

<table><tr><td>IS:13947 Pt.-5 Sec.1, IEC-60947 IS : 8623(3 parts) /</td><td>LV switchgear and Control gear Control current devices and switching element Specification for factory built assemblies of Switchgear and</td></tr><tr><td>IEC-60439</td><td>Control gear for voltages upto and including 1000V AC and 1200V DC</td></tr><tr><td>IS : 8686 IS : 13703 / IEC-</td><td>Static Relays HRC Cartridge fuses</td></tr><tr><td>60269</td><td></td></tr><tr><td>IS : 10118 (4 parts)</td><td>Code of practice for selection, installation and maintenance of switchgear and control gear</td></tr><tr><td>IS :11171 IS :11353</td><td>Specification for dry type transformers Guide for uniform system of marking and identification of</td></tr><tr><td>IS :12021</td><td>conductors and apparatus terminals Specification of control transformers for switchgear and</td></tr><tr><td>IS:8084</td><td>Control gear for voltage not exceeding 1000V AC</td></tr><tr><td>Updated upto:1992</td><td>Interconnecting bus bars for A.C. voltage above 1KV upto and</td></tr><tr><td></td><td>including 36KV.</td></tr><tr><td>ANSI C37:20</td><td>Switchgear Assemblies including Metal enclosed Bus.</td></tr></table>

## 8.2.6 DC System :

8.2.6.1 DC system comprising of DC storage batteries suitably rated Trickle and Boost chargers and DC distribution boards shall be provided to cater the normal DC loads. The DC system shall be generally comprising of :

8.2.6.2 1x100% sets of 220V of either Lead–Acid Plante or Nickel-Cadmium Battery banks catering CHP load shall be provided.

8.2.6.3 The Ampere-hour capacity of DC storage battery shall be based on half an hour supply.

8.2.6.4 2x100% float cum boost charger shall be provided for each battery bank.

8.2.6.5 Codes and Standards :

IS : 266 Specification for sulphuric acid

IS : 1069 Specification for water for storage batteries

IS : 1146 Specification for rubber and plastic containers for lead acid storage batteries

IS : 1652 Specification for stationary cells and batteries, lead acid type (with plant positive plates).

IS : 3116 Specification for sealing compound for lead acid batteries.

IS : 8320 General requirements and methods of tests for lead acid storage batteries

IS : 6071 Specification for synthetic separators for lead acid batteries

IS : 10918 Specification for vented type Nickel Cadmium Batteries.

IS : 1069 Quality tolerances for water for storage batteries

ANSI-C Guide for surge withstand capability tests

IS:5 Colours for ready mix paints.

IS : 694 PVC Insulated Cable for working voltages upto and including 1100V

IS : 1248 Specification for Direct acting indicating analogue electrical measuring

## instruments.

IS:13947 Degree of protection provided by enclosures for low voltage switch gear Pt-1 and control gear.

IS : 13947 Specification for low voltage switch gear and control gear

IS : 3231 Electrical relays for power system protection.

IS : 3842 Application guide for Electrical relays for AC System

IS : 3895 Mono-crystalline semi-conductor Rectifier Cells and Stacks

IS : 4540 Mono crystalline semi-conductor Rectifier assemblies and equipment.

IS:6005 Code of practice for phosphating of Iron and Steel

IS:6619 Safety Code for Semi-conductor Rectifier Equipment.

IS:6875 Control switches (switching devices for control and auxiliary circuits including contactor relays) for voltages upto 1000 VAC or 1200V DC

IS : 9000 Basic environmental testing procedures for electronic and electrical items.

IS:13703 Low voltage fuses for voltages not exceeding 1000 V AC, 1500VDC.

EEUA-45D Performance requirements for electrical Alarm Annunciation system

## 8.2.7 Power and Control cables and Laying & Termination :

8.2.7.1 For 11/ 3.3kV system, Power cables shall be XLPE insulated with conductor and insulation screens armoured and FRLS PVC outer sheathed. The 415V system cables and control cables shall be 1.1kV grade, PVC insulated, armoured and FRLS PVC outer sheathed. The sizing of all power cables shall be done on the basis of current rating taking into account proper de-rating factors for temp. deration and group deration. However, 11/3.3kV cables shall be chosen on the basis of magnitude of fault current and fault clearing time. Certain important auxiliaries as given below shall be provided with fire survival (FS) cables as these cables can withstand 750<sup>0</sup>C for three (3) hours.

Fire alarm, annunciation and protection system.

DC supply cables to switchgears.

DC cables from batteries to DC boards.

DC emergency lighting cables for main building etc.

8.2.7.2 Cable shall have suitable filters laid up with the conductors to provide a substantially circular cross section before the sheath is applied. The constructional requirement shall be as follows :

a) 11 kV system power cables - The cable shall be 11kV/11kV (unearthed) grade, heavy duty, stranded aluminium conductor, XLPE insulated, provided with conductor screening and insulation screening, galvanized steel wire/strip armoured (non-magnetic material for single core cables), flame retardant low smoke (FRLS) extruded PVC of type ST2 outer sheathed.

b) 3.3 kV system power cables - The cable shall be 3.3kV/3.3kV (unearthed) grade, heavy duty, stranded aluminium conductor, XLPE insulated, provided with conductor screening and insulation screening, galvanized steel wire/ strip armoured (non-magnetic material for single core cables), flame retardant low smoke (FRLS) extruded PVC of type ST2 outer sheathed.

c) 415V system power cables - The cable shall be 1.1kV, grade, heavy duty, stranded aluminium conductor, PVC Type-A Insulated galvanized steel wire/strip armoured (non-magnetic material for single core cables), flame retardant low smoke (FRLS) extruded PVC type ST1 outer sheathed.

d) Control cables - The cable shall be 1.1kV grade, heavy duty, stranded copper conductor, PVC Type-A insulated, galvanized steel wire/ strip armoured, flame retardent low smoke (FRLS) extruded PVC of Type-ST1 outer sheathed.

8.2.7.3 Special properties : All the above cables shall be conforming to the relevant Indian/ IEC standard in general, with the following special properties:

a) Oxygen Index of the outer sheath shall not be less than 29, when tested as per ASTM-D-2863.

b) Temperature Index of the outer sheath shall not be less than 250<sup>0</sup>C and 350<sup>0</sup>C for FRLS and FS cables respectively, when tested as per ASTM-D-2863.

c) Halogen acid contents in outer sheath shall not be more than 20% and 2% for FRLS and FS cables respectively, when tested as per IEC-60754.

d) The maximum smoke density in percent light absorption should not exceed 60% in case of PVC compound and 20% in case of fire survival cables, when tested as per ASTM-D-2843.

e) Swedish chimney test as per SS-4241475 class F3 and ladder test for flammability as per IEEE-383.

8.2.7.4 All cables shall be run in GI cable trays/ rigid GI conduits as far as possible. Cable trays shall be ladder/ perforated type. Cable tray support system shall be pre-fabricated. Cable trays shall have standard width of 150 mm, 300 mm and 600 mm and standard lengths of 2.5 metre. Minimum thickness of mild steel sheets used for fabrication of cable trays and fittings shall be 2 mm. The thickness of side coupler plates shall be minimum 3 mm. Cable installation shall be carried out as per IS:1255 and other applicable standards.

8.2.7.5 Power and control cables shall be laid on separate tiers. The laying of different voltage grade cables shall be on different tiers according to the voltage grade of the cables. In horizontal tray stacks, HT cables shall be laid on topmost tier and cables of subsequent lower voltage grades on lower tiers of trays. Single core cable in trefoil formation shall be laid with a distance of four times the diameter of cable between trefoil center lines and clamped at every two metre. All multi-core cables shall be laid in touching formation. Where cables cross roads/ rail tracks, the cables shall be laid in hume pipe/ PVC pipe. Joints for less than 250 Meters run of cable shall not be permitted.

8.2.7.6 Termination and jointing kits for 11/ 3.3 kV grade XLPE insulated cables shall be of proven design and make and type tested. Termination kits and jointing kits shall be premoulded type, tapex type or heat shrinkable type and shall be type tested as per IS:13573.

8.2.7.7 Wherever the cables pass through walls/ floors, fire proof cable penetration seals rated for two hours shall be provided. The system offered shall be of proven type as per BS:476 (Part-20) or equivalent standard.

## 8.2.7.8 Codes and Standards :

<table><tr><td>IS:1554</td><td>PVC insulated (heavy duty) electric cables for working</td></tr><tr><td>(Part-I)</td><td>voltage up to and including 1100 V.</td></tr><tr><td>IS:1554 (Part-II)</td><td>PVC insulated (heavy duty) electric cables for working voltage from 3.3kV upto and including 11kV.</td></tr><tr><td>IS:7098 (Part-II)</td><td>XLPE insulated PVC sheathed cables for working voltages from 3.3 kV upto and including 33kV.</td></tr><tr><td>IS:3961</td><td>Recommended current ratings for cables.</td></tr><tr><td>IS:8130</td><td>Conductors for insulated electric cables and flexible cords.</td></tr><tr><td>IS:5831</td><td>PVC insulation and sheath of electric cables.</td></tr><tr><td>IS:2982</td><td>Copper conductor in insulated cables and cords.</td></tr><tr><td>IS:3975</td><td>Mild steel wires, strips and tapes for armouring cables</td></tr><tr><td>IS:5609</td><td>Specification for low frequency wirers and cables with PVC insulation and PVC Sheath.</td></tr><tr><td>IS:6380</td><td>Spec. of elastomeric insulation of sheath of electric cables.</td></tr><tr><td>IS:434(I and II) IEC:540</td><td>Specification for rubber insulation cables The methods for insulations and sheaths of electric cables and</td></tr><tr><td>IEC:230</td><td>cords (elastomeric and thermoplastic compounds). Impulse tests on cables and their accessories.</td></tr><tr><td>IEC:60</td><td>High voltage test techniques.</td></tr><tr><td>IEC:287</td><td>Calculations of the continuous current rating of cables</td></tr><tr><td>IEC:288</td><td>(100% 1oad factor). Nominal cross-sectional area and composition of</td></tr><tr><td>IEC:502</td><td>conductor of insulated cables. Extruded solid dielectric insulated power cables for rated voltages</td></tr><tr><td>NEMA-WC-5</td><td>from 1.00 kV upto 30 kV. Thermoplastic insulated wires and cables for transmission and</td></tr><tr><td>IEEE:383</td><td>distribution of electrical energy. Standard for type test for class IE electric cables, filled splices</td></tr><tr><td></td><td>and connections for nuclear power generation stations</td></tr><tr><td>IEC: 332-1 ASTM-D-2843</td><td>Test on electric cables under fire conditions. Standard test method for density of smoke from burning/</td></tr><tr><td></td><td>decomposition of plastics.</td></tr><tr><td>ASTM-D-2863</td><td>Test for determination of Oxygen Index.</td></tr><tr><td>IEC-754-I</td><td>Test method for acid gas generation.</td></tr><tr><td>IEC-331</td><td>Fire resisting characteristics of electric cables.</td></tr><tr><td>SVENSK Standard</td><td>SS- 4241475 Class F3</td></tr><tr><td></td><td>BICC Hand Book For cables in fire regarding temperature index-chapter-6</td></tr></table>

## 8.2.8 Lighting system:

8.2.8.1 The auxiliary building shall be provided with a) Main Lighting system for full illumination under normal power supply conditions and shall operate from 415/ 240V AC Power supply tapped from respective 415V switchgear b) Emergency lighting system for reduced illumination operated by DG supply feeders during failure of main power supply. It will cover only 20% of fixtures in the building and associated area c) Minimum emergency lighting system for reduced illumination during failure of main power supply with the help of 220V DC batteries/ supply feeders and d) Suitable no. of Portable lighting units

8.2.8.2 Various lighting branch boards shall be fed directly from 415V switchgear through 1:1 transformers to reduce fault level. If the fault level can be contained in 9kA by virtue of cable impedence involved, then use of 1:1 transformers can be dispensed with.

8.2.8.3 Illumination Levels and Type of Fixtures and Luminaries :

<table><tr><td>SN</td><td>Location</td><td>Average Illumination</td><td>Type of Fixture</td></tr><tr><td>1.</td><td>Switchgear rooms</td><td>level (lux) 200</td><td>Industrial trough type fluorescent</td></tr><tr><td>2.</td><td>Control Room</td><td>300</td><td>Mirror optics with anti-glare features</td></tr><tr><td>3.</td><td>Battery rooms</td><td>100</td><td>Totally enclosed corrosion resistant/</td></tr><tr><td>4.</td><td>Street lighting</td><td></td><td>vapour proof HPSV street lights</td></tr><tr><td rowspan="3">5.</td><td>- primary roads</td><td>20</td><td></td></tr><tr><td>- secondary roads</td><td>10</td><td></td></tr><tr><td>Outdoor storage handling</td><td>20</td><td>HPSV flood light, weather proof</td></tr><tr><td>6.</td><td>and unloading area Permanent stores</td><td>150</td><td>Industrial trough type fluorescent</td></tr><tr><td>7.</td><td>Garage/ Car parking</td><td>70</td><td>Industrial trough type fluorescent</td></tr><tr><td>8.</td><td>Facility building, canteen</td><td>150</td><td>Industrial trough type fluorescent</td></tr></table>

8.2.8.4 Wherever possible Energy Efficient lamps shall be used.

8.2.8.5 Automatic ON/ OFF shall be preferred for street lighting through timers/ photo cells.

## 8.2.9 Earthing and Lightning Protection system:

Earthing system shall be designed to meet the following requirements:-

8.2.9.1 Earthing and lightning protection for the entire areas or buildings covered shall be provided in accordance with IS 3043, IS 2309, IEEE 80 and IEEE 665 and Indian Electricity Rules/ Acts.

8.2.9.2 Earthing system will be designed considering suitable corrosion allowance based on earthing conductor material and type of soil, for a service life of at least forty (40) years for maximum fault current or system fault current of 40kA whichever is higher for 1 second. The minimum rate of corrosion of earthing conductor shall be considered as 0.12mm per year while determining the conductor size.

8.2.9.3 Down conductors shall be connected to separate earth electrodes through test points located at height of 1000mm above ground level. These earth electrodes shall in-turn be connected to earth mat at two points.

8.2.9.4 Dedicated earthing system (Electronic grounding system) shall be provided for instrumentation system. The grounding system for electronic grounding shall be kept insulated from the other grounding system such as motor, transformer, switchgear etc.

8.2.9.5 The material of the earthing conductors shall be as follows :

a) Conductors above ground level and in built Galvanized steel up trenches

b) Conductors buried in earth Mild steel

c) Earth electrodes Mild steel rod

8.2.9.6 The sizes of earthing conductors for various electrical equipments shall be as below:

<table><tr><td>Equipment</td><td></td><td>Earth conductor buried in earth</td><td>Earth conductor and in built-up trenches</td></tr><tr><td>a)</td><td>Main earth grid</td><td>40 mm dia. MS rod</td><td>65x12mm GS flat</td></tr><tr><td>b)</td><td>11kV switchgear/ equipment</td><td></td><td>65x12mm GS flat</td></tr><tr><td>c)</td><td>3.3 kV switchgear/ 415V switchgear/ Transformers</td><td></td><td>50x6mm GS Flat</td></tr><tr><td>d)</td><td>415V Motors</td><td></td><td></td></tr><tr><td></td><td>- above 125 kW - 25 kW to 125 kW</td><td></td><td>50 x 6mm GS flat 25 x 6mm GS flat</td></tr><tr><td></td><td>- 1kW to 25 kW</td><td></td><td>25 x 3mm GS flat</td></tr><tr><td>e)</td><td>Control panel/ desk</td><td></td><td>25 x 3 mm GS flat</td></tr><tr><td>f)</td><td>Push button station/</td><td></td><td>8 SWG GI wire</td></tr><tr><td></td><td>Junction Box</td><td></td><td>50x6mm GS flat</td></tr><tr><td>g)</td><td>Columns, structures, cable trays and bus ducts</td><td></td><td></td></tr></table>

8.2.9.7 Metallic frame of all electrical equipment shall be earthed by two separate and distinct connections to earthing system,

8.2.9.8 Each continuous laid lengths of cable tray shall be earthed at minimum two places by GS flats to earthing system.

8.2.9.9 Earth pit shall be constructed as per IS:3043. Electrodes shall be embedded below permanent moisture level. Minimum spacing between electrodes shall be 6000mm. Earth pits shall be treated with salt and charcoal if average resistance of soil is more than 20 ohm metre.

8.2.9.10 Fences included within the ground grid area should have a conductor parallel to the fence on the outside at a distance of 500 to 1500mm with 1000mm generally recommended and the fence and conductor should be bonded together and to the ground grid at frequent intervals as per ANSI/ IEEE-665.

8.2.9.11 Lightning protection system shall comprise vertical air terminations, horizontal air terminations, down conductors, test links and earth electrodes.

8.2.9.12 Conductors of lightning protection system shall not be connected with conductors of earthing system above ground level.

8.2.9.13 Air terminations, down conductors and test links shall be of galvanized steel conductors and earth connection below ground level shall be of mild steel rod.

## 8.3 Control & Instrumentation System - Design Criteria :

8.3.1 A totally integrated instrumentation and control system covering the total functional requirements of sequential control, interlock, protection, monitoring, alarm, data logging, fault analysis etc. to ensure operability, maintainability and reliability with latest state of art equipment shall be provided. The control system for each of BOP system shall either be Programmable Logic Controller (PLC) based or shall be implemented through micro-processor based distributed control system (DCS).

8.3.2 All electrical instruments, solenoid valves shall be provided with explosion proof enclosure as per National Electric Code (USA) Article 500, Class-I, Division-I located in the hazardous areas, viz. Fuel oil area, Coal handling area etc.. Further, all fittings, cable glands etc shall be strictly as per NEC recommendation article, 500 to 503.

## 8.3.3 Environmental Conditions

Instruments, devices and equipments for location in outdoor/ indoor/ air-conditioned areas shall be designed to suit the environmental conditions indicated below and shall be suitable for continuous operation in the operating environment of a coal fired station and also during periods of air-conditioning failure without any loss of function, or departure from the specification requirements covered under this specification.

<table><tr><td rowspan=1 colspan=1>Ammunt tmmureouti ts)</td><td rowspan=1 colspan=1>Prssure</td><td rowspan=1 colspan=1>Relttvehumiy</td><td rowspan=1 colspan=1>Atnmppoere</td><td rowspan=1 colspan=1>Rebced pronClanns  daell/cab dasks</td></tr><tr><td rowspan=1 colspan=5>Outdoor location</td></tr><tr><td rowspan=1 colspan=1>55℃ max</td><td rowspan=1 colspan=1>Atmosphere</td><td rowspan=1 colspan=1>100% max</td><td rowspan=1 colspan=1>Air (dirty)</td><td rowspan=1 colspan=1>IP 55***</td></tr><tr><td rowspan=1 colspan=1>4C min</td><td rowspan=1 colspan=1>Atmosphere</td><td rowspan=1 colspan=1>5% min</td><td rowspan=1 colspan=1>Air (dirty)</td><td rowspan=1 colspan=1>IP 55***</td></tr><tr><td rowspan=1 colspan=5>Indoor location</td></tr><tr><td rowspan=1 colspan=1>55℃ max</td><td rowspan=1 colspan=1>Atmosphere</td><td rowspan=1 colspan=1>95% max</td><td rowspan=1 colspan=1>Air</td><td rowspan=1 colspan=1>IP 54**</td></tr><tr><td rowspan=1 colspan=1>4C min</td><td rowspan=1 colspan=1>Atmosphere</td><td rowspan=1 colspan=1>5% min</td><td rowspan=1 colspan=1>Air</td><td rowspan=1 colspan=1>IP 54**</td></tr><tr><td rowspan=1 colspan=5>Air-conditioned areas</td></tr><tr><td rowspan=1 colspan=1>24±5℃normal</td><td rowspan=1 colspan=1>Atmosphere</td><td rowspan=1 colspan=1>95% max</td><td rowspan=1 colspan=1>Air</td><td rowspan=1 colspan=1>IP 22</td></tr><tr><td rowspan=1 colspan=1>50℃ max *</td><td rowspan=1 colspan=1>Atmosphere</td><td rowspan=1 colspan=1>5%.min</td><td rowspan=1 colspan=1>Air</td><td rowspan=1 colspan=1>IP 22</td></tr><tr><td rowspan=1 colspan=5>*   During air conditioning failure.</td></tr><tr><td rowspan=1 colspan=5>** For non-ventilated enclosures. For ventilated enclosures, protectionclass shall be IP 42.</td></tr><tr><td rowspan=1 colspan=5>*** With a suitable canopy at the top to prevent ingress of dripping water.</td></tr></table>

## 8.3.4 Operability & Maintainability

a) The design of the control systems and related equipments shall adhere to the principle of ‘Fail Safe’ operation wherever safety of personnel/ plant equipment is involved. ‘Fail Safe’ operation signifies that the loss of signal or failure of any component shall not cause a hazardous condition. However, it shall also be ensured that occurrence of false trips are avoided/ minimised.

The types of failure, which shall be taken into account for ensuring operability of

## the plant shall include but not be limited to:

Failure of sensor or transmitter

Failure of main and/ or redundant controller/ other modules

Loss of motive power to final control element

Loss of control power

Loss of instrument air

b) The choice of hardware shall also take into account sound maintainability principles and techniques. The same shall include but shall not be limited to the following:

Standardization of parts

Minimum use of special tools

Grouping of functions

Interchangeability

Malfunction identification facility/ self surveillance facility

Easy modular replacement

Fool proof design providing proper identification and other features to preclude improper mounting and installation

Appropriate de-rating of electronic components and parts

## 8.3.5 Programmable Logic Controller based control system

a) Each PLC unit shall be provided with two processors; one for normal operation and one as hot standby. In case of failure of working processor, there shall be an appropriate alarm and simultaneously, the hot standby processor shall take over the complete plant operation automatically. The transfer from main processor to standby processor shall be totally bump-less and shall not cause any plant disturbance whatsoever. In the event of both processors failing, the system shall revert to fail safe mode.

It shall be possible to keep any of the processors as master and other as standby. The standby processor shall be updated in line with the changes made in working processor.

b) The PLC system shall be provided with necessary interface hardware and software for dual fibre-optic connectivity & inter-connection with station wide LAN for two-way transfer of important signals for respective systems for the purpose of information sharing.

c) Two (2) nos. PC based Operator Work Stations (OWS) shall be provided for i) control & monitoring and ii) programming function with each PLC assignable to any of the above two tasks.

d) The sequence startup mode shall be of the following types.

Automatic Mode

In this mode of operation, the sequence shall progress without involving any action from the operator. The sequence start/ stop command shall be issued from the TFT/ KBD’s.

## Semi-Automatic Mode

In this mode of operation, once the sequence is initiated, the step progressing shall be displayed on the TFT. But the step execution command shall be prevented and shall be sent by the operator via the keyboards. It shall be possible to bypass and/ or simulate one or more criteria to enable the program to proceed. This facility shall allow the program to be executed even if some criteria are not fulfilled because of defective switching device, etc., while the plant condition is satisfactory. All the criteria by-passed shall be logged and displayed. It shall be possible to put the system on the auto-mode after operating it on semi-automatic mode for some steps or vice-versa, without disturbance to the sequence operation.

## Operator Test Mode

It shall be possible to use the sequential control in operator guide mode/ test mode i.e. the complete system runs and receives input from the plant and the individual push button stations (where provided)/ keyboards but its command output is blocked. The whole programme, in this case shall run in manual mode. This mode shall allow the operator to practise manual operation using step and criteria indications. The actual protection should remain valid during this mode of operation also.

The sequence shall be started by putting the sequence on 'auto' and on receipt of 'start' command from the OWS or from a higher level group/ protection action as defined. The sequence shall then progress as per the defined logics. It should be possible to select alternative operation in the same sequence depending on certain process/ equipment condition. Some step can be automatically by-passed also based on certain process/ equipment condition. When the expected results of the sequence are reached the sequence is considered as "End".

If during sequence initiation or sequence progressing or during normal running of the drive, a shutdown criteria is present, the sequence shall be stopped and the shut down sequence initiated.

## Priority of different commands shall be as follows:

i) Manual intervention shall be possible at any stage of operation. Protection commands shall have priority over manual commands and manual commands shall prevail over auto commands.

ii) In PLC controller, memory shall exist as to where the sequence was aborted due to power supply failure, so that further operation from that point can restart on restoration of power supply. This restart shall be through operator‘s intervention, so as to enable verification of readiness of other related equipments.

f) Input/ Output (I/O) Modules

i) The PLC system shall be designed according to the location of the input/ output cabinets whether in the same cabinet or mounted in a separate rack.

ii) I/O modules for all type of field input signals (4-20mA, RTDs, thermocouples, non-changeover/ changeover contact inputs etc.) and outputs from the control system (non-changeover/ change over contact, 24/48VDC output signals for energising interface relays, 4-20mA output etc.) shall be provided. Redundant field sensors shall be provided for critical applications.

iii) Electrical isolation of 1.5kV with optical couplers between the plant input/ output and controller shall be provided on the I/O cards. The isolation shall ensure that any inadvertent voltage or voltage spikes shall not damage or mal-operate the internal processing equipment.

iv) The I/O system shall facilitate modular expansion in fixed stages. The individual I/O cards shall incorporate indications on the module front panels for displaying individual signal status.

v) Individually fused output circuits with the blower fuse indicator shall be provided. All I/O points shall be provided with status indicator. Input circuits shall be provided with fuses preferably for each input; alternatively, suitable combination of inputs shall be done and provided with fuses such that for any fault, fuse failure shall affect the particular drive system only without affecting other systems.

vi) All I/O cards shall have quick disconnect terminations allowing for card replacement without disconnection of external wiring and without switching of power supply.

vii) The following features shall be provided:-

\- Power supply monitoring;

\- Contact bounce filtering;

\- Optical isolation for binary signals and galvanic isolation for analogue signals.

In case of power supply failure or hardware fault, the critical outputs shall be automatically switched to the fail-safe mode.

viii) Keying-in of individual wire connectors shall be provided to ensure that only the correct card is plugged on the I/O module. It shall be possible to remove I/O module without disconnecting wiring from field inputs or outputs. There shall be atleast 20% spare capacity available on input, output and memory modules, over and above the system requirement.

ix) Binary Output modules shall be rated to switch ON/ OFF coupling relays of approx. 3VA at 24VDC. Analog output modules shall be able to drive a load impedance of minimum 500<sup>Ω</sup>.

x) Output module shall be capable of switching ON/ OFF inductive loads like solenoid valves, auxiliary relays etc. without any extra hardware.

xi) Only one changeover contact shall be provided in MCC for control and interlock requirement. Further, multiplication, if required, shall be done in PLC.

xii) All input field interrogation voltage shall be 24V DC or 48V DC.

xiii) In case of loss of I/O communication link with the main processing unit, the I/O shall be able to go to predetermined fail safe mode with proper annunciation.

xiv) 20% spare I/O modules in each system cabinet shall be provided.

## g) Data Communication System (DCS)

Redundant communication controllers shall be provided to handle the communication between I/O Modules (including remote I/O) and PLC’s and between PLC’s and operator work station.

## h) Operator interface displays/ logs

Suitable displays and reports for control operation and monitoring shall be provided.

## 8.3.6 Control and power supply scheme

i) For PLC system, redundant 24V DC power supply system shall be provided. The system shall consist of two sets, each set provided with 1x100% Ni- Cd batteries, 1x100% DC distribution board.1x100% microprocessor controlled intelligent modular rectifier banks and 1x100% controller for each bank. Necessary power supply from 415V, 3-phase redundant incomers shall be arranged from 415V MCC .

For separately mounted I/O racks, separate power supplies shall be provided. Power supply module shall be of adequate capacity to supply all modules. In addition 20% spare capacity for future shall be provided. All the drives shall be switched ON/ OFF through 24VDC coupling relays to be provided in HT/ LT

switchgears.

ii) Each set of PC along with TFT shall be provided with smart type line interactive Uninterrupted Power Supply (UPS) with software and hardware for remote management along with features of surge suppression and AVR facility. The UPS shall be of sufficient capacity of at least 30 minute at machine load.

iii) The battery shall be sealed maintenance free Ni-Cd type or Plante type lead acid batteries with long life and shall be able to provide a back-up for 30 min.at full load requirement of the complete control system.

## 8.3.7 Annunciation system

Annunciation system shall be integral part of PLC system. Field contacts shall be acquired through PLC only. The annunciation sequence logics shall be implemented as a part of PLC controllers.

# STANDARD DESIGN CRITERIA/GUIDELINES FOR BALANCE OF PLANT OF THERMAL POWER PROJECT 2 x (500MW OR ABOVE) SECTION- 9: (CIVIL WORKS)

## 9.1 GENERAL

## 9.1.1 Intent and Scope

This section covers technical requirements for design criteria/guidelines for civil and structural works for Balance of Plant Packages. The scope of civil works has been described in respective Section of Balance of Plant packages.

## 9.1.2 Site Grading and Leveling

i) Design criteria

Leveling and grading shall be carried out by selected cutting and filling of existing ground surface and earth. The cutting and filling requirements should balance each other to avoid earth from borrow pits as far as possible. Different grade levels may be adopted for different areas. Following levels may generally be adopted for the plant:-

a) Formation level of the plant : +0.0M

b) Road level of the plant +0.25 to 0.3M

c) Finished floor level of all buildings : +0.5M

Formation level of the plant shall be kept minimum 1.0 m above the highest flood level (HFL).

## ii) General site excavation and fill

General site excavation and fill shall establish a uniform, stable working surface in active station areas, provide for positive drainage compatible with natural drainage system around buildings and other structures, and provide adequate soil cover for underground utilities. Before the placement of fill material, the existing sub grade shall be prepared as follows:-

a) All vegetation, organic or otherwise incompetent material shall be removed. The remaining in-situ material shall be compacted to the depth and density determined by the detailed design. Slope stability, moisture and density relationship, and compaction requirements shall be determined as a result of the geotechnical field and laboratory investigations.

b) The size of the general site fill is defined by its geometrical boundaries. These shall be established in conformity with the arrangement of site facilities and the site design parameters subject to constraints imposed by the interfacing systems.

c) The natural soil strata and fill material shall be tested for presence of sulphates and chlorides. In the event high percentages of such compounds are found to be present, required special treatment/coatings shall be provided to the concrete and reinforcement surfaces for foundations and structures below ground for protection against the deterioration during the life-time of such structures.

## Structure backfill

a) Structure backfill shall provide stable fill around and adjacent to structure foundations and buried utilities.

b) All organic and other existing material which can cause settlements due to soil volume change shall be removed prior to placing the fill material. Backfill shall be placed and compacted to the required limits. The use of heavy equipment or inundation for placing structure backfill shall be prohibited.

## Slope protection

Slope protection shall protect earth slopes from erosion due to storm water runoff and wind damage or other natural phenomena consisting of grass cover, grout filled fabric forms rip rap. The type of slope protection shall be determined by expected velocities of storm water run off.

## 9.1.3 Roads

Design criteria

a) The roads system shall provide vehicular access throughout the plant area including access to all building and structure etc. The system shall provide access to all building and major activity areas of the site.

b) The roads system shall be subjected to heavy vehicles and construction equipment during construction. All roads shall be subject to heavy wheel loads of off-road haul trucks, wheel loaders, and scrapers. Road system shall be designed for minimum class ‘A’ loading or higher conforming to IRC standards. All roads should be provided with adequate camber as per IRC standards.

c) The roads shall be divided into two types of roads as follows:-

1. All main roads shall be 8 meter wide with raised foot path on both sides of roads.

2. All secondary plant roads shall be 4.5 meter wide provided with 1.5 meter wide hard shoulders on either side and shall be for access to plant auxiliary areas and buildings. Peripheral road along the boundary wall shall have adequate nos. of watch towers as per requirement.

d) Secondary access roads within the station complex shall be constructed during the site preparation phase of construction with RCC culvert at road junctions to cater for crossing of drains/cables etc. to avoid major road cuttings at a later date.

e) All roads shall be constructed on prepared sub-grade and stone sub-base and base of two (2) layers of water bound macadam each of minimum 75 mm thickness, with Gr. II crushed rock aggregate conforming to IRC-19 laid over prepared sub-base. The sub-grade for the road shall be the natural ground, which shall be cleared of all loose material, organic matter, grass etc, scarified, rolled and compacted to proctor density of 95%. The sub-base shall consist of crushed stone laid to a minimum thickness of 200 mm, in 2 layers of 100 mm compacted thickness each, with Gr. I aggregate conforming to IRC-19. All the roads shall be topped with bitumen. Road side drainage shall be provided preferably on both sides of road. The total thickness and composition of the layers of the pavement shall be provided as per IRC – 37. “Design of flexible pavement.”

## ii) Road sub-grades

a) The sub-grades shall provide uniform and stable foundations for the roads.

b) Embankment fill material shall consist of specified fill material obtained from excavation at other onsite grading areas, buildings, or roadbeds. This material shall be placed and compacted to the density and geometry determined by the detailed design to provide the strength required and to limit settlements within the allowable limits.

## Type of roads

a) Access within the plant site shall be provided by a system of roadways.

b) Roads shall be three types: Type I, Type II and Type III.

c) Type I roads shall be 8 meter wide and consist of asphalt paved carriageways with 1.5 m wide hard shoulders.

d) Type II roads shall be 4.5 m wide with 1.5 m wide hard shoulders on either side. Type III roads, 3 meter wide, shall be provided along the plant boundary for access for security and maintenance.

e) All roads shall be surfaced with gravel during the construction period. Occasional applications of a dust palliative material shall be used to minimize the dust problem during the dry seasons.

f) All Type I and Type II roads shall have a minimum turning radius of 15.2 m. Bollards shall be provided along side all type roadways near equipment which requires protection. Spare duct banks shall be provided under all type roads spaced at 100 m intervals.

g) Signs shall be provided for vehicle management and shall meet Indian standards. All signs shall be dual worded in both English and the local Indian language.

## 9.1.4 Storm Water Runoff Drainage

## i) Design criteria

a) Grading shall provide stable sub-grades for transportation facilities, flow ways for the transportation of runoff, flood protection, and stable earth surfaces for access and for handling of materials during plant construction and operation.

b) Storm water runoff drainage shall direct runoff from roof drains and other areas to the proper drainage collection basins or to natural drainage as appropriate. Rainfall runoff shall be directed from facility areas and construction lay-down areas in a manner which allows maximum freedom of vehicular traffic patterns.

c) Various classes of compacted earth fill materials with stone base shall form roadbed embankments, foundation bearing surfaces, and stable earth surfaces for access roads and parking areas.

d) Grading and engineered ditches shall direct the site drainage. Roof drainage and ditch flow shall be based on a 1 in 50 year frequency rainfall event for the power block area, the railroad, and for the plant access roads.

e) Whenever possible, drainage shall run parallel to roadways and traffic areas to direct runoff to culverts used in the storm water runoff drainage system.

f) In case collection basin is provided, the basin shall be designed to contain general site drainage, neutralization basin flows, oil/water separator flows, and service water system flows, septic tank. The basin shall be sized to contain the 24 hours storm runoff from two recent consecutive rainfall events and shall be designed not to have a normal discharge.

## ii) Storm water runoff drainage and culverts

Offsite runoff entering the site from surrounding areas shall be routed around the site area through the use of overland flow, open channel flow, and underground piping. Runoff originating from areas of the site not disturbed by construction activities or unit operation shall be allowed to flow to the natural site drainage system. Runoff from disturbed areas of the site shall be controlled as described below:-

a) Open areas shall be sloped a minimum of 1 percent to drain away from buildings and structures towards drainage channels. All runoff shall be conveyed by gravity to the drainage system. Open drains shall be utilized primarily except for roof and floor drainage. In areas where surface space limitations prevent the use of open drains, catch basins/pits shall be used. Catch basins shall discharge to the nearest open drain through underground piping. RCC box culverts/pipe culverts shall be used to pass flows under roads, railroads, and other locations where surface conveyance would not be practical. For pipe culverts, reinforced concrete pipes class NP3 conforming to IS-458 shall be provided. For all other underground piping work reinforced concrete pipe class NP2 of IS-458 (minimum) shall be provided.

b) All plant drains shall be of covered RCC construction and shall be rectangular or trapezoidal in shape depending upon the space available. Drains shall be provided with RCC slab covers if required from aesthetic and operational requirements. MS edge angles 50x50x6 shall be provided on the drain side walls supporting the cover slabs. The pre-cast cover slabs shall also be provided with MS flats/angles for edge protection. All culverts shall be equipped with headwalls and aprons at both the upstream and downstream ends. Wherever vehicular or other loading is anticipated to occur over drain covers, these shall be designed for it. Beyond the plant boundary, the drains can be of Brick work/masonry without covers.

c) The general site drainage system shall be designed for a 1 in 50 year frequency rainfall event for the power block area and for the main access roads.

d) Culvert wall thickness shall be sized to provide adequate strength and allow for corrosion protection over the unit lifetime. The opening shall be sized to carry the design flow most efficiently accounting for the constraints of the discharge channel and the embankment.

e) All runoff from outside area flowing through the site shall be suitably diverted to the natural drainage system by constructing the open channels, underground pipes or closed channels as per site requirement. The natural drainage system may need to be modified to take care the additional discharge from the site.

f) The plant area drainage shall be designed to cater to storm water run off resulting from a three (3) hour storm or 1 hour rainfall intensity with a return period of 50 years which ever is higher. The three (3) hour values shall be based on the recommendation of Indian Meteorological Department (IMD).

g) The plant storm water drainage shall be designed taking into account the finished grade levels of the plant and invert levels of existing drains, area drainage pattern within and outside plant area, intensity of rainfall etc. The maximum velocity for pipe drains and open drains shall be limited to 2.4 m/sec and 1.8 m/sec respectively. However, minimum velocity of 0.6/sec. for self cleansing shall be ensured. Bed slope not milder than 1 in 1000 shall be provided.

## Road Drainage

a) Runoff from onsite road roadbeds and other embankments shall be collected and directed to general site drainage. Roads and their embankments shall be sloped to drain to toe drains which shall collect and transport the runoff. Intermediate culverts shall convey runoff through embankment fills.

b) Toe drains and culverts shall be designed as described in general site drainage. Drainage system study within plant boundary as well as outside the plant boundary shall be carried out.

## 9.1.5 Drains and Plumbing

## i) General

The drains and plumbing system shall carry contaminated and other waste fluids by gravity to a waste collection and treatment system through an over ground piping system and embedded underground pipes.

## ii) Major Components

The drains and plumbing system shall consist of the following major components:-

a) Roof drains.

b) Trenches, floor, equipment, and oil drains.

c) Hot drains.

d) Plumbing.

## iii) Description

a) The drains and plumbing system shall consist of drain trenches covered with precast RCC covers or gratings, floor drains, feeder drain pipes, down comers, bell-ups, inspection chambers/manholes with covers, main pipe headers, and supply piping. This system, along with the interfacing waste collection and treatment systems shall drain the floor drains and fixtures to the proper drainage or treatment facility.

b) All components of the drains and plumbing system shall be designed to ensure efficient drainage of the associated areas or equipment.

The water or storm drainage facilities and piping shall be located at elevations to allow gravity drainage adequately.

## iv) Roof Drains Design Criteria

a) The roof drains shall transport rainfall runoff from roofs to the grading and storm water runoff drainage system.

b) The roof drains shall be sized for the roof area runoff for a maximum rainfall per hour at site. Fixing of rain water gutters and down pipes for roof drainage shall conform to IS-2527.

## Plumbing Design Criteria

a) The plumbing shall consist of all the hot and cold water supply distribution piping from the potable water header connection to and including the plumbing fixtures. The plumbing fixtures shall include water heaters, lavatories, urinals, toilets, etc. The plumbing shall be rigidly anchored to walls and steel with suitable pipe hangers or wall brackets. All plumbing materials and fixtures shall be of the best quality and make conforming to relevant IS codes with water conserving features and shall be as approved by Purchaser.

b) The plumbing shall be sufficient to supply the quantity of water required by the plumbing fixtures. All plumbing work shall correspond to IS-2065 and IS-1172.

c) The design, layout, construction etc of drains for waste-water, surface water and sewage together with connections, manholes, inspection chambers etc., used within the building and from the building to the septic tank or treatment works shall conform to IS-1742.

## 9.1.6 Concrete/Steel Structural Design

## 9.1.6.1 Codes and standards

All design criteria must conform to the latest edition of the Indian codes and standards or other Internationally accepted standards which ensure a quality equal to or higher than the Indian standards unless otherwise specified.

## Indian Standards

Different Bureau of Indian standards codes (IS)

<sup>•</sup> Special publications (SP)

Indian Road Congress standards (IRC)

<sup>•</sup> National Building Codes (NBC)

If any, standard/ clauses of the standard contains a provision which is inconsistent with a provision in Indian standard, the more stringent requirement as per the interpretation of the Owner/Purchaser shall prevail. All design work shall be carried out on the basis of latest edition of applicable codes and standards mentioned.

## 9.1.6.2 Natural Phenomena Design Criteria

The design criteria based on the natural phenomena (wind speed, seismicity, ambient temperature and relative humidity) are discussed below.

## Wind speed

a) The basic wind speed shall be based on IS: 875 (part 3). This basic wind speed shall be used to determine wind load for all structures.

b) All structures shall be designed for wind forces in accordance with IS: 875 (Part 3) for site specific information with reference to basic wind speed $\mathrm { V _ { b } }$ at 10 metres above mean ground level. The risk co-efficient K1 & category of terrain, but notwithstanding the values of the above mentioned parameters, the design wind pressure so computed at any point shall not be taken less than 1500 N/sq.m for all classes of structures, i.e. A, B & C as defined in IS-875(Part 3).

c) Along wind forces shall generally be computed by peak (ie 3 second gust) wind speed method. Along wind forces for slender & wind sensitive structures shall be computed for dynamic effects using gust factor or gust effectiveness factor method. The structure shall be designed for higher of the forces obtained from gust factor method and the peak wind speed method.

d) Analysis for dynamic effects of wind must be undertaken for any structure which has a height to minimum lateral dimension ratio greater than 5 & if fundamental frequency of structure is less than 1 HZ.

e) Susceptibility of structure to across wind forces, galloping, flutter/ovalling etc. be examined and designed/detailed as per recommendations of IS: 875 (Part 3).

f) The size & relative position of other structures likely to enhance wind loading on structure under consideration shall be considered. Enhancement factor, if necessary, shall be estimated and applied to wind loading.

## g) Damping in structures

The damping factors to be adopted shall not be more than as indicated below:

Welded steel structures 1.0%   
Belted steel structures 2.0%   
Reinforced steel structures 1.6%   
Steel stacks As per IS:6533 & CICIND model code whichever is more critical

## ii) Seismicity

a) The zone factor as per IS: 1893 shall be applied for the plant site.

b) The seismic risk zone for this site determined from the IS : 1893. Seismic loading shall be used in the design of structures. Wind load and seismic load shall not be considered to act simultaneously. Under seismic condition, the whole frame except the roof, shall be assumed loaded with 50% design live load. No further reduction in column live load shall be considered as per clause 1.7.2.1 under seismic conditions. Dynamic analysis of buildings and structures shall be carried out in accordance with clause 7.8 of IS 1893.

c) All structures and equipment shall be designed for seismic forces adopting the site specific seismic information provided in IS: codes and using the other provisions in accordance with IS: 1893 (Part 1): 2002 and IS: 1893 (part 4) : 2005. Pending finalization of Parts 2,3 and 5 of IS : 1893, provisions of part 1 shall be read along with the relevant clauses of IS : 1893 : 1984, for structures other than the buildings and industrial structures including stack-like structures.

d) A site specific seismic study shall be conducted for project site. The peak ground horizontal acceleration for the project site, the site specific acceleration spectral coefficients ( in units of gravity acceleration ‘g’) in the horizontal direction for the various damping values and the multiplying factor (to be used over the spectral coefficients) shall be modified as per IS 1893 (Part 4):2005.

Alternatively, in the areas not covered in high seismic zones (zone 4 & 5) and if there is paucity of time, the data of IS: 1893 can be adopted.

e) Horizontal seismic acceleration spectral coefficients in units of $\mathbf { \dot { g } } ^ { \mathbf { \prime } }$ (Site Specific)
<table><tr><td rowspan=1 colspan=1>Period</td><td rowspan=1 colspan=6>Damping factor (as percentage of critical damping)</td></tr><tr><td rowspan=1 colspan=1>Sec</td><td rowspan=1 colspan=1>0.8%</td><td rowspan=1 colspan=1>1%</td><td rowspan=1 colspan=1>1.6%</td><td rowspan=1 colspan=1>2%</td><td rowspan=1 colspan=1>3%</td><td rowspan=1 colspan=1>5%</td></tr><tr><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr></table>

f) Vertical acceleration spectral values shall be taken as $2 / 3 ^ { \mathrm { r d } }$ of the corresponding horizontal values.

g) The site specific design acceleration spectra shall be used in place of the response acceleration spectra, given at figure-2 in IS : 1893 (Part 1) and Annex B of IS : 1893 (Part 4). The site specific acceleration spectra along with multiplying factors specified in Annexure-1 includes the effect of the seismic environment of the site, the importance factor related to the structures and the response reduction factor. Hence, the design spectra do not require any further consideration of the zone factor (Z), the important factor (I) and response reduction factor (R) as used in the IS : 1893 (Part 1 and Part 4).

## h) Damping in Structures

The damping factor ( as a percentage of critical damping) to be adopted shall not be more than as indicated below for :

<table><tr><td>Steel structures</td><td></td><td>2%</td></tr><tr><td>Reinforced Concrete structures :</td><td></td><td>5%</td></tr><tr><td>Reinforced Concrete Stacks</td><td></td><td>3%</td></tr><tr><td>Steel stacks</td><td></td><td>2%</td></tr></table>

## i) Method of Analysis

1) Since most structures in a power plant are irregular in shape and have irregular distribution of mass and stiffness, dynamic analysis for obtaining the design seismic forces shall be carried out using the response spectrum method. The number of vibration modes used in the analysis shall be such that the sum total of modal masses of all modes considered is at least 90 percent of the total seismic mass and shall meet requirements of IS : 1893 (Part 1). Modal combination of the peak response quantities shall be performed as per Complete Quadratic Combination (CQC) method or by an acceptable alternative as per IS : 1893 (Part 1).

2) In general, seismic analysis shall be performed for the three orthogonal (two principal horizontal and one vertical) components of earthquake motion. The seismic response from the three components shall be combined as specified in IS : 1893 (Part1 ).

3) For regular type general buildings, IS 1893 Part 1 can be followed for enhancement of Base shear as per empirical time period Clause 7.8.2 of IS 1893 Part 1.

Industrial buildings shall be designed as per IS 1893 Part -4.

4) Further, the spectral acceleration coefficient shall get restricted to the peak spectral value if the fundamental natural period of the structure falls to the left of the peak in the spectral acceleration curve.

## j) Design/Detailing for Ductility for Structures

The site specific design acceleration spectra is a reduced spectra and has an inbuilt allowance for ductility. Structures shall be engineered and detailed in accordance with IS:800-2007 for steel structure and as per IS: 13920 for RCC structures to achieve ductility.

## iii) Temperature

Systems and system component design criteria which require ambient temperature extremes shall use the range from minimum to maximum temperature existing at site for dry-bulb temperatures.

## iv) Relative humidity

i) Absolute maximum 100%

ii) Highest monthly mean As per site condition

## 9.1.6.3 Design Loads

Design loads for all structures shall be determined according to the criteria described below, unless the applicable Indian building code requires more severe design conditions.

## i) Dead loads

Dead loads shall consist of the weights of the structure and all equipment of a permanent or semi-permanent nature including tanks, silos, bins, wall panels, partitions, roofing, piping, drains, electrical trays, bus ducts, and the contents of tanks measured at full capacity. However, the contents of tanks and other loads of semi-permanent nature shall not be considered as effective in resisting column uplift, overturning and sliding.

## ii) Live loads

a) Live loads shall consist of uniform live loads and equipment live loads. Uniform live loads are assumed unit loads which are sufficient to provide for movable and transitory loads, such as the weight of people, portable equipment and tools, planking and small equipment, or parts which may be moved over or placed on floors during maintenance operations. These uniform live loads should not be applied to floor areas which shall be permanently covered with equipment.

b) Equipment live loads are calculated loads based upon the actual weight and size of the equipment and parts to be placed on floors during dismantling and maintenance, or to be temporarily placed on or moved over floors during installation.

c) Floors and supporting members which are subject to heavy equipment live loads shall be designed on the basis of the weight of the equipment in addition to a uniform load of 500 kg/m<sup>2</sup>, or specifically defined live loads, whichever is greater. Each member in the floor which may carry these loads shall be designed for the heaviest piece or pieces of equipment arranged in the most critical position. For loads caused by moving equipment over the floor for installation, consideration shall be given to the shoring of beams and floor from floors below. When moving equipment over floors for installation, stress increases of 25 percent are permitted in beams and columns.

## d) Live loads shall be used as follows:-

Areas designated for different loadings on the same floor shall be clearly and permanently marked.
<table><tr><td rowspan=1 colspan=1>Description</td><td rowspan=1 colspan=1>Floor slabs</td></tr><tr><td rowspan=1 colspan=1>Grade floors slabs</td><td rowspan=1 colspan=1>1500 kg/m² (minimum)</td></tr><tr><td rowspan=1 colspan=1>Maintenance area in groundfloor</td><td rowspan=1 colspan=1>3000 kg/m²</td></tr><tr><td rowspan=1 colspan=1>Storage areas</td><td rowspan=1 colspan=1>Actual load of stored material or 1500 kg/m²(minimum)</td></tr><tr><td rowspan=1 colspan=1>Suspended floors andcontrol room floor</td><td rowspan=1 colspan=1>1500 kg/m² (minimum ) or actual whichever ishigher</td></tr><tr><td rowspan=1 colspan=1>Roofs (concrete slab)</td><td rowspan=1 colspan=1>As per IS:875.</td></tr><tr><td rowspan=1 colspan=1>Steel grating / chequeredplate platforms</td><td rowspan=1 colspan=1>500 kg/m² for grating/ chequered plate500 kg/m² for supporting beams</td></tr><tr><td rowspan=1 colspan=1>Inclined Roof</td><td rowspan=1 colspan=1>As per IS – 875 (Part-2)</td></tr></table>

## e) Column live loads

Live loads carried from the floors to the columns shall include 100 percent of the roof live load. In addition to the roof live load, the columns must carry floor live load. If the floor live load is 500 kg/m<sup>2</sup> or less, no reduction in live loads carried from the floors to the columns is allowed. If the floor live load is greater than 500 kg/m<sup>2</sup>, reduction in live loads carried from the floors to the columns shall be considered as per clause 3.2 of IS-875 (Part-2) for design. However, reduction in live load from all floors to be carried by the member under consideration shall not exceed 20% irrespective of the codal provisions.

## iii) Impact loads

Impact loads shall be added to other loads for components supporting reciprocating or rotating machines, elevators, hoists, cranes, or other equipment creating dynamic forces. The following impact loads shall be used, unless analysis indicates higher or lower values:-

a) Elevators 100 % of lifted load.

b) Hoists and cranes:

<sup>•</sup> Vertical

25 % of the maximum static wheel load.

<sup>•</sup> Horizontal-lateral

20 % of the sum of the lifted load plus the weight of the hoisting component.

<sup>•</sup> Horizontal-longitudinal

10 % of the total moving load.

c) Rotating and reciprocating equipment

50 % of the machine weight

d) Hangers supporting floors and platforms

33 % of the sum of the dead load and reduced live load.

Steel members supporting boiler drum hangers 100 percent..

## iv) Equipment loads

Equipment loads shall be specifically determined and located. For major equipment, structural members and bases shall be specifically located and designed to carry the equipment load into the structural system. For equipment weighing less than the live load, the structural system shall be designed for the live load. Equipment loads shall be noted in the design calculations to permit separation in calculation of uplift and stability.

## Access walkways, stair, handrails, and ladders

Design loads shall conform to the requirements of IS: 875 (part I and II) and the minimum requirements following, whichever are the most severe:

a) The walkways shall be designed for the dead loads of the structure plus a superimposed live load of 500 kg/m<sup>2</sup> uniformly distributed, or a concentrated load of 500 kg at any point, whichever produces the most severe effect.

b) Stair treads shall be designed for a distributed load of 225 kg/linear meter of tread width or a concentrated load of 100 kg, whichever produces the most severe effect.

c) Handrail forces shall be 100 kg applied outward at the center of the span and vertical between posts. Ladders shall be designed to withstand a line load of 100 kg or, alternatively, a number of line load units of 100 kg, the number of units and their spacing being in accordance with the anticipated usage of the ladder.

## vi) Test load

The test load shall be defined as the gravity load imposed by method necessary to test vessels, tanks, equipment or piping.

## vii) Wind loads

Wind load for all structures shall be based on IS: 875 (part 3). Basic wind speed shall be as specified in IS: 875(part-3).

## viii) Seismic loads

The seismic risk zone for the site shall be determined from IS: 1893. Under seismic condition, the whole frame except the roof shall be assumed loaded with dead load, super imposed dead load (SIDL) and 50% design live load. No further reduction in column live load shall be considered as per clause 5.3.2.1 under seismic condition.

## ix) Construction loads

The integrity of the structures shall be maintained without use of temporary framing struts or ties and cable bracing insofar as possible. However, construction or crane access considerations may dictate the use of temporary structural systems. Special studies shall be made and documented to ensure the stability and integrity of the structures during any periods involving use of temporary bracing systems.

## x) Estimated loads

Loadings imposed by equipment shall be specifically determined or estimated before detailed structural design. Estimated loadings shall be noted as such in hand calculations or computer input and verified as information is made final.

## xi) Dust Load

All buildings and structures shall be designed for dust load of 50 kg/m<sup>2</sup> wherever applicable.

## xii) Thermal load

Thermal loads shall be defined as forces caused by changes in temperature. The primary source of thermal loads in an industrial plant is the expansion or contraction of vessels and piping. Another source of thermal loads in a redundant structure is the expansion or contraction of the entire structure or individual structural components. For temperature loading calculation the total temperature variation shall be considered as 2/3 of the average maximum annual variation in temperature. The average maximum annual variation in temperature for this purpose shall be taken as the difference between the mean of daily minimum ambient temperature during the coldest month of the year and mean of deily maximum ambient temperature during the hottest month of the year. The structure shall be designed to withstand stresses due to 50% of the total temperature variation. Suitable expansion joints shall be provided in the longitudinal direction wherever necessary with provision of twin columns. The structures shall also be checked for temperature effects in the areas where the temperature rise is expected to be high.

## xiii) Future load

Loads from future expansion shall be considered when so directed by the purchaser./owner. Future loads may include any of the loads listed above.

## xiv) Surge load

Surge loads may occur in some vessels or equipment. In such cases, the magnitude and direction of the load shall be given by the equipment supplier.

xv) Miscellaneous load

Miscellaneous loads shall be defined as loads that do not fit into the categories listed in this section. Typical miscellaneous loads are loads, during erection, maintenance and repair.

For the design of individual structural components, realistic load combinations in accordance with the relevant design standards shall be considered.

All loadings considered in the design shall be justified with supporting details.

## 9.1.6.4 General Requirements

## 9.1.6.4.1 Design requirements

i) Reinforced concrete structures shall be designed in accordance with the latest Indian standards IS: 456- Building code requirements for reinforced concrete.

ii) Structural steel buildings shall be designed in accordance with latest IS – 800. “Building code requirements for steel buildings.”

iii) The design of all structures shall be such that differential and total settlements or other movements shall not exceed acceptable limits and full provision shall be made for all expansion and other joints.

iv) Structural members subjected to flexure shall be designed to have adequate stiffness to limit deflections or any deformations that affect strength or serviceability of a structure adversely. The maximum allowable deflections of structural members shall be in accordance with the relevant design standards and/or the limits prescribed by the machinery manufacturers (whichever is less).

v) The superstructures and foundations subjected to vibrations (the primary source of these vibrations being the unbalanced forces generated by rotating or reciprocating equipment) shall be designed such that vibrations will be neither intolerable nor troublesome to personnel and will not cause damage to the machine or structure.

vi) The natural frequency of the whole of the superstructures and foundations or parts thereof and all structures adjacent thereto shall not coincide with the operating frequency of the vibrating equipment.

vii) The differences between frequencies and the dynamic analysis of the superstructures and foundations shall be in accordance with the relevant design standard.

viii) The dimensions of all the buildings shall be such as to provide adequate space for the safe installation and proper operation, maintenance and repair of all plant and equipment.

## 9.1.6.4.2 Design of steel connections

i) Fabrication drawings shall be prepared according to the provision of IS: 800, IS: 816, IS: 9595, IS: 1367 and IS: 9178.

ii) Connection of vertical bracings with connecting members and diagonals of truss members shall be designed for full tensile capacity of the bracings.

iii) Size of fillet weld for flange to web connection for built-up section shall be as follows:-

a) Full shear capacity or actual shear whichever is more for box section.

b) 80% of full shear capacity or actual shear or 0.5 times of the web thickness whichever is more for I section weld shall be double fillet.

c) All welds shall be continuous. The minimum size of the fillet weld shall be 6 mm.

iv) Shear connections shall be designed for 75% of section strength or actual shear for rolled sections and 80% of section strength or actual shear whichever is higher for built-up section or rolled section with cover plates.

Moment connections between beam and column shall be designed for 120% of moment capacity of the beam section as per IS:800-2007 to provide ductility to structure.

vi) All butt-welds shall be full penetration butt-welds.

vii) The connection between top flange and web of crane girder shall be full penetration butt-weld and for bottom flange, connection may be fillet weld.

viii) Connection of base plate and gusset members with the columns shall be done considering that total load gets transferred through weld.

ix) Splicing: All splicing work shall be full strength. Field splicing shall be done with web/flange cover plates. For exceptional cases, the field splicing shall be designed for 50% of load carried by the cover plates and remaining 50% load through full penetration butt-weld. Shop splicing for all sections other than rolled shall be carried out by full penetration butt-welds with no cover plates. Splicing for all rolled sections shall be carried out using web and flange cover plate. Connections shall be designed as per IS 800-2007.

## 9.1.7 Foundations

## 9.1.7.1 Foundations for Building

## i) General

a) Detailed geo-technical investigation shall be required to be carried out to ascertain the safe bearing capacity and appropriate type of foundation for heavy equipment and structures.

b) The geo-technical exploration, testing and analysis information shall be used to determine the most suitable bearing method to support each foundation. The bearing method may include engineered fill, piling, drilled shafts, pressure injected footings or soil densification.

## ii) Bearing capacity

The foundations shall be designed for the following factors of safety:-

Shallow foundations : 3.0

Deep foundation systems 2.0

## iii) Settlement criteria

Allowable settlements, elastic plus consolidation, shall be limited as follows:-

For foundation of Tall Steel Structures e.g. Crusher house, Transfer point, Conveyor Trestle, etc. the total settlement may generally limited to 25 mm and Differential settlement to 6mm.

For other buildings:-

Total settlement 38 mm

Differential settlement : 6 mm

Foundations for equipment shall be designed to meet the total and differential settlement established by the equipment manufacturer if they are more stringent than

the allowable settlements listed above. Foundations for buildings shall be designed to meet the total and differential settlement as required for the building function if they are more stringent than the allowable settlements listed above.

## iv) Settlement and expansion joints

a) Joints are to be arranged in such a way that stresses and strains caused by settlements, temperature, differential settlement, etc do not adversely affect the structures. This primarily applies to differently loaded areas and structures having different foundations or foundations of different depths. The settlement joints shall run through the complete structure down to foundation level, the expansion joints however shall stop on the top level of foundations.

b) The joint width which is to be at least 2 cm is to be planned considering all relevant factors (settlements, tilting, movements, aspects etc.).

c) Settlements of all relevant structures shall be measured, recorded and shown in diagrams according to IS: 8009 – “Code of practice for calculation of settlement of foundation”.

## v) Foundations at different depths

Foundations at different levels should be based beyond a load spread angle of /30<sup>°</sup> (against the horizontal). Otherwise, the load influence (e.g. earth pressure) of the higher level structures on the lower ones must be taken into consideration.

## vi) Safety against uplift

For all parts of the structures extending into the ground water, safety against uplift has to be guaranteed during all execution stages, especially when ground water lowering is terminated.

## vii) Shallow foundations

Shallow foundations shall rest on the natural bearing soil. For this kind of foundation especially the following standard is to be applied:

IS: 1080 Code of practice for design and construction of shallow foundations on soil

IS: 6403 Code of practice for determination of bearing capacity of shallow foundations

## viii) Pile Foundations

The pile foundation shall be of cast-in-situ bored piles as per IS: 2911 or approved international standard (relevant part).

a) Only RCC piles shall be provided.

b) Minimum diameter of bored piles generally shall be 450 mm. The allowable load carrying capacity of the pile in vertical compression shall be limited to its structural capacity. The uplift and lateral load capacities shall be restricted to 20% and 5% respectively of the allowable load capacity in vertical compression. However, the pile capacities to be adopted shall be the least of the estimated design values and that obtained from the pile load tests. Maximum permissible lateral deflection at pile head shall be 5.0 mm.

c) Only straight piles shall be used.Raker piles may be adopted where horizontal load is predominant.

d) The piling work shall be carried out in accordance with the provisions of IS: 2911 (relevant part) or approved Inter- national Standard and approved construction methodology.

e) The pile shall be tested for vertical, lateral and uplift capacity. The safe load shall be as per IS \_ 2911 (Part-IV).

## 9.1.7.2 Foundation for rotating Equipment

## Special foundation requirements for rotating equipment

i) The foundation systems for rotating equipment shall be sized and proportioned not to exceed the bearing and settlement criteria and to assure satisfactory performance of the equipment. In addition to a static analysis, a dynamic analysis shall be performed to determine the fundamental frequencies of the foundation system. To preclude resonance, the fundamental frequency of the foundation shall be 20 percent removed from the operational frequency of the equipment. The dynamic behavior of the foundation shall meet the requirements of IS: 2974 (part I to IV) – Code of practice for design and construction of machine foundations.

ii) All rotating equipment shall be provided with rigid foundation system or vibration isolation spring system mounted foundations. The vibration isolation system supplied should be of proven make, consisting of steel helical spring units and viscous dampers (providing damping resistance in all three planes).

iii) For minor equipments supported on building structures, floors etc. suitable vibration isolation shall be provided.

## 9.1.8 Underground Structures

## 9.1.8.1 Loads

In addition to other loads, the following loads shall also be considered for underground structures:-

## i) Earth pressure

Earth pressure for all underground structures shall be calculated using co-efficient of earth pressure at rest, co-efficient of active or passive earth pressure (whichever is applicable).

## ii) Ground water pressure

Ground water pressure due to the highest water table at the location shall be considered.

## iii) Surcharge load

Minimum surcharge load of 20 kN/m<sup>2</sup> shall be considered for the design of all underground structures located in the vicinity affected by vehicular traffic; including channels, sumps, cable and pipe trenches etc to provide for increase in earth pressure due to vehicular traffic; or else a minimum surcharge load of 5KN/m2 should be applied including channels, sumps, cable and pipe trenches etc. to provide for increase in earth pressure due to vehicular traffic.

## iv) Hydrostatic load and buoyancy

Hydrostatic load is the load due to water pressure. The design of structures shall include hydrostatic loads when applicable. The buoyancy load is equal to the weight of the volume of displaced water.

## Design Concepts

i) RCC water retaining structures like storage tanks shall be designed as uncracked section in accordance with IS:3370 (Part-1 to IV) by working stress method. However, fore-bay, water channels and substructure of pump houses shall be designed as cracked section with limited steel stress as per IS: 3370 (Part 1 to IV) by working stress method.

ii) For design of all underground structures foundations/ground water table shall be assumed at level emphasized as per soil test report in respect of water table for that area.

iii) Earth pressure for all underground structures shall be calculated using coefficient of earth pressure at rest. Co-efficient of active or passive earth pressure whichever is applicable depending upon the structural configuration. However, for the design of sub-structure of pump houses, earth pressure at rest shall be considered.

iv) For design of all underground structures/foundations, ground water tables shall be assumed at the finished ground level unless specified otherwise.

v) Earth pressure for all underground structures shall be calculated using coefficient of earth pressure at rest, co-efficient of active or passive earth pressure whichever is applicable depending upon the structural configuration. However, for the design of sub structure of pump houses, earth pressure at rest shall be considered.

## Liquid Retaining/Conveying Structures

i) All RCC liquid retaining/conveying structures shall be designed as uncracked sections with reduced steel stresses in accordance with IS : 3370.

ii) All water retaining structures shall be tested for water tightness as per the provisions of IS : 3370 and IS : 6494 and chemical injection grouting to be provided, incase required.

Substructures of Pump Houses, channels/tanks and other underground structures containing liquid, the following conditions shall be considered in addition to loading from super structure for design of sub structure.

i) Water pressure from inside upto full height and no pressure from outside.

ii) Earth pressure, surcharge pressure and ground water pressure from outside and no water pressure from inside.

iii) Base slab of pump houses shall also be designed for different combinations of pump sumps being empty during maintenance stages with ground water level at finished ground level.

iv) All pump houses/sub structures shall be checked for stability against sliding during construction. In case where dead load provides the storing moment, only 0.90 times the characteristics dead load shall be considered. Factor of safety shall not be less than 1.40 under most combinations.

v) All pump house/sub structures shall be checked for stability against over turning and shall not be less than 1.20 due to dead load.

vi) Design against uplift due to ground water table at finished level during construction with minimum factor of safety of 1.20 against uplift considering 0.9 times dead load. Inclined wedge action shall be limited to 15 degree. Factor of safety of 1.0 shall be considered for dead weight of structure and earth resting on sides in vertical plane with provisions of pressure relieve valves/flaps valves etc. shall not be permitted to counter the buoyancy. The inclined wedge not considered.

Following loading conditions shall be considered, in addition to the loading from super structure for the design of sub structure of pump house, channels, sumps, tanks, trenches, tunnels and other underground structures :

i) Water pressure from inside and no earth pressure, ground water pressure & surcharge pressure from outside (applicable only to structures which ate liable to b e filled up with water or any other liquid).

ii) Earth pressure, surcharge pressure and ground water pressure from outside and no water pressure from inside.

a) Design shall also be checked against buoyancy due to the ground water during construction and after construction and after construction stages. Minimum factor of safety as per IS : 3370 against buoyancy shall be ensured considering empty condition inside and ignoring the superimposed loadings. For safety against buoyancy, pressure release valves can be provided as per relevant IS code if mixing of ground water with stored water does not affect the system adversely.

Base slab and piers of the pump houses shall also be designed for the condition of different combination of pump sumps being empty during maintenance stages with maximum ground water level.

For structures affected by mobile crane load movement underground structures in Foundation, Tunnels, Trench shall be designed for full mobile crane load or additional surcharge of 5.9 T/m<sup>2</sup>.

Intermediate dividing pier of pump sumps and partition wall (if applicable) in channel shall be designed considering water on one side only and other side being empty for maintenance.

All pump houses and other substructures (wherever applicable) shall be checked for stability against sliding and overturning during construction as well as operating conditions for various combinations of loads. Factor of safety for these cases shall be taken as mentioned in relevant IS Codes or as stipulated elsewhere in this specification

## Overground Structures

The design of steel structures shall be done by working stress method. Design and fabrication shall be as per provisions of IS : 800 and other relevant IS standards. Structural member shall be of minimum 6 mm thickness. For design of coal binds and ash hoppers, IS : 9178 (Part – 1 to III) shall also be followed.

Welding shall be used for fabrication and joints. For site connections, welding or High Strength Friction Grip (HSFG) bolts shall be used. In few cases for shear connection or removable beam connections, bolted joints with M.S. block bolts may be adopted. For HSFG bolt connection, IS : 4000 shall be followed. IS : 816 and IS : 9595 shall be followed for welding of structures. Welding shall be of minimum 6 mm thickness.

iii) Trestles supporting coal/ash conveyor galleries shall be so proportioned that the transverse deflection of trestles due to wind/seismic load shall not exceed trestle height/1000 as stipulated in IS : 11592. The crusher and transfer house structures shall be so designed that transverse deflection at places where conveyor galleries meet, should be equal to the respective transverse deflection of conveyor supporting trestles.

iv) All structures close to railway line shall have clearances conforming to Railway norms.

v) The following loads are considered for design :

a) Density of bottom ash shall be 650 kg/cu.m. for volume calculations.

b) Density of bottom ash shall be 1600 kg/cu.m. for load calculations.

c) Density of fly ash shall be 750 kg/cu.m. for volume calculations.

d) Density of fly ash shall be 1600 kg/cu.m. for load calculations.

e) Density of dry fly ash to be considered for design of supporting structures for dry fly ash conveying pipes shall be taken as 1000 kg/cu.m. The pipes shall be considered with dry fly ash.

vi) The design and construction of RCC structures shall be carried out as per IS : 456. Working stress method shall be adopted for the design wherever specifically mentioned.

vii) For design and construction of steel-concrete composite members, IS : 11384 shall be followed.

viii) A minimum clearance (clear head room) of 8 M shall be kept for all road/rail crossing and in other areas as specified elsewhere for all pipe/cable galleries conveyors etc. Before and after the crossings, barrier of suitable height shall be constructed so as to prevent the approach of cranes having height more than 8 M etc. upto the pipe/cable racks.

## 9.2 SPECIFIC REQUIREMENTS

## 9.2.1 Coal Handling Plant

## i) Track Hopper

The track hopper extends more than 10 m below ground level and has to withstand considerable earth pressure. If the ground water level is high, precautions have to be taken to prevent empty hoppers tendency to float by increasing the dead weight of whole construction or increase the width of base slab and use weight of soil above the projections to counteract the tendency. The beams supporting track over hopper should be as narrow as practicable so that discharge coal from railway wagons is not impeded.

## ii) Wagon Tippler Hopper

Wagon Tippler Hopper shall be of RCC underground structure of required length & size as per design. The wagon tippler hopper is designed as per criteria for design of reinforced concrete bins for the storage of granular and powdery materials as per IS : 4995 Part – 1-1974 “General Requirements and Assessment of Bin Loads.” and Part-II , “Design Criteria”.

The wagon tippler and conveyor tunnels shall be provided with adequate slopes and sumps for dewatering. The spacing of sumps shall not exceed 50 meters. The wagon tippler hopper shall be provided with structural steel shed for full length with roof and side cladding with colour coated steel sheeting.

## iii) Reclaim Hopper

Reclaim hopper shall consist of RCC hoppers with liners and steel bar grid at top designed for passage of dozer. A structural steel shed above reclaim hopper shall be provided. It is part underground & part over ground structure.

## iv) Underground Works

All the conveyor tunnels shall be designed for dozer load of approximately 36 Tons or to withstand movement of crane 150 Ton self weight. Suitable inserts at 3 m intervals shall be embedded in both sides and undersides for supporting cables. Drains of 250 mm depth shall be provided for drainage of tunnels and sump pits at 50 m intervals of 1.5 m deep. The clear head room of 2.5 m shall be provided in tunnels.

## v) Transfer Points/Drive House

Transfer points shall be in steel framed construction with pre-coated galvanized steel sheeting above 2 m and brick work below 2 m. Floors of all transfer points shall be in RCC. Independent staircase shall be provided to all transfer points with landing facility at all floors. The underground transfer points shall be completely in RCC construction with brick wall cladding above ground.

## vi) Conveyor Tunnels

All conveyor tunnels shall be designed for dozer load of approximately 36 tons or to withstand movement of crane with loads of cranes as per manufacture. Crushers shall be supported on spring and Visco-damper system. Suitable inserts at 3 m intervals shall be embedded in both sides and underside for supporting cables. Drains of 250 mm depth shall be provided for drainage of tunnels and with sump pits at 50 m intervals of 1.5 m depth. The height of tunnels shall not be less than 2.5 m.

All conveyor tunnels shall be designed to withstand the load due to movement of crane having 150 T self wt. at a maximum speed of 5 km/Hr.

## vii) Crusher House

The crusher house building shall be provided with number of floors. The building super structure shall be of structural steel frame. All flooring in crusher house shall be of RCC. Crusher equipment foundation shall be in RCC and provided with independent building structure and foundations to avoid transfer of vibrations to crusher house building. The crusher foundations shall be provided with spring and Visco-damper system. Crusher house building shall be provided with brick walls upto 2 m from ground floor and side cladding thereafter. Equipment hatch with removable grating shall be provided. The lift beam shall extend 2 m outside the crusher house for removal of equipment to ground.

## viii) General Design Requirements

Bulk density of coal shall be taken as 800 kg/m<sup>3</sup> for capacity calculation and 1050 kg/m<sup>3</sup> for stress on structure for Structural Design. For calculation of coal load on moving conveyor, a multiplication factor of 1.60 shall be used to take care of inertial forces, over burden and impact factor.

For Rail tracks passing over wagon tippler hopper/tunnels/loco having 160 T self weight & with 60 fully loaded wagons having 110 T gross weight of each wagon shall be considered.

## ix) Galleries and Trestles

a) Galleries, trestles, transfer points, buildings shall be designed to withstand wind pressure as per BIS Codes. The conveyor gallery structure & trestles shall be designed considering both conveyors operating simultaneously.

b) Dynamic analysis of conveyor galleries and conveyor supporting system shall be carried out for spans greater than 25 m.

c) Permissible deflection for latticed frame work floor beams shall be span/325 minimum clear head room of 2.50 m shall be provided in conveyor galleries, trestle spacing shall not exceed 15 m as far as possible.

d) The clearance between top of road and bottom of conveyor gallery where crane is likely to pass shall be 8 meters minimum.

e) 3.15 mm thick seal plate shall be provided where gallery crosses roads/buildings/railway tracks extending additional 5 meters on both sides of crossing.

f) For all conveyor galleries, a minimum clear gap of 300 mm at top & 150 mm at bottom and side sheeting shall be provided for natural ventilation. The gallery roof shall be pre colour coated.

g) For natural lighting in conveyor gallery every sixth panel of side sheeting shall be provided with F&P translucent sheets which shall be staggered on opposite sides of gallery.

## x) Main switchgear cum Central Control Room

The complete CHP is operated from a building located near crusher house. It shall be RCC building of minimum size 15 m x 25 m. It will house MCC/electrical, battery room and control desk/mimic panel/relay panels. The space for MCC etc. shall be provided with exhaust ventilation system. Central control desk area shall be provided with false ceilings suitable for air conditioning.

Coal yard office & electrical maintenance room shall be provided on first floor with attached toilets & drinking water facilities. Coal yard office shall be air conditioned. All electrical buildings/control room shall have a clear head of 3.50 m (minimum) at all floors.

The Building shall be complete with toilets, drains, plumbing space conditioning for air conditioned area and false ceiling and glass panels.

## xi) Wagon Tippler/Track Hopper Control Building

Wagon Tipper/Track Hopper Control Building shall be located in Wagon Tippler/Track House Complex. & will house appropriate electricals such as MCC battery room at ground floor. The control room shall be located at first floor complete with glass panels all round to have full view of rake unloading (i) the building will be of RCC construction with air conditioning space to locate mimic panel weigh bridge control panel & space for operators.(ii) Space for MCC’s/Junction Boxes/other electrical equipment etc shall be provided with pressurized ventilation system. (iii) Ventilated Battery room and (iv)Two toilets & drinking water facility

## xi) Coal Stock Pile

The angle of repose for coal stock pile is assumed as $3 7 ^ { \mathrm { { \mathrm { { o } } } } }$ . The height of stock pile is assumed as 10 m height. Civil & Structural designing tunnels shall be suitable to cater to all loads due to passing of dozer which may weight upto 35 tonnes.

## 9.2.2 Ash Dyke

i) The ash dyke in the power plant is constructed with ash and is constructed in stages. The starter dyke around storage pond has a capacity to store ash for five years of plant life. The raising of dyke is done in stages of 3M. effective height increase. The starter dyke is constructed as an earthen embankment with excavated earth from ash pond area and is made strong enough to withstand load from all the future stages as well as the ultimate ash filling. The ultimate capacity of dyke is calculated for 25 years. The height varies depending upon the seismic zones topography, subsoil strata etc. And the top surface of ash is covered with good earth of about 0.3m.

ii ) 50 M. wide green belt is also to be provided all around the ash dyke

iii) The slurry accumulates within pond till water level reaches the design FRL i.e. 1.5 meter below dyke top in each phase.

iv) The upstream side slope shall be protected by 115 mm thick brick layer laid over a 50 mm thick sand cushion and 750 µm thick LDPE lining. Bottom of pond is provided with 300 mm thick sand layer over 500 µm thick LDPE layer. This layer protects the water entry from ash pond to dyke. The downstream side slope will be protected by 50 mm thick cast-in-situ concrete apron cast in panels of 1.50 m x 1.20 m approximately. A rock toe of 750 mm height using 100 mm – 400 mm thick graded stones laid over 150 mm thick sand graded filter will be provided in the toe. As per MOEF stipulations the liner material can be either natural or synthetic.

v) Discharge pipe in RCC encasing with PCC bedding shall be laid upto decantation wells. A steel bridge shall be provided over ash dyke upto decantation well and with steel trestle and concrete foundation. Decanted water with low percentage of ash from ash pond shall go to stilling pond by means of RCC collecting circular wells which are provided with vents at various levels, which can be blocked progressively as the level of ash settles in the pond rises. The water from the collecting wells in the stilling ponds is led to the ash water recovery system for further treatment by means of pipes

## vi) Ash Pond Stability Analysis

Seismicity :- The horizontal seismic coefficient is worked out taking 1.50 as Important factor as per IS : 1893 (Table-4).

The dyke is designed as homogeneous section. The soil parameters considered for stability analysis are found as per field investigations from field investigations . .The design parameters considered for stability analysis are Unit weight, cohesion, angle of internal friction for ash , bund fill material and Foundation. Top width of dyke is generally kept as 6.0 m Upstream dyke slope is generally kept as 2H :1 V and with no berm Downstream side slope is 2.25H :1VAt bottom and a berm of 1.5 m at intermediate level. The slope above berm is of 2H: 1V The upstream side slope is protected by 115 mm thick brick layer laid over a 50 mm thick sand cushion and 750 µm thick LDPE lining. This layer protects the water entry from ash pond to the dyke. The downstream side slope is protected by 50 mm thick cast-in-situ concrete apron cast in panels of 1.50 m x 1.20 m. A rock toe of 75 mm height using 100 – 400 mm thick graded stones laid over 150 mm thick sand graded filter is provided in toe. The slope stability analysis of dyke is carried by a suitable slope stability analysis software. FOS Static- sudden draw down -1.5 seismic- 1.0

a) The three loading conditions considered for stability analysis are empty stage condition with 10 KN/sq.m. on top width as surcharge and without earthquake forces and with earthquake forces.

b) Two stage loading with ash fill of 3 H : 1 vertical with forces/surcharge without earthquake and with earthquake.

c) Three stage loading with ash fill and 3 H :1 vertical with two road Berm’s with surcharge without earthquake forces and with earthquake forces.

## vii) Supports for ash pipes:

a) Over ground pipes shall be supported on RCC footing with top of RCC of pedestal at least +500 mm above ground level.

b) RCC culvert shall be constructed with culvert top generally not more than +100 mm above road.

c) For water body/Nallah suitable structural arrangement with 800 mm wide walkway shall be provided with minimum clearance of 1.50 m above highest flood level.

d) Centre to centre distance of pedestals for ash disposal pipes shall be designed on the basis of pipe diameters. Maximum centre to centre distance of supports shall be restricted to 7.0 m.

e) Thrust block shall be provided at locations where direction of ash pipe changes

## 9.2.3 Oil Tank foundations

Tank foundations can be of earth type foundation or concrete ring wall foundation. Pile foundation with raft/pile cap shall be provided where soil conditions are adverse or foundation can subside due to poor soil conditions. For earth foundation, tank is supported over compacted fill of gravel, coarse sand, over which 75 mm minimum compacted crushed stone, screenings/fine gravel, clean sand mixed in Hot Asphalt 8 to 10 percent by volume is laid, rolled & compacted in slope of 1 in 100 from centre of tank as detailed in IS : 803 – 1976.

## 9.2.4 Raw Water Reservoir

The raw water reservoir shall be provided with HDPE sheet at bottom & sides on a 100 mm thick cushion of sand. The lining shall be protected by 75 mm P.C.C. (M 15) cast-in-situ concrete in panels set on 25 mm thick 1:4 mortar. Side slope of 1:2 is generally provided for raw water reservoir.

## 9.2.5 Natural Draft Cooling Tower (NDCT)

NDCT shall be of reinforced concrete construction and of hyperbolic shape in vertical section and circular in plan. The analysis and design of NDCT is done considering wind and seismic loads in addition to dead and imposed loads. The effects of temperature & moisture variations are also considered. The cooling tower basin and structure shall be constructed of reinforced cement concrete. The tower basin shall be designed as uncracked section. Each basin is divided in two parts for hydrostatic pressure. All exposed surfaces of concrete viz,inside surface of tower basin, inner surface of shell, fill support beams, columns & bracings,raker column etc which are in contact with moisture/water shall be given three coats of water proof bituminous paint of approved make. All concrete surfaces which are in contact with earth shall be applied with anti corrosive coat system.

As specific requirement, natural draft cooling towers shall be designed for

1) Dead load

2) Imposed load (including construction loads)

3) Wind load

4) Earthquake loads

5) Thermal loads

## ii) Dead Loads

Dead loads shall include the weight of structure complete with finishes, fixtures and partitions and shall be as per IS 875 (Part – 1). Dead loads for NDCT shall include self weight of structure, weight of fill materials, weight due to algae growth, weight of drift eliminator, weight of falling water, weight of hot water pipe, weight of water in hot water channel and distribution system including the self weight of channel and distribution system.

iii) Imposed Loads :-

Imposed loads on various structures shall be as follows :
<table><tr><td rowspan=1 colspan=1>Basin, sump,duct  &amp;underground pipe</td><td rowspan=1 colspan=1>Besides earth pressure under dry and wet condition, anadditional surcharge of 2.0 T/m2 shall be taken.</td></tr><tr><td rowspan=1 colspan=1>Covers  for  hot  waterchannels HW distributionbasin</td><td rowspan=1 colspan=1>0.30 T/m2</td></tr><tr><td rowspan=1 colspan=1>Walkway     inside     CTdistribution basin</td><td rowspan=1 colspan=1>0.30 T/m2</td></tr></table>

## iv) Construction Loads

Temporary loadings likely to be imposed during construction shall also be considered in design of CT structures.

## v) Wind Load :-

Basic wind speed is taken at 10 m above mean retarding surface as per IS – 875.

Risk coefficients, terrain category, topography factor shall be k3 as per IS : 875. Wind loading shall be calculated as per gust effective factor (GEF) as well as by peak wind method & analysed for both the cases and designed for the most unfavourable condition & higher of the two values is adopted, while calculating wind load. The term ‘b’ shall be taken as diameter of the throat in Fig. 10g IS – 875 (Part 3) 1987.

For design of Raker columns, a load enhancement factor of 1.43 shall be applied to wind loading calculated to account for natural turbulence in the incident wind resulting from obstructions and as well as adjacent cooling tower.

The wind pressure distribution around shell shale be calculated as per Cosine Fourier given in Appendix A of IS – 11504. The actual design wind pressure is obtained by multiplying the basic wind pressure (Pz) by coefficient ‘p’ (as Appendix A) and the wind load enhancement factor 1.43 based on wind tunnel test; the total load enhancement factor will be taken as maximum of

i) 1.43

ii) factor as per wind tunnel test 1.10

For tower sizes more than 100 m height & 120 m in base diameter, acro-elastic model testing in wind tunnel shall be done as the wind pressure distribution suggested in Appendix ‘A’ of IS – 11504 is applicable for towers not more than 100 m in height & 120 m base diameter. The cooling towers in group shall be spaced at clear distance of not less than 0.50 times the base diameter of largest cooling tower in group.

A damping factor of 1% of critical damping shall be considered while analyzing the structure for wind induced ovalling oscillations as well as any dynamic phenomenon involving wind effects.

## vi) Earthquake Load

a) Seismic Zone as per IS : 1893 – 2002 shall be considered for evaluation of seismic forces.

b) The tower shall be designed with sufficient ductility.

c) Modern analysis using response spectrum method shall be done for design of tower, raker column/seismic loads.

## vii) Temperature Load :

(a) For temperature loading, the total temperature variation shall be considered as 2/3<sup>rd</sup> of average maximum annual variation in temperature.

The structure shall be designed to withstand stresses due to 50% of total temperature variation.

(b) Temperature effects due to solar radiation shall also be considered for one sided solar radiation effect.

(c) Detailed analysis of actual thermal gradient by considering temperatures inside the tower & outside ambient temperature variation of $3 ^ { 0 } \mathrm { C }$ to $5 0 ^ { 0 } ~ \mathrm { C }$ shall be carried out.. An effective temperature difference of at least $2 5 ^ { 0 } \mathrm { ~ C ~ }$ across shell thickness constant over the height and following a sine function along half the circumference shall be considered.

## viii) Method of Analysis

The analysis shall be carried out using a finite element modeling software. Design shall be carried out using working stress method as per IS – 11504 and IS : 456.

## ix) Foundation of Cooling Towers

a) Cooling tower shall be provided with suitable foundation & checked for uplift forces considering empty conditions with ground water table at finished ground. A minimum factor of safety of 1.20 against uplift shall be ensured.

b) Depth of basins shall be fixed to allow for proper flow of water by gravity upto CW.

## x) Liquid Retaining Structures

Design of cooling tower basin, sump, outlet channel, HW distribution basin,/HW channel shall be designed as per IS – 3370.

## xi) Shell Analysis & Design

(a) Shell shall be designed as per C1 – 6.3 of IS – 11504 & minimum grade of concrete shall be M-30.

(b) Bending analysis be carried out for shell using finite element.

(c) Boundary conditions shall be as outlined in 6.3.1 of IS – 11504.

(d) Provisions of IS : 2210, IS : 2204 & BS – 4485 shall also be followed.

## (e) Buckling of Tower Shells

Critical dynamic wind pressure & shell buckling shall be checked using dynamic wind pressure. The factor of safety against buckling shall not be less than 5 for completed tower.

(a) Cooling Tower shall be provided with external RC staircase leading to a heavy duty door giving access to the distribution system. Hand rails on both sides ofthe staircase shall be applied with anti-corrosive coating system.

(b) Approved walkways & platforms shall be provided inside the tower for safe and clear access to all sprayers and distribution pipes.

xii) Codes :

a) IS : 11504

b) (BS – 4485 Part 1 to IV) British Standard.

c) Cooling Tower Institute USA and other international Codes as applicable.

## 9.2.6 Induced Draft Cooling Tower

IDCT consists of R.C C basin for collection of cold water , it has a de-sledging sump and outlet channel. The floor of the basin shall be sloped 1:500 towards the drain sump. The flow of water shall be controlled with a stop log arrangement.

Raft type foundation shall be provided for columns. For superstructure the beams/slab etc shall be of M25 grade as per IS-456 The civil structures in contact with water shall be designed as per IS : 3370 .Cooling tower cells shall be of RCC Column, beams and walls. Cell division partition wall shall be cast in situ RCC or precast concrete block.. Hot water channel shall be of RCC covered with pre cast/ cast in situ concrete slab. Gear box and fan assembly shall be supported over beam. Dynamic load shall be considered for design of beams supporting fan. One RCC stair case on each side of cooling tower shall be provided at gable end.

## 9.2.7 Chimney

i) Design Criteria

The chimney shall be RCC Construction comprising of two nos. steel flues, one for each unit supported from floor at 40 m intervals starting from topmost floor at 6m below the top of chimney the support bracket and bearing assembly shall be bolted to the locally thickened portion of flue on the support platform with arrangement to cater for thermal movement of flue element and enclosed by wind shield of reinforced concrete shell. Internal and external platforms shall be provided not more than 40 m intervals and shall satisfy the requirements of high intensity aviation obstruction lights as per IS 4998/I.C.A.O. regulations, aviation lights are provided at three levels at 1/3, 2/3 and at top. Lightning protection, down conductors shall be provided as per Clause no 12 2. 3

Lightning protection, down conductors shall be provided as per Clause no.12.2.3 of IS:2309.

For chimney with brick lined flue, the thickness of brick wall is generally 230 mm & internal platforms are provided at 10m interval.

The chimney flues will be of mild steel/ corrosion resistant steel., with mineral wool insulation. Secured by G.I .Chicken wire mesh to insulate whole exterior of the flues.

The design & construction of steel chimney liners shall be based on published report by fossil power committee, power Division, ASCE.

The steel flues are supported from floor at elevation 6M below chimney top and restrained laterally and also at several levels by access/ restrained platforms. Corrosion allowance shall be considered over structural considerations. The chimney roof shall be of reinforced concrete & with provision for water proofing and acid by laying acid resistant tiles in acid resistant mortar.

Provision of chimney ventilation and rack & pinion elevator in the chimney is to be made.

Arrangements shall be provided for flue gas measuring instruments with necessary arrangement of earthing.

Opening in the shell shall be provided for duct work, access door etc. The total plan area of openings at a particular section shall not be more than 15% of plan area of concrete shell at that location. The maximum width of opening shall be limited to an angle of not more than 30 degree subtended at center of concrete shell. The extra reinforcement around opening shall be highest given in

a) IS \_ 4998 (Part 1)

b) ACI – 307

c) Reinforced concrete chimney and tower by M.Q. Pinfold. The valve & k1 shall be taken as 0.11 as per data on page No. 186 Minimum half the number of extra horizontal havs in shell around the opening to continue for circle round both faces and both sides.

## Materials

All material shall conform to IS Codes. However, the following shall apply :

The flue duct shall be of “COR TEN – B”. Top 10 M length of liner shall be fabricated from stainless steel grade 316 L.

## Platform supporting Structure

The floor supporting beams shall take support on shell by making a pocket in the shell and

Elastomeric bearings shall be provided below supporting beams. The platforms shall be designed for following loads

## 1) Dead Load

2) Live load on platforms during operation and maintenance ( 750 Kg/m2) for chequered plate & 500 Kg/m<sup>2</sup> for platform supporting beams

3) Construction Loads of 750 Kg/m<sup>2</sup>

4) Maximum deflection of platform beams shall be L/325.The Beams will be   
epoxy painted   
And as such no corrosion is taken into account

Foundation system shall be either bored cast in situ piles with pile cap or raft foundation. Circular cap or Raft shall be provided. Reference shall be made to CICIND Chimney book 2005, Design is based as per working stress method. Foundation will be designed for SRSS of across wind and concurrent along wind response.

Shall satisfy the requirement of aviation warning lights as per IS : 4988: I.C.A.O regulations & instructions issued by Director General of Civil Aviation. The minimum clear width shall be 1000 mm & minimum live load shall be 500 Kg/m<sup>2</sup>.

At roof level and all platform levels on upper surface 35 mm acid resistant tiles conforming to IS : 4457 over water proofing shall be provided. The average thickness shall be 10mm & shall be sloping outwards.

vi) Roll up Door

A rolling steel chain operated door of 4.0 m x 5.0 m shall be installed at base of shell for trucks could inside as per detail conforming to IS: 6248 “ Metal Rolling Shutters & rolling grids “

vii) Personnel/ Access Doors

A Steel door of size 1000 mm x 2100 mm shall provide access at grade level

A mild steel hatch shall be provided as an access to the roof of the chimney. It shall be constructed of two outer sheets not less than 3mm thick mild steel with Steel stiffeners and to withstand Live load of 300 Kg/m<sup>2</sup> . Hatch shall be painted with acid and heat resistant epoxy paint on both sides

Chimney Elevator within R.C.C shell with staircase shall be provided for transportation of personnel and equipment

x) Liner Hood /Cap

The Liner hood is fabricated from Cast iron or 10 mm thick stainless steel plate. It covers the annular area packed with insulation material between stainless steel flue cladding to protect insulation from surrounding flue gas environment

## xi) Acid Drains & Manholes

Due to condensation within flue, acid drains at base with provision of stainless steel pipes & the acid is lead to manholes which is diluted by flushing system

## xii) Chimney Roof & Roof Drainage

The roof is of R.C.C. slab supported on MS beams. Roof is sloped towards rainwater down take pipes for drainage within interior of the shell.

## xiii) Flue Support Arrangement

Alternatively, the flue shall be of “Top Hung” type & supported from top. Support bracket and bearing assembly shall be bolted to the locally thickened portion of the flue & in turn support the flue on the support platform. The arrangement shall cater to thermal movement of flue elements.

## xiv) Chimney Painting

The entire inside surface of shell for full height with acid & heat resistant black bitumen paint as per IS : 158 to give a point DFT not less than 150 micron. For outside surface, the shell shall be painted top 50 m, with acid and heat resistant paint in alternate bands of signal red and white colour. The remaining portion on the outside surface with synthetic enamel paint in alternative bands of signal red and white colour. The spacing and width of bands shall be as per I.C.A.O. Guidelines.

## xv) Platform Supporting Structure

The floor supporting beams shall take support on shell by making a pocket in the shell and elastomeric bearings shall be provided below supporting beams. The platforms shall be designed for following loads

## xvi) Flue Ducts

The function of chimney flue duct is to exhaust the combustion gases from the boiler. Flue ducts are designed to protect the chimney shell from high temperature, prenuve and corrosive abrasive properties of the gases & protected from weathering elements by means of aluminum cladding.

Resin bonded mineral coal insulation of density not less than 96 kg/cu.m. shall be laid in two layers composed of 40 mm & 25 mm thickness on external surface of steel flue. The insulation shall be tightly secured to the exterior surface of the liner by impaling them on studs welded to the surface at 450 mm c/c both horizontally & vertically. The studs shall extend minimum 25 mm beyond insulation and provided with circular or square speed washers. 20 gauge galvanized wire mesh with 25 mm hexagonal pattern conforming to IS : 3150 shall be wrapped around with minimum 150 mm overlap. The mesh is tied in place with 16 gauge GI wire at 300 mm centers.

Insulation for exposed portion of flue at top shall be 150 mm & in 2 to 3 layers with minimum density of 200 kg/cu.m.

The maximum deflection at top is limited to H 500 where “H” is the total height above foundation.

The lower values in the range of valves specified in IS-4998 (Part 1) for dynamic modulus of elasticity shall be taken.

The static modulus of elasticity of concrete shall be 5000 √fck.

Maximum spacing of reinforcement in shell shall not be more than 250 mm

Vertical bars shall be uniformly spaced.

## xvii) Permissible Stresses for Chimney Shell

The stresses in steel reinforcement & concrete shall not exceed limits as per cl. 7.0 of IS : 4998 – 1975. For Dead load + Wind the permissible stress in concrete shall not exceed 0.28 fck.

## xviii) General Criteria

1) The chimney flues will be corrosion resistant steel of type COR TEN B with mineral wool insulation outside.

2) The flues shall be sized to give effective nominal gas velocity of 20 m/sec. under design operating conditions. The height of chimney is dependent upon

a) Flue gas efflux velocity should be 25m/s.

b) Sulphur dioxide content of the flue gas calculated from sulphur content of fuel

c) Maximum burning rate of fuel

d) Topography of surrounding area

e) Height of adjacent buildings

f) Size of adjacent buildings.

g) The natural draught produced by chimney is dependent upon height of chimney, temperature difference between flue gas & external air.

h) Provision to be made for ducts to expand both circumferentially and vertically without producing stress in concrete chimney shell.

i) Thickness of flue duct shall be minimum 6 mm.

Internal and external platforms is generally provided at 40 m intervals .Internal platforms will be of structural steel supported over RCC shell. A Structural steel staircase is provided to access platforms.

An opening in windshield at ground level shall be provided for installation of flue with suitable door for access of personnel & trucks. Aviation obstruction lighting for warning aircraft of chimney obstruction shall be provided.

## xix)

## Basis of Design

The reinforced concrete twin flue chimney is designed in accordance with IS-4998(both 1975 & 1992 edition as applicable) and “Criteria for design of Reinforced concrete chimney for reference ACI-307-1979” “specification for design & construction of reinforced concrete chimney” for items not covered in Indian /CICIND Code (International Committee for Industrial Chimneys and stacks).

The chimney shell is modeled as Beam elements made of annular conical sections of appropriate diameter and thickness . Chimney foundation shall be in concrete grade M-25 with minimum cement concrete of 400 kg/cu.m & wind shield shall be grade M-30 with minimum cement content 425 kg/cum. 43 Grade OPC for concrete foundation & shell be used.

## xx)

## Loading and their Combinations

Dead load:- All permanent loads due to weight of chimney shell, internal platforms and lining supported on them, ladders, flue ducts, staircase etc.

Imposed load:-

(i) Imposed load on service platform around chimney shall be 500 kg/sqm & design live load shall be 750 kg/sq.m during construction / erection.

(ii) Imposed load from ducts joining the chimney shall be considered .

## xxi)

## Analysis

Calculation of natural frequencies and mode shape shall be carried out. For this purpose chimney shaft is idealized as vertical cantilever with limited masses at different nodes. These nodes shall be provided at each platform. Minimum five modes will be considered.

## a) Wind Loads :-

Wind load will be based on IS:4998(Part-I) and 875 (Part3) Dynamic analysis shall be carried out and stability ensured under such conditions.

## Along Wind Static Analysis

The basic wind speed ,terrain category, K1 & K2, K3 Values will be as per table 2 of IS:875 (part-3).

The gust factor will be calculated as per code IS:4998,(PartI). Dynamic modulus of elasticity of concrete as recommended in IS.4998(Part1) is used for calculating natural frequencies of chimney, Cd is taken as 0.80 for concrete shell, along wind respose of chimney shall be calculated as per gust factor method as in (A-5.1)& Simplified method as in A-4.10 of IS-4998-Part-1, for design, higher of the along wind loads shall be used.

## b) Across Wind

The across wind response of chimney will evaluated as per section A-4&A-5of IS-4998(Part-1). CL will be assumed as 0.16 & S=0.20. Higher of the two moments shall be considered for design of chimney .

## c) Ring Moments due to Wind

The circumferential ring moments due to wind is calculated as per clause 5.40 of IS:4998(Part 1); The wind induced stresses in concrete and steel shall be calculated as per cl.No D-2.2.7, D-2,.2.28 & D-2.2.29 of IS -4998 (Part 1).

## xxii) Component Design Criteria

The concrete shell shall be designed as per working stress method as per load combinations. The modular ratio shall be calculated as per Annexure -3 of IS - 456

(a) Dead load

(b) Dead Load + Wind Load

(c) Dead load +Earth Quake force

(d) Dead load +Temperature effects

(e) Dead load +wind load +Temperature effects

(f) Dead load + Earth quake+ Temperature effect

(g) Circumferential stresses due to temperature effects

(h) Circumferential tensile stresses due to wind inducing ring moment

(i) Circumferential Compressive stresses due to wind induced ring moment combined with temperature.

In load combination (a) to (i) ,dead load considered shall be with or without the weight of steel lining for flues whichever condition is more critical.

1. Across wind loads shall be combined with co-existing along wind loads. The combined design moment shall be taken as SRSS(Square root of summation of squares) of the moments due to across wind loads and co-existing along wind loads.

2. The concrete shell shall support platforms, the beam supporting the platform shall be made to rest on shell by making a pocket in shell, elastomeric bearing pads are provided below main girders & steel-lead bearing for other beam.

3. Minimum shell thickness is 350 mm at top & 750 mm at junction of shell with foundation junction.

4. The maximum deflection at top is limited to H 500 where it is the total weight above foundation.

5. The lower valves in the range of valves specified in IS-4998(Part 1) for dynamic modulus of elasticity shall be taken.

6. The static modulus of elasticity of concrete shall be 5000 <sup>√</sup>fck.

7. Maximum spacing of reinforcement in shell shall not be more than 250 mm.

8. Vertical bars shall be uniformly spaced.

## xxiii)

## Permissible Stresses for Chimney Shell

The stresses in steel reinforcement & concrete shall not exceed limits as per cl. 7.0 & IS: 4998:19H, for dead load + wind the permissible stress in concrete shall not exceed 0.28

The chimney flues will be corrosion resistant steel of type COR TEN B with mineral wool insulation.

c) Reinforced concrete chimney and tower by M.G. Pinfield. The valve of K1 shall be taken as 0.11 as per data on page No. 186. Minimum half the number of extra horizontal bars in shell around the opening to continue for circle round both faces and both sides.

2 1 OF WORK

![](images/8cc8825bf6b6e49a49c03fd643e55ffc1fb7a246b03c231ffa9b1cdf93cb7fc2.jpg)

<table><tr><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>LEGEND</td><td rowspan=1 colspan=2>LEGEND</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>BELT CONVEYOR</td><td rowspan=1 colspan=1>9</td><td rowspan=1 colspan=1>BELT FEEDER</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td rowspan=1 colspan=1> BS</td><td rowspan=1 colspan=1>BELT SCALE</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>DUST SUPRRESSION SYSTEM</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td rowspan=1 colspan=1>K  CSU</td><td rowspan=1 colspan=1>COAL SAMPLING UNIT</td><td rowspan=1 colspan=1>S</td><td rowspan=1 colspan=1>SERVICE WATER SYSTEM</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td rowspan=1 colspan=1>□DS</td><td rowspan=1 colspan=1>DUST SUPPRESSION-PF</td><td rowspan=1 colspan=1>OW</td><td rowspan=1 colspan=1>DRINKING WATER SYSTEM</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td rowspan=1 colspan=1>0 ILMS</td><td rowspan=1 colspan=1>MNCNETIC SEPARATORATOR</td><td rowspan=1 colspan=1>回</td><td rowspan=1 colspan=1>DUST EXTRACTION SYSTEM</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td rowspan=1 colspan=1>A MD</td><td rowspan=1 colspan=1>METAL DETECTOR</td><td rowspan=1 colspan=1>SP</td><td rowspan=1 colspan=1>SUMP &amp; SUMP DRAINAGE PUMPS</td><td></td><td></td><td></td><td></td><td rowspan=2 colspan=2>FOR REFERENCE ONLY</td><td rowspan=2 colspan=1></td></tr><tr><td rowspan=1 colspan=1>PF</td><td rowspan=1 colspan=1>PADDLE FEEDER</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td></td><td></td><td></td><td></td></tr><tr><td rowspan=1 colspan=1>区<</td><td rowspan=1 colspan=1>VENTILATION</td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=5 colspan=2>TYPICAL COAL FLOW DIAGRAM FOR2x500MW THERMAL POWER PLANT(WITH WAGON TIPPLER, TRACK HOPPER UNLOADING &amp;REVERSIBLE YARD CONVEYOR)</td><td></td></tr><tr><td rowspan=1 colspan=1>FG</td><td rowspan=1 colspan=1>FLAP GATE</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td rowspan=1 colspan=1>8000</td><td rowspan=1 colspan=1>ROD GATE</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td rowspan=1 colspan=1>日</td><td rowspan=1 colspan=1>RACK &amp; PINION GATE</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td rowspan=1 colspan=1>回cR</td><td rowspan=1 colspan=1>CRUSHER</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td rowspan=1 colspan=1>日vsF</td><td rowspan=1 colspan=1>VIBRATING SCREENINFEEDER</td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=3 colspan=1></td><td rowspan=2 colspan=1>Central Electricity Authority</td><td></td></tr><tr><td rowspan=1 colspan=1>SM</td><td rowspan=1 colspan=1>SUSPENDED MAGNET</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td rowspan=1 colspan=1>可a</td><td rowspan=1 colspan=1>RACK &amp; PINION ELEVATOR</td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=2>CEA-TETD-CHP-002</td></tr></table>

![](images/d7713fd4d4f0b0855910bc3b9966d8204685a9c1a35255d646dab94abf7bab96.jpg)

<table><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=3 colspan=1></td><td rowspan=3 colspan=2>Y</td><td rowspan=3 colspan=1></td><td></td><td></td><td rowspan=3 colspan=1></td><td rowspan=3 colspan=1></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td rowspan=1 colspan=1></td><td rowspan=2 colspan=1></td><td rowspan=2 colspan=1></td><td rowspan=2 colspan=1></td><td></td><td></td><td></td></tr><tr><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td></td><td></td><td></td></tr><tr><td rowspan=1 colspan=1>Y</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>Y</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>Y</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>Y</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>X</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>X</td><td rowspan=1 colspan=1>X</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=2></td><td rowspan=1 colspan=1>Y</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>Y</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>Y</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr><tr><td></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr><tr><td></td><td></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=2></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>Y</td><td rowspan=1 colspan=1>Y</td></tr><tr><td></td><td></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=2></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=1>PS</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=2></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr></table>

![](images/eafc5638625403858778fecfb8baf67af7be9302d8ad5a99ffe8716783755178.jpg)

![](images/475df957c5c64d020ce568d821e650b1f2115af87c8b3a8fa0ff6981a140e81e.jpg)

![](images/34f09a15dabff1ef47dfa40bc7a3d2c1fd30460f35ae16bcce29f7d038479923.jpg)

![](images/9c175841282664add4e8c613376adb0a8fd30eb26ee0d080d3c8d3ef4c7f709d.jpg)

![](images/e3e4f6fd18790343bc9e01c8d1848dd8d5df0578b89d5312a10f66505b43fdc3.jpg)

![](images/0e5b13066efba243db273a5cca7efaa1c084ad741612764078c8555990f2abf0.jpg)

![](images/62bdcca32353d648fd42ace412510aa78ef9a415ea4578f4261db13b35d550ab.jpg)

![](images/e0a49446a7aca97e3fd15334ed222a314e6dece14efb0ad3170e6c9f79614f32.jpg)

![](images/88eb6dc45262b6f69a979d251215b1f972ba63ba871466dfaffa34dc356a4231.jpg)

![](images/17c46772436ffb4e9ab8be455b7cc171910b9ca23b70cd45f389d133db6afa66.jpg)

<table><tr><td rowspan=1 colspan=2>FOR REFERENCE ONLY</td></tr><tr><td rowspan=1 colspan=2>KEY SINGLE LINE DIAGRAM (TYPICAL)</td></tr><tr><td rowspan=1 colspan=2>2 X 500 MW &amp; ABOVE COAL BASED TPS</td></tr><tr><td rowspan=1 colspan=2></td></tr><tr><td rowspan=2 colspan=1>cea</td><td rowspan=1 colspan=1>Central Electricity Authority</td></tr><tr><td rowspan=1 colspan=1>Drg. NO.   CEA-TETD- EL-01</td></tr></table>