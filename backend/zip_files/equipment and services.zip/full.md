## Equipment and Services for Thermal Power Industry

## atomenergomash COMPANYOFROSATOM

# ABOUT THE COMPANY

Atomenergomash JSC (Company, Holding, AEM) is one of the leading powerengineering companies in Russia, and supplier of ef ective integrated solutions for nuclear and thermal power, gas and petrochemical industries, shipbuilding and special steel market.

SHIPBUILDING

THERMAL POWER

<sup>●</sup> Scientifi c, research and development

Manufacturing of special steel castings and forgings

## atomenergomash

SPECIAL STEELS

GAS AND PETROCHEMISTRY

<sup>●</sup> Manufacturing and supply of machinery equipment

<sup>●</sup> Construction and erection works

<sup>●</sup> More than 30 enterprises in Russia and abroad

<sup>●</sup> About 20% of domestic power engineering market

<sup>●</sup> Over 21,000 employees

<sup>●</sup> Equipment manufactured at AEM is used in more than 20 countries all over the world

# MACHINERY FOR THERMAL POWER INDUSTRY

Atomenergomash JSC is one of the largest and leading suppliers of ef ective technological solutions for thermal power industry in Russia and abroad.

Atomenergomash Enterprises have long-term experience in design and supply of thermal power equipment. The Company comprises scientifi c research, engineering, manufacturing, service construction, and installation entities in the Russian Federation and abroad.

## Milestones of Thermal Power Engineering Development

Design and engineering companies of Atomenergomash have high potential for integrated engineering design cycle — from research and development technological processes and further equipment manufacturing.

1942 <sub>—</sub> <sub>the</sub> <sub>fi</sub> <sub>rst</sub> <sub>drum-type</sub> <sub>boiler</sub> <sub>with</sub> <sub>gravity</sub> circulation

1944 <sub>—</sub> <sub>the</sub> <sub>fi</sub> <sub>rst</sub> <sub>direct-fl</sub> <sub>ow</sub> <sub>boiler</sub> <sub>with</sub> <sub>capacity</sub> <sub>of</sub>   
220 t/h for sub-critical steam conditions

1947 <sub>—</sub> <sub>the</sub> <sub>fi</sub> <sub>rst</sub> <sub>in</sub> <sub>the</sub> <sub>world</sub> <sub>experimental-industrial</sub> prototype 60-OP (Russian: 60-ОП) boiler with capacity of 12 t/h for ultra-supercritical steam parameters

1962 <sub>—</sub> <sub>fi</sub> <sub>rst</sub> <sub>USC</sub> <sub>boiler</sub> <sub>as</sub> <sub>a</sub> <sub>part</sub> <sub>of</sub> <sub>100</sub> <sub>MW</sub> <sub>power</sub> unit (PK-37) was commissioned at Kashirskaya State District Power Plant (GRES)

70s <sub>—</sub> <sub>start</sub> <sub>of</sub> <sub>production</sub> <sub>of</sub> <sub>supercritical</sub> <sub>pulverized-</sub> coal-fi red boilers with steam capacity of 1,650 t/h for 500 MW power units

Customers of AEM have trust in technologies and professional experience of the Group both when it comes to supplying the equipment and components for new thermal power plants and in the area of engineering and developing ef ective solutions for upgrading the existing plants.

80s <sub>—</sub> <sub>start</sub> <sub>of</sub> <sub>production</sub> <sub>of</sub> <sub>supercritical</sub> <sub>pulverized-</sub> coal-fi red boilers with steam capacity of 2,650 t/h for 800 MW power units

60s <sub>—</sub> <sub>start</sub> <sub>of</sub> <sub>production</sub> <sub>of</sub> <sub>supercritical</sub> <sub>direct-fl</sub> <sub>ow</sub> boilers with steam capacity of 950 t/h for 300 MW power units

90s <sub>—</sub> <sub>start</sub> <sub>of</sub> <sub>localization</sub> <sub>of</sub> <sub>heat-recovery</sub> <sub>steam</sub> generators (HRSG) in Russia

![](images/9ccb23e2a04d0530f13b6460235ca3ac8c3c90de99c3cd550ee1de4e40422042.jpg)  
In 1958, PK-33 (Russian: ПК-33) boiler won Grand Prix Brussels Exhibition.

![](images/94ee193f621e5ac1d86746b48114e713647b70077a3ea7084100599b0586de33.jpg)  
Hydro Power Plant GES-1, Mosenergo.

# GEOGRAPHY OF OPERATIONS

Projects of power units’ construction with AEM participation for the last 30 years

## 1. Russia

<sup>●</sup> Beryozovskaya GRES-1

3. Hungary

<sup>●</sup> Geller TPP

<sup>●</sup> Reftinskaya GRES

4. Macedonia

<sup>●</sup> Ryazanskaya GRES-24

<sup>●</sup> Bitola TPP

<sup>●</sup> Hydro Power Plant GES-1, Mosenergo

5. Bulgaria

<sup>●</sup> Central Heating and Power Plant CHPP-27, Mosenergo

<sup>●</sup> Maritsa-Vostok II TPP

<sup>●</sup> Maritsa-Vostok III TPP

<sup>●</sup> Severo-Zapadnaya CHPP

6. Ukraine

<sup>●</sup> Ivanovskiye CCGTs

<sup>●</sup> CHPP of Dnepropetrovsk Metallurgical Plant

<sup>●</sup> Kaliningradskaya CHPP-2

<sup>●</sup> Kirishskaya GRES

<sup>●</sup> CHPP-26, Mosenergo

<sup>●</sup> Nizhnevartovskaya GRES

<sup>●</sup> Novomoskovskaya GRES

<sup>●</sup> Nazarovskaya GRES

<sup>●</sup> Yuzhnouralskaya GRES-2

## 2. Belarus

<sup>●</sup> Thermal power plant (TPP) of Naftan OJSC

## 7. India

<sup>●</sup> Neyveli TPP

8. Kazakhstan

<sup>●</sup> Ekibastuzskaya GRES-2

9. Uzbekistan

<sup>●</sup> Novo-Angrenskaya GRES

10. China

<sup>●</sup> Tszisyan TPP

<sup>●</sup> Imin TPP

![](images/dabe8b535e1013a415df9c15080f1448afe8d9d0dd359b7c23065c176a03f6c2.jpg)

## KEY SUPPLIES

Power boilers   
Belarus 15   
Bulgaria 20   
Bosnia and Herzegovina 2   
Vietnam 4   
Germany 16   
Greece 1   
India 2   
Kazakhstan 48   
Kyrgyzstan 1   
China 14   
Lithuania 2   
Macedonia 4   
Poland 9   
Russia 338   
Romania 18   
Serbia 1   
Turkmenistan 2   
Uzbekistan 7   
Ukraine 29   
Croatia 2   
Heat Recovery Steam   
Generators (HRSG)   
Belarus 2   
Hungary 1   
Russia 77

# EQUIPMENT AND SERVICES FOR THERMAL POWER INDUSTRY

AEM companies manufactured about 800 boiler units of dif erent capacity and parameters for more than 150 domestic and foreign electric power plants with total capacity of over 66 GW, including 16 GW for export. AEM boilers are used at electric power plants in 20 countries all over the world.

## EQUIPMENT

• <sub>Power</sub> <sub>boilers</sub> <sub>for</sub> <sub>power-generating</sub> <sub>units</sub> with capacity of up to 50–800 MW;

• <sub>Heat</sub> <sub>recovery</sub> <sub>steam</sub> <sub>generators</sub> <sub>(HRSG)</sub> <sub>for</sub> combined cycle gas turbine (CCGT) with capacity of up to 20–800 MW;

• <sub>Hot</sub> <sub>water</sub> <sub>HRSG</sub> <sub>for</sub> <sub>units</sub> <sub>with</sub> <sub>capacity</sub> <sub>of</sub> <sub>up</sub> to 6–45 MW;

• <sub>Hot</sub> <sub>water</sub> <sub>boilers;</sub>

• <sub>Boiler</sub> <sub>auxiliary</sub> <sub>equipment;</sub>

• <sub>Steam</sub> <sub>and</sub> <sub>water</sub> <sub>heaters</sub> <sub>of</sub> <sub>spiral</sub> <sub>fi</sub> <sub>nned</sub> tubes;

• <sub>Standard</sub> <sub>sections</sub> <sub>of</sub> <sub>tubular</sub> <sub>air</sub> <sub>heaters;</sub>

• <sub>Equipment</sub> <sub>of</sub> <sub>regeneration</sub> <sub>system;</sub>

• <sub>Pumping</sub> <sub>equipment;</sub>

• <sub>Water-to-water</sub> <sub>heaters;</sub>

## SERVICES

• <sub>Engineering;</sub>

• <sub>Integrated</sub> <sub>supply;</sub>

• <sub>Project</sub> <sub>management;</sub>

• <sub>Heavy</sub> <sub>welded</sub> <sub>structures;</sub>

• <sub>Vessel</sub> <sub>equipment,</sub> <sub>including</sub> <sub>pressure</sub> <sub>vessels;</sub>

• <sub>Deaerators;</sub>

• <sub>Burners;</sub>

• <sub>Steam</sub> <sub>silencers;</sub>

• <sub>Water-steam</sub> <sub>heaters;</sub>

• <sub>Filters;</sub>

• <sub>Power</sub> <sub>valves;</sub>

• <sub>Parts</sub> <sub>and</sub> <sub>assembly</sub> <sub>units</sub> <sub>for</sub> <sub>pipelines;</sub>

• <sub>Metalwork;</sub>

• <sub>Distillation</sub> <sub>and</sub> <sub>desalination</sub> <sub>units;</sub>

• <sub>Automatic</sub> <sub>controls.</sub>

• <sub>Construction</sub> <sub>and</sub> <sub>erection</sub> <sub>works;</sub>

• <sub>Retrofi</sub> <sub>tting</sub> <sub>and</sub> <sub>Modernization.</sub>

![](images/b9680435a6a3cd2168762479e6be802d2ec9807808b92895ef8fd0e2feff15c5.jpg)

![](images/df87a811aa3b85fc432c01e5e28c8101cef975c14a0a4b5752c120bbd520cf0a.jpg)

![](images/04d6cf74af3b870fd6b8a5ee45a165117f1961527de3ab7b2903b431c9ddb041.jpg)

![](images/e54d6fe58e75a9da4217ae003112af78afa4b8c66f49b84837f6a0eafc546034.jpg)

![](images/a1f9b6efd180aafefcc222dbb0cdf8b9fb258d04c0e0f02f3e4a133744ef2a39.jpg)

# ENGINEERING

AEM includes enterprises with unique engineering competences and solid research and development base. The group of companies comprises leading designengineering and research companies with long-term experience in design and development of machinery equipment.

The Holding includes ZIOMAR Engineering Company established in 1991. Nowadays, it is one of the leading Russian design-engineering companies specialized in research and development works for Russian and foreign sites of thermal, nuclear and petrochemical industries.

The works are performed with involvment of the leading relevant research institutions and organizations of the Russian Federation: OJSC OKB Gidropress, OJSC Afrikantov OKBM, OJSC NPO CNIITMASH, OJSC NPO CKTI, JSC VTI, OJSC Engineering Center ORGRES. In terms of the license agreement, AEM carries out cooperation together with the NEM Energy b.v. (Holland) company, which is one of the leading engineering companies in Europe supplying equipment for thermal power plants, i.e. HRSGs.

ZIOMAR Engineering Company has relevant licenses and permits of state and supervising entities of the Russian Federation required for performing its activities, including the license issued by the Federal Nuclear and Radiation Safety Authority of Russia that authorizes to carry out design-engineering works and designer’s supervision at all stages of the equipment and pipelines’ life cycle of nuclear power plants.

Nowadays, ZIOMAR Engineering Company OJSC employs about 400 highly qualifi ed specialists. The specialists of the Company are certifi ed according to the Rules and Norms of Nuclear Power Industry valid in the Russian Federation.

ZIOMAR Engineering Company OJSC includes:

• <sub>Power</sub> <sub>boilers</sub> <sub>department;</sub>

HRSG department;

• <sub>Special</sub> <sub>design</sub> <sub>bureau</sub> <sub>for</sub> <sub>nuclear</sub> <sub>power,</sub> <sub>gas</sub> <sub>and</sub> petrochemical industries and special-purpose equipment;

• <sub>Calculation</sub> <sub>and</sub> <sub>engineering</sub> <sub>center;</sub>

• <sub>Experimental</sub> <sub>department.</sub>

Specialists of ZIOMAR Engineering Company OJSC perform complete design and engineering works for thermal and nuclear power, gas and petrochemistry sites; rig and industrial testing of designed and manufactured equipment; perform thermal-hydraulic and strength calculations and carry out equipment adjustment; retrofi t feasibility study of the operating generation units for evaluation of retrofi tting and modernization solutions.

![](images/54c632c2c0fc455d3c64e8502738234ca96920187260ef6508b8dd85337df3e4.jpg)

# MANUFACTURING CAPACITIES

The unique manufacturing capabilities let AEM of er customers equipment in accordances with their strict requirements. Nowadays, thanks to industrial upgrading and modernization of the Holding’s assets, AEM is one of the leaders of the Russian power engineering industry.

![](images/961f2270bd5e25acd5cedb93a2990ce1d1171f023e3e2a9366b19a62a2895cae.jpg)

## ZiO-PODOLSK

JSC Machine-Building Plant ZiO-Podolsk is one of the largest machine-building enterprises in Russia with more than 90 years history. Nowadays, the plant has almost all types of the main machine-building facilities allowing to manufacture modern equipment. Introduction of Rosatom production system (RPS) enables to detect and reduce all kinds of losses in manufacturing and business processes.

![](images/1180c49ecf2731ad56f6f5aa6b665595f8ac4714967cf05c45f93052ea9abcc3.jpg)

## SHEPROMAWCNELCTAAb ENERGOMASHSPETSSTAL

Energomashspetsstal OJSC is the largest in the Eastern Europe manufacturer of special steel heavy castings and forgings. Energomashspetsstal has a large pool of metal cutting equipment, including turning, boring, turningand-boring lathes, deep boring lathes, planer-type milling machines, slotting machines, gear-milling machines, bandsaw machines and others. Production capacities of the electric-furnace shop provide for production of large size dif erent steel grades forgings.

![](images/c046ad29dad735e4a386435a086506a09474dd48b185c39f8d4bf5167f37cd9f.jpg)

The company is specialized in production of pumping equipment for the enterprises of thermal, nuclear, oil and gas industries and in production of fuel-handling machines for nuclear power plants. GANZ EEM also manufactures hydropower equipment.

## AEM-TECHNOLOGY ATOMMASH

It is the largest machine-building enterprise in the South of Russia with total area 1.7 ha. The process capabilities allow to manufacture any heat exchange, casing and vessel equipment for nuclear power plants, steelstructures and modular boiler equipment of high readiness.

The company owns a large pool of unique metal cutting, press, thermal and welding equipment. Another advantage of the company is its logistic capacity ofequipment transportation by road and railway as wellas by sea from its own port terminal.

## AEM-TECHNOLOGY PetrozavodskMash

Petrozavodskmash is one of the largest machine-building enterprises in the Northwest Russia, supplying casing, vessel, tank and other equipment. The plant has unique melting and weight-lifting capacities providing production of castings of almost all required standard sizes. The enterprise has also a unique pool of equipment: turning and boring mills, horizontal milling lathes, boring lathes, multi-spindle drilling, grinding and fi nishing CNC machines, balancing and other machines. Production areas are connected to all European ports via its own port terminal and Volga-Baltic Route.

![](images/49fe64650421426ed76e47a075a882b7de4327722d64f57327a6c5bcdd82e031.jpg)

It produces pipeline valves for thermal, nuclear oil & gas and chemical industries.

Manufacturing of boiler equipment for 2 х 500 MW steam units and of 4 HRSGs for 450 MW CCPs a year;

● Equipment capacity up to 6 GW per year for all thermal power industry programs of;

Finned tube production comes to 7.5-8 thousand tons per year;

• <sub>Up</sub> <sub>to</sub> <sub>60</sub> <sub>thousand</sub> <sub>tons</sub> <sub>of</sub> <sub>castings,</sub> <sub>steels,</sub> <sub>non-</sub> ferrous alloys;

• <sub>ISO</sub> <sub>standards.</sub>

# BOILER EQUIPMENT MODERNIZATION

## ZIOMAR Engineering Company OJSC performs boiler equipment retrofi t and modernization solutions.

## Main Directions of Retrofi t & Modernization Solutions Provided to Customer Equipment

## Monitoring of power engineering facility’s technical state

![](images/6f47348b821cd1351d02a155a7ab836f9746c2b700185f358c072e27637199a2.jpg)

Detection of the sources of reliability degrading and evaluation of the causes of nonconformities

## Operation Modes:

• <sub>Adjustment</sub> <sub>of</sub> <sub>operation</sub> <sub>modes;</sub>

• <sub>Testing;</sub>

• <sub>Efi</sub> <sub>ciency</sub> <sub>evaluation.</sub>

## Technical State ( Lifetime, Project and Installation Quality):

• <sub>Studying</sub> <sub>domestic</sub> <sub>and</sub> <sub>foreign</sub> <sub>experience;</sub>

• Development of technical assignment for retrofi tting;

• <sub>Development</sub> <sub>of</sub> <sub>design</sub> <sub>documentation;</sub>

• <sub>Modernization</sub> <sub>and</sub> <sub>retrofi</sub> <sub>tting;</sub>

• <sub>Follow-up</sub> <sub>retrofi</sub> <sub>t</sub> <sub>results</sub> <sub>and</sub> <sub>efi</sub> <sub>ciency</sub> <sub>evaluation.</sub>

Implementation of the listed above activities is impossible without applying new technologies.

The workshop is equipped with modern machine tools. Design subdivision is equipped with required computers and software.

Development of design documentation is performed with modern software for 2D and 3D drawing (Autodesk Inventor, SolidWorks). Calculations are performed by use of software for numerical simulation (ANSYS, Flow Vision), allowing to obtain results which are maximum approximated to experimental data of operation.

## List of Boiler Equipment Retrofi ts:

• <sub>Increase</sub> <sub>of</sub> <sub>the</sub> <sub>unit</sub> <sub>load</sub> <sub>adjusted</sub> <sub>range</sub> <sub>(threshold</sub> reduction of reliable operation);

• <sub>Shift</sub> <sub>to</sub> <sub>of</sub> <sub>-design</sub> <sub>types</sub> <sub>of</sub> <sub>fuel;</sub>

Arrangement of sludge-free operation mode of slagging coal boilers combustion chamber by means of lowtemperature and layer-by-layer fuel combustion;

Enhancement of fuel ignition stability and operation range extension without fuel oil support fl ame by means of installation of telescopic dust separators and special dust concentrators, high-temperature air heating, using low-temperature vortex technology etc.;

• Enhancement of technical and economic efi ciency by means of structure optimization and implementation of modernt design and circuit solutions (usage of diaphragm and spirally fi nned heating surfaces, light piping insulation, etc.);

Retrofi tting aimed at environmental performance improvement; increase of boilers steam generating capacity by mean of installation of intensifi ed heating surfaces in economizer, evaporation and superheating boiler areas.

# LOW-TEMPERATURE VORTEX TECHNOLOGY COMBUSTION

Low-temperature vortex technology is based on principles of solid fuel low-temperature combustion under conditions of particles multiple circulation in chamber furnace.

## Key Advantages of Low-Temperature Vortex Technology

Combustion of coarse grinding fuel (turf, brown coal)

Rapid heating of fuel air fl ow

• <sub>1.3–3.4</sub> <sub>times</sub> <sub>increase</sub> <sub>in</sub> <sub>efi</sub> <sub>ciency</sub> <sub>of</sub> <sub>dust</sub> <sub>system;</sub>

• <sub>Increase</sub> <sub>in</sub> <sub>lifetime</sub> <sub>of</sub> <sub>grinding</sub> <sub>elements;</sub>

• <sub>Explosion</sub> <sub>safety;</sub>

• <sub>Fuel</sub> <sub>treatment</sub> <sub>system</sub> <sub>easing;</sub>

• <sub>Decrease</sub> <sub>of</sub> <sub>of</sub> <sub>electric</sub> <sub>power</sub> <sub>cost</sub> <sub>of</sub> <sub>grinding</sub> <sub>works;</sub>

• <sub>Improvement</sub> <sub>of</sub> <sub>ash</sub> <sub>collecting</sub> <sub>equipment</sub> <sub>operation.</sub>

• <sub>Stable</sub> <sub>ignition</sub> <sub>and</sub> <sub>burning;</sub>

• <sub>Refuse</sub> <sub>from</sub> <sub>gas</sub> <sub>or</sub> <sub>fuel</sub> <sub>oil</sub> <sub>support</sub> <sub>fl</sub> <sub>ame;</sub>

• <sub>Stable</sub> <sub>burning</sub> <sub>process</sub> <sub>regardless</sub> <sub>of</sub> <sub>load</sub> <sub>and</sub> <sub>fuel</sub> <sub>parameters.</sub>

Heat exchange   
intensifi cation   
(increase of screens   
thermal efi ciency factor)

Adjustment of thermal fi eld and decreasing maximum temperature in fl ame core to 1,000 … 1,350 °С ● Potential increase of boiler steam generating capacity by 15–20%.

No slagging and contamination of furnace and convective heating surfaces;

• <sub>Decrease</sub> <sub>of</sub> <sub>nitrogen</sub> <sub>oxides</sub> emission NOx by 20–70%;

Decrease of sulfur oxides emission SOx to 70%.

![](images/f5da0653fa524ab85cbfd1d6bc3a11fbc5b351ec8f745b31b9b0aab187fd614a.jpg)

## Modernization of Power Unit No. 7 at Nazarovskaya GRES

![](images/29f2ed05f59d6ac19d4744375ac675f93314efa5e1d33bfd2ebe6004af6278ef.jpg)

• <sub>It</sub> <sub>retrofi</sub> <sub>t</sub> <sub>of</sub> <sub>К-500-240</sub> <sub>turbine</sub> <sub>(COMTEС-Energoservice</sub> <sub>LLC);</sub>

• <sub>Upgrading</sub> <sub>automated</sub> <sub>process</sub> <sub>control</sub> <sub>system</sub> <sub>of</sub> <sub>power</sub> <sub>unit</sub> <sub>No.</sub> <sub>7</sub> (Honeywell CJSC);

• <sub>replacement</sub> <sub>of</sub> <sub>three</sub> <sub>phases</sub> <sub>of</sub> <sub>the</sub> <sub>unit</sub> <sub>transformer;</sub>

• <sub>retrofi</sub> <sub>tting</sub> <sub>central</sub> <sub>dust</sub> <sub>plant</sub> <sub>(CDP)</sub> <sub>equipment;</sub>

retrofi tting boiler 7А, 7B (Russian: 7Б) including shift to low-temperature vortex technology of combustion as well as replacement of heating surfaces, brickwork and insulation (ZiO-Podolsk).

Actual 33 MW increase enhanced power unit installed capacity up to 433 MW instead of the planned earlier 415 MW. Emissions of nitrogen and sulfur oxides decreased almost twice.

# QUALITY MANAGEMENT SYSTEM

Enterprises of the Holding are specialized in manufacturing of equipment for thermal and nuclear power, gas and petrochemical industries. The basis for quality assurance of equipment manufacturing for thermal power industry is quality management system, relevant to modern worldwide practice, norms of international standards ISO 9000 series. Quality management system of AEM enterprises covers the whole management system of AEM and its subsidiaries, aimed at the quality assurance of provided services and applied processes.

For this purpose independent certifi cation authorities (international and domestic) carried out certifi cation of quality management and manufacturing system at the enterprises of the Holding. In particular, currently it is carried out prolongation of certifi cate of conformity to code of American Society of Mechanical Engineers (ASME): ASME Section 8 Division 1, Division 2, Stamp U and Stamp S.

All equipment manufactured by the Holding enterprises is subject to the strictest quality inspection, including detailed expert review of the documentation and tests performance at high quality level. The quality inspection starts from the moment of the contract signing. According to its requirements the manufacturer develops and agrees with the customer quality plans including all main stages of equipment production, starting from the approval of design documentation with customer, control of production availability, certifi cation of technologies, equipment and personnel, incoming inspection of purchased materials and components to production workfl ow and customer acceptance.

Before enter into manufacturing all purchased materials and components pass through 100% incoming inspection. Visual and dimensional inspection of the arrived materials, semi-fi nished products, welding materials is performed as well as supporting documentation.

Laboratories of the Holding enterprises during equipment manufacturing perform the following types of inspection: chemical analysis, metallographic examination, corrosion tests, mechanical tests of metal and welded joints, radiographic, ultrasonic, magnetic particle testing, dye penetrant testing, metal and welded joints leakage testing.

## Quality Management System and Production Certifi cates Availability

![](images/6aba7783d3d534850bdbea28d81ef544a4d30f77a6fe274538f684984c794238.jpg)  
Quality management system corresponds to the requirements of ISO 9001:2008, which are valid till November 2015.

![](images/f678941f5f10c270bcde9ce3a33cec7ea948f1ce510bb3a8265a65bae364a661.jpg)  
Production of the equipment operated under pressure as per European norms according to Directive AD 2000-Merkblatt HP0/ TRD201 with СЕ 0036 marking, which is valid till April 2016.

# BOILER EQUIPMENT

AEM has vast experience in design and manufacturing of boiler equipment for thermal power industry. The main products are steam boilers for power units with capacity from 50 to 800 MW and heat recovery steam generators (HRSG) for modern Combined Cycle Gas turbines (CCGTs) with capacity from 20 to 800 MW.

## Types of Manufactured Equipment

## Utility Boilers

Intended for generation of process steam or operation within power sources at power generation plants. Design of burner device of utility and hot water boilers for generation plants implies combustion of dif erent kinds of fuel pursuant tor the agreement with customer.

## Heat Recovery Steam Generators

Сomplete recovery units, including HRSGs with inlet and outlet gas ducts and fume stacks, auxiliary equipment, including blowdown expanders, deaerators within low pressure drum, station pipelines, water-water heat exchangers, feed and circulation pumps, non-metallic condensers, afterburning units etc.

## Hot Water Boilers

Designed and manufactured state-of-the-art gas fuel oil hot water boilers with heat capacity of 70–120 Gcal/h. The boilers are manufactured in gas leak-proof design of all-welded panels with towertype arrangement of heating surface and supplied completed with auxiliary equipment, including valves of gas-air ducts, blowdown fans, noise suppressors, and fume stacks.

## Hot Water HRSGs

Hot water HRSGs for gas turbines with capacity from 6 to 45 MW. In hot water HRSGs of such series there is a capacity to regulate the output heat rate with saving nominal electric load of gas turbine plant. Regulation of the heat rate is achieved due to tight gas valves of own design.

AEM provides services of boiler equipment erection supervision, including preinstallation inspection, designer’s supervision and assistance with installation, adjustment, tests, trial starting, starting and commissioning in guarantee maintenance, personnel training and post-warranty service.

## Intergrated Supply:

• <sub>Soot-blowing</sub> <sub>equipment;</sub>

• <sub>Fuel</sub> <sub>supplying,</sub> <sub>coal</sub> <sub>milling</sub> <sub>and</sub> <sub>dust</sub> <sub>preparation</sub> equipment;

• <sub>Exhaust</sub> <sub>fans</sub> <sub>and</sub> <sub>air</sub> <sub>turboblowers;</sub>

Colorifi c installations with piping and valves;

● Ash cleaning devices, including electrostatic precipitators;

• <sub>Metalwork</sub> <sub>of</sub> <sub>boiler</sub> <sub>island</sub> <sub>and</sub> <sub>fume</sub> <sub>stack;</sub>

● Dust-gas-air ducts complete with valves and compensators;

• <sub>Station</sub> <sub>pipelines;</sub>

• <sub>Single</sub> <sub>turn</sub> <sub>electric</sub> <sub>actuators</sub> <sub>and</sub> <sub>their</sub> <sub>joints;</sub>

• Other power equipment of boiler island.

![](images/cbb94cd67ac2f966c2ccf0d7ed0dbdf443e8a5042618888ed26c47f12125d600.jpg)

## UTILITY BOILERS

AEM solutions include wide range of steam boilers, designed and delivered for operation on brown coal and lignite of power units with capacity of up to 800 MW.

Development and engineering

![](images/73170c60436c59173fd78c62408c3759a0a5e169d3efbd68e92f6143ff2b486b.jpg)

![](images/aec7c1720a20bc8311bcc89aa708ef8ea384c78d0a8a81d40b1a5eed4f16c127.jpg)  
ZIOMAR  
Ep-690-15.4-540 LT Ep-690-15.4-540 LT (Russian: Еп-690-15,4-540 ЛТ)<sub>Neyveli</sub> <sub>TPP</sub> <sub>2×210</sub> <sub>MW</sub> <sub>(India)</sub>

![](images/c88f43e99d5d52ecc94962b37d5d16d2e38efff8560491f004ebaede5246ad8b.jpg)  
Pp-1000-25-545/545 (P-64) Pp-1000-25-545/545 (P-64) (Russian: Пп- <sup>(П-64))</sup> <sup>boiler</sup>Gacko and Ugljevik TPP (Yugoslavia), Novo-Angrenskaya TPP (Uzbekistan)  
Manufacture

![](images/33660ad51040b17d064aac07c7a2c079ab1a85e8ce020113fe70efb0691c4bae.jpg)  
500 МВт

![](images/9bbe996d86864de9dfd7326d74f0dd12c74b8efdfbd19e8db984c58d96aaa80d.jpg)

![](images/f97e88ba98fd5b31ff0a313a6f3d2b851cabdb04a12eb981724861f927d4658e.jpg)  
Pp-1650-25-545/545 (P-78) Pp-1650-25-545/545 (P-78) (Russian: Пп- <sup>(П-78))</sup> <sup>boiler</sup>Imin TPP2×500 MW (China)

![](images/02b368f125afcf7489366499fd8c321f99f0a8ecafdac8fb8f2a331269246375.jpg)  
Pp-2650-25-545/545 (P-67) (Russian: Pp-2650-25-545/545 (P-67) (Russia Beryozovskaya GRES 3×800 MW (Russia)

## Scope of Boiler Supply

• <sub>Forced-draft</sub> <sub>equipment;</sub>

• <sub>Dust</sub> <sub>preparation</sub> <sub>equipment;</sub>

• <sub>Steam-water</sub> <sub>duct</sub> <sub>valves;</sub>

• <sub>Gas-air</sub> <sub>ducts</sub> <sub>valves;</sub>

• <sub>Burner</sub> <sub>devices</sub> <sub>with</sub> <sub>ignition</sub> <sub>safety</sub> <sub>devices</sub> <sub>and</sub> <sub>fl</sub> <sub>ame</sub> control sensors;

• <sub>Fuel</sub> <sub>oil</sub> <sub>nozzles;</sub>

• Equipment for cleaning heating surfaces from outer deposits;

• <sub>Service</sub> <sub>platforms</sub> <sub>(bridging</sub> <sub>and</sub> <sub>ladders);</sub>

• <sub>Boiler</sub> <sub>fi</sub> <sub>ttings;</sub>

• <sub>Piping</sub> <sub>within</sub> <sub>boiler</sub> <sub>skid;</sub>

Gas piping with valves within boiler skid;

## Boiler Technical Parameters

High pressure boilers with natural circulation:

• <sub>Steam</sub> <sub>capacity</sub> <sub>120–670</sub> <sub>t/h;</sub>

• <sub>Outlet</sub> <sub>steam</sub> <sub>temperature</sub> <sub>510–540</sub> <sub>°C;</sub>

● Outlet steam pressure 100–160 kgf/cm<sup>2</sup>.

High pressure direct-fl ow boilers:

• <sub>Steam</sub> <sub>capacity</sub> <sub>540–670</sub> <sub>t/h;</sub>

• Steam and fuel oil piping with valves within boiler skid;

• <sub>Embedded</sub> <sub>items</sub> <sub>for</sub> <sub>instruments</sub> <sub>and</sub> <sub>sensors;</sub>

• <sub>Calorifi</sub> <sub>ers</sub> <sub>for</sub> <sub>preliminary</sub> <sub>air</sub> <sub>heating</sub> <sub>before</sub> <sub>air</sub> <sub>heater;</sub>

• <sub>Condensing</sub> <sub>units</sub> <sub>for</sub> <sub>obtaining</sub> <sub>own</sub> <sub>condensate;</sub>

• <sub>Steam-steam</sub> <sub>heat</sub> <sub>exchangers</sub> <sub>and</sub> <sub>injection</sub> <sub>steam</sub> coolers;

• <sub>Setting</sub> <sub>and</sub> <sub>insulation</sub> <sub>materials,</sub> <sub>decorative</sub> <sub>casing;</sub>

• <sub>Sampling</sub> <sub>cooler;</sub>

• <sub>Supports</sub> <sub>and</sub> <sub>suspensions</sub> <sub>for</sub> <sub>boiler</sub> <sub>piping;</sub>

• <sub>Expansion</sub> <sub>joints</sub> <sub>for</sub> <sub>gas-air</sub> <sub>ducts;</sub>

• <sub>Non-metallic</sub> <sub>gas</sub> <sub>ducts</sub> <sub>expansion</sub> <sub>joints;</sub>

• <sub>Rain</sub> <sub>screens;</sub>

• <sub>Boiler</sub> <sub>outlet</sub> <sub>silencers.</sub>

• <sub>Outlet</sub> <sub>steam</sub> <sub>temperature</sub> <sub>540–570</sub> <sub>°C;</sub>

• <sub>Outlet</sub> <sub>steam</sub> <sub>pressure</sub> <sub>140</sub> <sub>kgf/cm2.</sub>

Supercritical parameters direct-fl ow boilers:

• <sub>Steam</sub> <sub>capacity</sub> <sub>950–2650</sub> <sub>t/h;</sub>

• <sub>Outlet</sub> <sub>steam</sub> <sub>temperature</sub> <sub>545–565</sub> <sub>°C;</sub>

• <sub>Outlet</sub> <sub>steam</sub> <sub>pressure</sub> <sub>255</sub> <sub>kgf/cm</sub>2<sub>.</sub>

# HOT WATER BOILERS

ZiO-Podolsk and ZIOMAR developed modern gasfuel oil and gas boilers with heat rate of 70, 100 and 120 Gcal/h for the needs of industrial power sector and public utilities. The boilers are designed for heating of district water and can be used in heat supply system and ventilation. Boilers design allow to instal them in the cells of worn out and outdated equipment.

Optional Equipment (supplied by agreement with customer):

• <sub>Blow</sub> <sub>down</sub> <sub>fan;</sub>

• <sub>Tight</sub> <sub>valves</sub> <sub>as</sub> <sub>per</sub> <sub>the</sub> <sub>diagram</sub> <sub>of</sub> <sub>gas-air</sub> <sub>ducts;</sub>

All types of water heating boilers are equipped with low emission burner devices. There is staged fuel combustion (as per the height) providing partial supply of the air required for burning through nozzles of the upper blow down.

• <sub>Electric</sub> <sub>actuators</sub> <sub>for</sub> <sub>the</sub> <sub>tight</sub> <sub>valves/single-turn</sub> electric actuators and their joints;

• <sub>Compensators</sub> <sub>of</sub> <sub>gas-air</sub> <sub>ducts;</sub>

• <sub>Flow-metering</sub> <sub>devices</sub> <sub>for</sub> <sub>gas-air</sub> <sub>ducts;</sub>

• <sub>Lower</sub> <sub>level</sub> <sub>of</sub> <sub>ACS</sub> <sub>(automated</sub> <sub>control</sub> <sub>system).</sub>

## Technical Parameters

<table><tr><td>No.</td><td>Technical parameters of</td><td>KV-G-81.4-150N</td><td>KV-GM-140150N</td><td>KVGM-116.3-150N</td></tr><tr><td>1</td><td>Heat rate (gas/fuel oil), Gcal/h</td><td>70</td><td>120</td><td>100</td></tr><tr><td>2</td><td>Fuel</td><td>Gas</td><td>Gas/fuel oil</td><td>Gas/fuel oil</td></tr><tr><td>3</td><td>Boiler outlet water temperature, °C</td><td>150</td><td>150/160</td><td>150</td></tr><tr><td>4</td><td>Boiler outlet water pressure, kgf/cm²</td><td>12</td><td>12</td><td>12</td></tr><tr><td>5</td><td>Design boiler efficiency (gross), %</td><td>95.0</td><td>95.5/90.8</td><td>93.9/91.1</td></tr><tr><td>6</td><td>Nitrogen oxides emissions after the boiler (if α = 1.4), mg/nm³</td><td>≤125</td><td>≤125/300</td><td>≤125/300</td></tr></table>

## Hot Water HRSGs for Operation with Gas Turbine from 6 to 45 MW

Hot Water HRSGs are designed to produce hot water by using exhaust gases heat supplied from the gas turbine. Technical parameters of hot water HRSGs and types of gas turbines, which they are installed behind, are given in the table below. Water heating HRSG allows operation with changes in fl ow and temperature of combustion products after gas turbine due to changes in temperature of ambient air and changes in gas turbine load.

## Technical Parameters

<table><tr><td>Type of boiler (factory marking):</td><td>Water heating HRSG 5.5/110 (P-104)</td><td>Water heating HRSG 13.0/150 (P-105)</td><td>Water heating HRSG 35.0/150 (P-106)</td><td>Water heating HRSG 17.0/150 (P-109)</td><td>Water heating HRSG (B) 35.0/150 (P-122)</td><td>Water heating HRSG 12.2/150 (P-126)</td><td>Water heating HRSG 19/130 (P-128)</td><td>Water heating HRSG 60/150 (P-129)</td></tr><tr><td>Type of gas turbine (turbine power capacity):</td><td>GTE-6/6.3 11 (6 MW)</td><td>GTA-6RM (6 MW)</td><td>LM2500+DLE (30 MW)</td><td>GTE-10/95BM (8 MW)</td><td>LM2500+DLE (30 MW)</td><td>GTES Ural-6000 (6 MW)</td><td>GTG-12VE (12 MW)</td><td>SGT-800 (43 MW)</td></tr><tr><td>Water heating HRSG inlet gas temperature, °C</td><td>303</td><td>416</td><td>505.2</td><td>420</td><td>505.2</td><td>437</td><td>283</td><td>523.5</td></tr><tr><td>Flow of recovered exhaust gases, kg/s</td><td>37.71</td><td>48</td><td>80,8</td><td>57.8</td><td>80.8</td><td>34.72</td><td>93.2</td><td>143.47</td></tr><tr><td>Temperature of exhaust gases, ℃</td><td>138</td><td>133</td><td>95</td><td>110</td><td>109</td><td>111</td><td>103</td><td>99</td></tr><tr><td>Water heating HRSG inlet water temperature, °C</td><td>70</td><td>70</td><td>61</td><td>73</td><td>65</td><td>80</td><td>70</td><td>70</td></tr><tr><td>Water heating HRSG outlet water temperature, °C</td><td>110</td><td>150</td><td>129,3</td><td>155</td><td>150</td><td>150</td><td>130</td><td>150</td></tr><tr><td>Draft-pressure drop of water heating HRSG, max, Pa</td><td>1800</td><td>2000</td><td>1300</td><td>2500</td><td>2300</td><td>1500</td><td>2500</td><td>2500</td></tr></table>

# HEAT RECOVERY STEAM GENERATORS

## Single- and Double-Circuit Vertical Type Boiler with Controlled Circulation in Evaporation Circuits

Designed for superheated steam generation of one and two pressures due to recovery of exhaust products heat after gas turbine. HRSGs are manufactured in a wide range of standard sizes and can be operated with an independent deaerator or a deaerator head integrated into a low pressure drum or a deaerator column. Gas heater condensate circuit (recirculation line) can comprise water-water heat exchanger for heating piping network

## Advantages of Vertical HRSGs:

● The capability to install HRSG above the gas turbine frame with vertical exhaust from the gas turbine;

Lower number of pipelines as well as drains and air vents and valves in these lines;

water or be provided with separated circuit of gas heater for network water.

Higher parameters for steam generation capacity and steam temperature of HRSG can be reached by operating in a combined cycle (heat recovery of exhaust gases and additional burning of natural gas in an afterburning device using the air excess which exists in exhaust gases as an oxidant). HRSGs can be equipped with a bypass system (with separate bypass fume stack or joint fume stack) for gas turbine operation when the boiler is shutdown.

• <sub>Modular</sub> <sub>design</sub> <sub>of</sub> <sub>heating</sub> <sub>surfaces</sub> <sub>for</sub> <sub>easy</sub> shipment.

## Technical Parameters

<table><tr><td rowspan="2">Type of HRSG</td><td rowspan="2">Type of the gas turbine, capacity, MW,</td><td colspan="3">Steam parameters</td></tr><tr><td>D, t/h</td><td>P, bar</td><td>T,℃</td></tr><tr><td>P-90</td><td>V-94.2 Siemens 160 MW</td><td>242/56</td><td>82/7.0</td><td>515/200</td></tr><tr><td>P-91</td><td>V-94.2 Siemens 160 MBτ</td><td>310</td><td>15</td><td>275</td></tr><tr><td>P-103</td><td>GT-10C Alstom</td><td>39/8</td><td>55/6</td><td>487/212</td></tr><tr><td>P-107</td><td>GTE-160160 MW</td><td>224/51</td><td>77/5.8</td><td>509/206</td></tr><tr><td>P-108</td><td>SGT-800 Siemens 45 MW</td><td>58/12</td><td>74/7.0</td><td>525/209</td></tr><tr><td>P-116</td><td>GTE-160160 MW</td><td>224/51</td><td>77/5.8</td><td>509/206</td></tr><tr><td>P-120</td><td>GTE 20C/40P 20 MW</td><td>40</td><td>40</td><td>440</td></tr><tr><td>P-134</td><td>GTE-160160 MW</td><td>224/57</td><td>71.5/5.3</td><td>509/207</td></tr><tr><td>P-137</td><td>GTE-160160 MW</td><td>224/49</td><td>98/8.7</td><td>508/222</td></tr><tr><td>P-144</td><td>GTE-160160 MW</td><td>232/47</td><td>78/7.9</td><td>503/217</td></tr></table>

## Key References:

2× 450 MW CCGT\*, Severo-Zapadnaya CHPP\*\*, St. Petersburg, power units No. 1 and No. 2 — 4 HRSGs;

2× 450 MW CCGT, CHPP -27, Moscow, power units No. 3 and No. 4 — 4 HRSGs;

• <sub>190</sub> <sub>MW</sub> <sub>CCGT,</sub> <sub>Dzerzhinskaya</sub> <sub>CHPP,</sub> <sub>Dzerzhinsk;</sub>

2× 39 MW CCGT, Sochinskaya TPP, Sochi —   
2 HRSGs;

\* CCGT — Combined Cycle Gas Turbine Power Plant

\*\* CHPP — Combined Heat and Power Plant

2× 130 MW CCGT, district thermal station Strogino, Moscow — 4 HRSGs;

• <sub>450</sub> <sub>MW</sub> <sub>CCGT,</sub> <sub>CHPP-21,</sub> <sub>Moscow</sub> <sub>—</sub> <sub>2</sub> <sub>HRSGs;</sub>

• <sub>52</sub> <sub>MW</sub> <sub>CCGT,</sub> <sub>Yeletskaya</sub> <sub>CHPP,</sub> <sub>Yelets</sub> <sub>—</sub> <sub>2</sub> <sub>HRSGs;</sub>

• <sub>CCGT-230Т,</sub> <sub>Chelyabinskaya</sub> <sub>CHPP-3,</sub> <sub>Chelyabinsk;</sub>

• <sub>210</sub> <sub>MW</sub> <sub>CCGT,</sub> <sub>Novgorodskaya</sub> <sub>CHPP,</sub> <sub>Novgorod;</sub>

450 MW CCGT, Khuadyan-Teninskaya CHPP, Yaroslavl —2 HRSGs.

## Horizontal Type with Natural Circulation in Evaporation Circuits, Single-, Doubleand Triple-Circuit Ones

Designed to generate superheated steam of one and two pressures by means of recovery of exhaust products heat behind the gas turbine. HRSGs are produced in wide range of standard sizes and can be operated with an independent deaerator or a deaerator head integrated into a low pressure drum or deaerator column. Gas heater condensate circuit can comprise a water-water heat exchanger for heating piping network water or provided

In 2009, it was signed the license agreement with one of the leading HRSG suppliers in Europe NEM Energy b.v. company (Netherlands). Several HRSGs were produced on the NEM Energy b.v. engineering base for with a separated circuit of a gas heater for the network water. To reach higher parameters for steam capacity and steam temperature HRSGs can be eqiupped with post injections. HRSGs can be eqiupped with a bypass system (with a separate bypass fume stack or a joint fume stack) for the gas turbine operation when the boiler is shutdown. Heating surfaces of HRSG can be supplied for installation as separate sections or modules, including sections of heating surfaces with pipelines, suspensions, beams and fl ooring with heat insulation.

Russian thermal power plants: Novomoskovskaya GRES, Yuzhnouralskaya GRES-2, Nizhnevartovskaya GRES, Verkhnetagilskaya GRES.

## Advantages of HRSGs based on NEM Energy b.v. Engineering:

• <sub>Minimum</sub> <sub>dimensions</sub> <sub>of</sub> <sub>HRSG;</sub>

• <sub>Guaranteed</sub> <sub>parameters</sub> <sub>proved</sub> <sub>by</sub> <sub>tests;</sub>

Ease of assembling of heating surfaces using special assembling devices.

## Technical Parameters

<table><tr><td rowspan="2">Type of HRSG</td><td rowspan="2">Type of gas turbine, power, MW,</td><td colspan="3">Steam parameters at HRSG outlet</td></tr><tr><td>D, t/h</td><td>P, bar</td><td>T,℃</td></tr><tr><td>P-88</td><td>GTE-110110 MW</td><td>155/35</td><td>72/7.0</td><td>501/231</td></tr><tr><td>P-96</td><td>GTE-160160 MW</td><td>232/45</td><td>77.5/5.0</td><td>510/226</td></tr><tr><td>P-131</td><td>PG-6581 GE 45 MW</td><td>58/12</td><td>74/7.0</td><td>525/209</td></tr><tr><td>P-132</td><td>SGT5-4000F 280 MW</td><td>258.4/309.3/35.1</td><td>149.9/31.4/4.4</td><td>540/534.6/263.2</td></tr><tr><td>P-133</td><td>GT-26 Alstom 288 MW</td><td>315/357/30.9</td><td>139/30/4.7</td><td>567/566/284</td></tr><tr><td>P-140</td><td>SGT5-4000F 280 MW</td><td>259/311/42</td><td>119/29/4.3</td><td>543/542/234</td></tr><tr><td>P-142</td><td>PG9171E 125 MW</td><td>186/39</td><td>74.9/7.25</td><td>515/229</td></tr><tr><td>P-143</td><td>PG9351FA 260 MW</td><td>277/302/44.1</td><td>110/22/3.9</td><td>566/565/300</td></tr><tr><td>P-146</td><td>SGT5-4000F 280 MW</td><td>288.6/317.1/42</td><td>138/32.5/5.2</td><td>566/568/244</td></tr></table>

## Key References:

• <sub>325</sub> <sub>MW</sub> <sub>CCGT,</sub> <sub>Ivanovskiye</sub> <sub>CCGTs,</sub> <sub>Ivanovo;</sub>

• <sub>450</sub> <sub>MW</sub> <sub>CCGT,</sub> <sub>Kaliningradskaya</sub> <sub>CHPP-2,</sub> <sub>Kaliningrad;</sub>

• <sub>60</sub> <sub>MW</sub> <sub>CCGT,</sub> <sub>Noyabrskaya</sub> <sub>CCGT,</sub> <sub>Noyabrsk;</sub>

• <sub>800</sub> <sub>MW</sub> <sub>CCGT,</sub> <sub>Kirishskaya</sub> <sub>GRES,</sub> <sub>Kirishi;</sub>

• <sub>420</sub> <sub>MW</sub> <sub>CCGT,</sub> <sub>CHPP-26,</sub> <sub>Moscow;</sub>

420 MW CCGT, Yuzhnouralskaya GRES-2 power unit   
1 and 2, Yuzhnouralsk;

• 190 MW CCGT, Novomoskovskaya GRES, Novomoskovsk;

• <sub>400</sub> <sub>MW</sub> <sub>CCGT,</sub> <sub>Nizhnevartovskaya</sub> <sub>GRES,</sub> Nizhnevartovsk;

• <sub>420</sub> <sub>MW</sub> <sub>CCGT,</sub> <sub>Verkhnetagilskaya</sub> <sub>GRES,</sub> <sub>Verkhny</sub> <sub>Tagil.</sub>

# LOW PRESSURE HEATERS (LPH)

Enterprises of the Holding manufacture LPHs for turbine groups of power units. Standard range of new upgraded units for thermal power plants allows to eliminate the constructive weaknesses used nowadays at TPPs.

LPHs are intended to heat main condensate by the takenof steam in the system for low pressure regeneration of steam turbine group.

![](images/7b389e2af51628455d77ba33d738c8dc89c187ffcc9956d1ad14e77839bd2eca.jpg)  
Low pressure heaters manufactured by ZiO-Podolsk are successfully operated at CHPP-27 of Mosenergo as a part of PT-80 (Russian: ПТ-80) turbine group.

<table><tr><td>Key characteristics of LPH</td><td>LPH-2</td><td>LPH-3</td><td>LPH-4</td></tr><tr><td>Nominal flow rate of main condensate, t/h</td><td>464</td><td>565</td><td>565</td></tr><tr><td>Main condensate pressure, kgf/cm² (MPa)</td><td>14 (1.373)</td><td>13.0 (1.275)</td><td>12.0 (1.177)</td></tr><tr><td>Design pressure of main condensate, kgf/cm² (MPa)</td><td>20.0 (1.96)</td><td></td><td></td></tr><tr><td>Inlet temperature of main condensate, °C</td><td>57</td><td>99</td><td>128</td></tr><tr><td>Outlet temperature of main condensate, °C</td><td>95</td><td>127</td><td>157.6</td></tr><tr><td>Design temperature of main condensate, °C</td><td>100</td><td>130</td><td>160</td></tr><tr><td>Flow rate of heating steam, t/h</td><td>31.3</td><td>25.5</td><td>28.4</td></tr><tr><td>Pressure of heating steam (g), kgf/cm² (MPa)</td><td>0.98 (0.096)</td><td>2.8 (0.275)</td><td>6.22 (0.605)</td></tr><tr><td>Design temperature of heating steam, °C</td><td>170</td><td>260</td><td>380</td></tr><tr><td>Outlet temperature of heating steam, °C</td><td>166</td><td>253</td><td>364</td></tr><tr><td>Underheating of main condensate at nominal flow rate of main condensate (max), C</td><td>3</td><td>2.9</td><td>1.8</td></tr><tr><td>Hydraulic resistance of piping system, kgf/cm² (MPa)</td><td>0.51 (0.05)</td><td>0.92 (0.09)</td><td>0.91 (0.089)</td></tr><tr><td>Full area of heat exchange, design, m²</td><td>362</td><td>366</td><td>362</td></tr><tr><td>Heater weight, kg: at installation</td><td>10,906</td><td>11,633</td><td>11,135</td></tr><tr><td>at hydraulic test</td><td>18,386</td><td>19,863</td><td>18,615</td></tr></table>

# DISTRICT WATER HEATERS

The latest R&D of AEM allowed to retrofi t district water heaters installed earlier in terms of heat-exchanging media fl ow improvement, providing directional condensate draining from heating surface, enhanced efi ciency of non-condensing gases outlet, retrofi t of distribution chamber, standardization of main assemblies and parts.

District heaters are installed in heat supply system and designed for district water heating at thermal power plants by steam from turbines’ taking-of s.

![](images/d02db2ad44a60173aacbb9f08be7b9eb76dcf31eeb4284993a227f3eebca30c3.jpg)

<table><tr><td>Key characteristics of district water heaters (Russian: ∏CB)</td><td>NWH-530-0.29-2.25</td><td>NWH-530-1.37-2.25</td></tr><tr><td>Heat-exchanging area, design, m²</td><td>530/644</td><td></td></tr><tr><td>Operation pressure in piping system (g), kgf/cm² (MPa)</td><td>23 (2.25)</td><td></td></tr><tr><td>Operation pressure in casing (g), kgf/cm² (MPa)</td><td>3,0 (0.29)</td><td>14,0 (1.37)</td></tr><tr><td>Network water temperature, °C:</td><td></td><td></td></tr><tr><td>Inlet</td><td>120</td><td>70</td></tr><tr><td>Outlet</td><td>150</td><td>110</td></tr><tr><td>Maximum temperature of heating steam, °C</td><td>400</td><td></td></tr><tr><td>Nominal mass flow rate of network water, t/h</td><td>1130</td><td></td></tr><tr><td>Hydraulic resistance of piping system at nominal flow rate of network water, kgf/cm² (MPa)</td><td>0.54 (0.053)</td><td>0.65 (0.064)</td></tr><tr><td>Nominal heat flow, MW (kcal/h)</td><td>66.0 (56.7)</td><td>53.4 (45.9)</td></tr><tr><td>Complete heating of network water, C</td><td>12.7</td><td>8.7</td></tr><tr><td>Heating steam flow rate, t/h</td><td>110</td><td>94</td></tr><tr><td>Dry weight of the unit, t</td><td>18.3</td><td>19.9</td></tr><tr><td>Unit weight completely filled with water, t</td><td>30.3</td><td>31.9</td></tr></table>

# PUMPING EQUIPMENT

AEM companies manufacture a wide range of pumps of dif erent design, calculation parameters and materials.

![](images/1882945e2df91a7bb0c36c70519b6d3409f5ee01c369ddeae1379ff35de7ad30.jpg)  
Multi-stage centrifugal horizontal sectional and double casing pumps

![](images/4ad916ce55f605ff0f0fb4b4c57c63261d91a9364e75e8a483224812f6570f0d.jpg)  
Horizontal centrifugal with double inlet impeller with a horizontal and a vertical split

![](images/2ebd160a7c3c188360960751e80476ea8d89506e1a28f0cda767c06a9dce7baa.jpg)  
Horizontal and vertical centrifugal single-stage with a scroll case pumps

![](images/5a10204095c7dbc4a08db28c3585fd4c9223695f4d2d0a3acd228dbd8865a142.jpg)  
Axial and angular-fl ow single-stage semi-submersible with regulation system of hydraulic characteristics pumps

![](images/327c1cc595461e9181c441da6f2e12e6626f945a8e8756a0185defaf7c19cee4.jpg)  
Single and multiple stage centrifugal vertical semi-submersible

![](images/606d7695c2b116e80d49989c72da6be2f7fb985ab120a7f4798fcb210cef1bd9.jpg)

# VESSEL EQUIPMENT

Applied in processing units at thermal power plants, gas, oil, oil-refi ning, petrochemical and other industries, including infl ammable and hazardous media. Large size items are transported dismantled and mounted at the site.

![](images/47822d85cbb0583c5a060f8f7e8d1ed0619f9d0d7dc0efb9f4f8db8690608cdd.jpg)  
Deaerator

![](images/c81d9d1ac5f05fdf7a381974e0ffab0a3504bb516aba3f45d8fc5e85159f788f.jpg)  
Gas condenser

![](images/ca4bb3ddd067c888b123470911611d94ec3726fcd9ef61ec29f2741445f632f2.jpg)  
Steam separation unit for Verkhne-Mutnovskaya Geothermal Power Plant

## Types of Vessel Equipment:

• <sub>Vessels</sub> <sub>operated</sub> <sub>under</sub> <sub>pressure</sub> <sub>up</sub> <sub>to</sub> <sub>70</sub> <sub>MPa,</sub> to 1,000 m³;

• <sub>Horizontal</sub> <sub>and</sub> <sub>vertical</sub> <sub>vessels</sub> <sub>for</sub> <sub>liquid</sub> <sub>media;</sub>

• <sub>Vertical</sub> <sub>vessels</sub> <sub>for</sub> <sub>air</sub> <sub>and</sub> <sub>gases;</sub>

• <sub>Evaporators.</sub>

## Technical Parameters

<table><tr><td>Volume, m³</td><td>to 300</td></tr><tr><td>Diameter, mm</td><td>to 3800</td></tr><tr><td>Nominal pressure, MPa to 70</td><td></td></tr><tr><td>Temperature, °C</td><td>from -70 to +950</td></tr><tr><td>Material:</td><td>carbon and stainless steel, iron-nickel alloys</td></tr></table>

## References:

• <sub>Vessels</sub> <sub>for</sub> <sub>catalysts</sub> <sub>producing</sub> <sub>at</sub> <sub>Ishimbaysky</sub> <sub>Oil</sub> Refi nery Plant (JGC Corporation, Japan);

• <sub>Vessels</sub> <sub>for</sub> <sub>hydrocyanic</sub> <sub>acid</sub> <sub>and</sub> <sub>acrolein</sub> producing (ERA, Mexico);

Sewage water treatment plant for Nevinnomyssk (TEC, Japan);

Steam collectors, separators, receivers, fi lters and other equipment for vacuum residue plant (LUKOIL-Permnefteorgsintez LLC);

Degasifi er, acid settler tanks, separators, economizers, tanks for alkylation for Omsk Oil Refi nery (TECHNIP, France);

• <sub>Vessels</sub> <sub>for</sub> <sub>sulfuric</sub> <sub>acid</sub> <sub>producing</sub> <sub>plant</sub> <sub>(LUKOIL-</sub> Permnefteorgsintez LLC);

Separators for arrangement of Verkhne-Salymskoye Oil and Gas Deposit (Salym Petroleum Development, subsidiary company of SHELL).

# AIR HEATERS AND CALORIFIERS

## Air Heaters

ZiO-Podolsk produces all types of tubular air heaters used in steam and water heating boilers. The air heater is installed in a convective gas duct of the boiler with the aim to heat the air driven to furnace to increase the efi ciency of fuels combustion and to coal milling devices using exhaust gases heat. Air heaters are manufactured with dif erent cubes design and arrangement depending on combusting fuel and boiler steam generating capacity.

## Calorifi ers

Sections of steam SP type calorifi ers made of steel tubes with welded spiral-bend fi nning are designed for heating of blowdown air in solid, liquid and gaseous fuel fi red boilers as well as for ventilation systems and air heating of power plants, public buildings and industrial enterprises.

Depending on the heat rate and draft loss sections of steam calorifi ers of SP type are divided into three-row and four-row as well as they have dif erent height of heating fi nned tubes.

Heat-release element is made of steel tube with welded spiral fi ns.

Main Technical Characteristics of Steam Calorifi ers:

• <sub>Inlet</sub> <sub>air</sub> <sub>temperature</sub> <sub>—</sub> <sub>minus</sub> <sub>15</sub> <sub>°С;</sub>

• <sub>Inlet</sub> <sub>heating</sub> <sub>steam</sub> <sub>temperature</sub> <sub>—</sub> <sub>up</sub> <sub>to</sub> <sub>250</sub> <sub>°С;</sub>

![](images/29f69ba8a145f3a3e4a917c1a521b1ebecd23cb14ef0a62da187ed663969f34c.jpg)

![](images/5e276689c88a400bb350a223bcde84c3543e8715e606821d0a04f9f6dad4e2a6.jpg)

• <sub>Air</sub> <sub>mass</sub> <sub>fl</sub> <sub>ow</sub> <sub>rate</sub> <sub>in</sub> <sub>incoming</sub> <sub>fl</sub> <sub>ow</sub> <sub>—</sub> <sub>9.4</sub> <sub>kg/m</sub>2<sub>s;</sub>

• <sub>Inlet</sub> <sub>steam</sub> <sub>pressure</sub> <sub>—</sub> <sub>up</sub> <sub>to</sub> <sub>16</sub> <sub>kg/cm</sub>2<sub>.</sub>

# VALVES OF GAS, AIR AND PULVERIZED-COAL DUCTWORK

Valves are designed for pulverized and air-gas ductworks of boiler units of TPP gas ducts with maximum ambient temperature 425°С or up to 550°С, pressure up to 20 kPa and coal concentration up to 100 g/nm<sup>3</sup>.

The valves are manufactured with round and rectangular cross-sections. Valves of a round crosssection have one shutof or control element made as a gate valve. Valves of a rectangular cross-section have one, two, three or more gate valves with parallel rotation with pair-wise counter gate valves rotation providing a wide range of fl ow rate parameters and eliminating non-symmetric fl ow defl ection. Besides that, there are valves with reciprocating movement of the gate valve.

Isolating valves serves to shutdown separate areas of DGAD during repair work performance.

Special-purpos valves and valves of other type sizes and parameters are manufactured at operating temperature up to 700 °С.

Specifi ed service life before overhaul is 35,000 hours provided compliance with rules of operation. Mean time to failure is not less than 4,000 hours. Average lifetime is 30 years except for gate valves operating in dust gas fl ows.

<table><tr><td>Description</td><td>Sizes, mm</td><td>Body passage area, m²</td></tr><tr><td>Shutoff and control round valves</td><td>from 100 to 2,000 (diameter)</td><td>0.01 to 3.1</td></tr><tr><td>Shutoff and control rectangular valves</td><td>from 300×500 to 5,500×2,500</td><td>0.01 to 13.75</td></tr><tr><td>Rectangular special control valves</td><td>From 800×400 to 1,600×3,000</td><td>0.32 to 3.8</td></tr><tr><td>Control and isolating valves</td><td>from 1,000×1,000 to 2,206×2,206</td><td>1 to 4.9</td></tr><tr><td>Isolating valve of CCGT</td><td>from 1,800×1,800 to 11,680×6,000, from 4,600 to 6,850 (diameter)</td><td>3.24 to 70</td></tr></table>

![](images/749224b84e0ad4fb0c7a79dd8f15c20676489929cbc7b9e9ce2c2cc4b05c0331.jpg)

![](images/f6f47c91e3d04aef59f6b5b4bf19ca3b229c812eed3e0b299f2c107197c822ea.jpg)

## FILTERS

## Trap Filters

Trap fi lters are produced with diameter from 0.2 to 0.8 m. Depending on the required. parameters mesh elements and fi ltering cartridges are used as fi ltering elements.

Wire fi ltering cartridges ensure reliable interception of particles with a size of over 0.1 mm. The cartridges are made of stainless steel.

Depending on assignment, casings of entrainment fi lters are produced of stainless or carbon steel, both with vertical and horizontal designs.

## Ion-Exchange Filters

The range of mixed-bed ion-exchange fi lters, regenerators varies in terms of diameter from 1 to 3.4 m. Depending on the processing media and regeneration solution, casings are made both of stainless steel and carbon steel with corrosion-proof coating.

Two types of fi ltering elements are used:

Stainless steel caps with slots from 0.4 to 0.1 mm proved their efi ciency and reliability during operation at dif erent sites;

Plastic caps are applied in corrosive media, where stainless steel caps cannot be used.

Upper and middle collection-distributive devices are made of stainless steel and polymeric materials.

![](images/f47c2f62534e110e27581c3bdeed10de77dced993d20e278536e5ff0fbbccb12.jpg)

![](images/7f8e50dbf854a5127235bc57ffd9fb03728fb2c508add6eef4c56344c796dae4.jpg)

Design feature of some devices results to be a use of a lower collection-distributive device, “false bottom” for carbon anticorrosive coated steel fi lters.

## BURNERS

AEM has a great experience in production of high quality and reliable burner equipment for steam and water heating boilers.

Depending on design, the burners are subdivided into vortex and direct fl ow (dust-coal, dust-gas). AEM of ers burners that ensure combustion of dif erent kinds of fuel,

![](images/02b7831ff6cbd46c63bed3fb2d52e0a010c1266ef105c3ed68a87761333828b4.jpg)

## STEAM SILENCERS

Silencers are designed to lower the sound power of the steam fl ow vented into the atmosphere. The processing mediais water steam with temperature not exceeding Тoper. = 570 °С, pressure not exceeding Рoper. = 25 MPa. The medium fl ow rate is from 20 to 350 t/h.

Design of the noise silencer provides reduction of the noise level to norms specifi ed by SN2.2.4/2.1.8.562-96 or customer requirements. Design of the noise silencer is developed individually on the base of a technical assignment or data specifi ed by the customer in data sheet.

both separately and in mixture (gas, fuel oil, coal). The capacity of burners is from 5 to 80 MW.

On shipment to customer, if required, the burner can be additionally completed with with ignitor, fl are sensor and other required equipment.

![](images/90bc9dcf6e8629eb8a9ea235aa28e0aa9ba5d30e2e5c034fcfdd845480b1403f.jpg)

![](images/d55e3ca12b97372d47cd69847bf3cf75db93c70323a17ba4b8419b86ec001d05.jpg)

# SHUTOFF AND CONTROL VALVES

Pipeline valves by Czech company Arako are used in thermal and nuclear power, oil and gas industries. The valves are manufactured with respect to the standards ČSN, DIN, EN, ANSI. The product range includes carbon, alloyed and stainless steel valves. Product range of the company includes gate valves, shutof , control and check valves, bellows valves, quick-action valves, drain and blow down valves, gate valves, check valves, ball valves and fi lters.

<table><tr><td rowspan=1 colspan=1>王</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>夏</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>夏</td></tr><tr><td rowspan=1 colspan=2>Gate valves</td><td rowspan=1 colspan=2>Shutoff and control valves</td><td rowspan=1 colspan=1>Drain and blowdown valves</td></tr></table>

Characteristics of Valves Produced for Power Engineering, Chemical, Petrochemical and Gas Industries
<table><tr><td></td><td>High pressure gate valves</td><td>Low pressure gate valves</td><td>Shutoff and control valves and bellows valves</td><td>High pressure shutoff valves</td></tr><tr><td>Nominal diameter</td><td>50-350</td><td>40-500</td><td>15-200</td><td>10-150</td></tr><tr><td>Nominal pressure</td><td>160-500</td><td>10(6)-100</td><td>10-40</td><td>63-630</td></tr><tr><td>Minimum operation temperature, °C</td><td>-50</td><td>-105</td><td>(-196)-50</td><td>-196</td></tr><tr><td>Maximum operation temperature, °C</td><td>600</td><td>540</td><td>400</td><td>650</td></tr><tr><td>Application</td><td>Gas, water etc.</td><td>Gas, steam, water, oil, oil products, corrosive and non-corrosive media etc.</td><td>Gas, steam, water, oil, oil products, corrosive and non-corrosive media etc.</td><td>Gas, steam, water, oil, oil products, corrosive and non-corrosive media etc.</td></tr></table>

## References:

• <sub>E-ON,</sub> <sub>Germany;</sub>

• <sub>Siemens</sub> <sub>AG,</sub> <sub>Germany;</sub>

• <sub>ČEZ</sub> <sub>a.s.,</sub> <sub>Czech</sub> <sub>Republic;</sub>

• <sub>Skoda,</sub> <sub>Czech</sub> <sub>Republic;</sub>

• <sub>ALSTOM,</sub> <sub>France;</sub>

• <sub>AREVA,</sub> <sub>France;</sub>

• <sub>ENEL,</sub> <sub>Italy;</sub>

• <sub>Slovenske</sub> <sub>Elektrarne,</sub> <sub>Slovenia;</sub>

• <sub>Thyssen</sub> <sub>Krupp,</sub> <sub>Germany.</sub>

• <sub>Mažeikiu</sub> <sub>Nafta,</sub> <sub>Latvia;</sub>

![](images/ed9238377a16b20e687122e5d7ca4cc0f8e61123c10da4281ac0f0ff0a496758.jpg)

![](images/77682d9cce337c5c439653412ed21194f57b2ec19297b3bbba0fd13e23e9e03d.jpg)

CE

<table><tr><td rowspan=1 colspan=1><img src="images/4d1bd76d99206e2ef7889ff478680c23a507a17c379132f8b2709728877b3424.jpg"/></td><td rowspan=1 colspan=1><img src="images/780a770897f2d80b5ae598cab5638f8edf190f79882a899dbfecfa266834c289.jpg"/></td><td rowspan=1 colspan=1><img src="images/bbeacdf2eb47f83620d105be7698390ab0c992257e0836601d1cff372732cfd0.jpg"/></td><td rowspan=1 colspan=1><img src="images/288ad1ab2a96da368006eefc0dd07af6e62990ea172213d194b71ceb757e4db0.jpg"/></td><td rowspan=1 colspan=1><img src="images/358c1de1573f65b28d27c80f7749c322cde58f517609bf904eded47f5e753065.jpg"/></td></tr><tr><td rowspan=1 colspan=2>Check valves</td><td rowspan=1 colspan=1>Check gate valves</td><td rowspan=1 colspan=1>Ball valves</td><td rowspan=1 colspan=1>Filters</td></tr></table>

## Characteristics of the Valves Produced for Power Engineering, Chemical, Petrochemical and Gas Industries (continued)

<table><tr><td></td><td>Drain and blow down valves</td><td>Check valves</td><td>Check gate valves</td><td>Ball valves</td><td>Filters</td></tr><tr><td>Nominal diameter</td><td>10-50</td><td>10-200</td><td>50-400</td><td>10-150</td><td>10-150</td></tr><tr><td>Nominal pressure</td><td>63-500</td><td>10-630</td><td>10-630</td><td></td><td>10-160</td></tr><tr><td>Minimum operation temperature, °C</td><td>(-196)-10</td><td>-196</td><td>-105</td><td>-196</td><td>-196</td></tr><tr><td>Maximum operation temperature, °C</td><td>580</td><td>600</td><td>540</td><td>200</td><td>550</td></tr><tr><td>Application</td><td>Steam, waste water</td><td>Gas, steam, water, oil, oil products, corrosive and non- corrosive media etc.</td><td>Gas, steam, water, oil, oil products, corrosive and non- corrosive media etc.</td><td>Gas, steam, water, oil, oil products, corrosive and non- corrosive media etc.</td><td>Gas, steam, water, oil, oil products, corrosive and non- corrosive media etc.</td></tr></table>

![](images/bd492e07e2a5ced1d144bd22ab50b2a374b21716b55635796a7c4c99aae4806d.jpg)

![](images/a55f54a11880e51afec65cad10ed3ff84a89c1afbd269d262861303923aaecaa.jpg)

# WATER TREATMENT AND WATER PURIFICATION

AEM of ers a wide range of unique modern technologies of water treatment, purifi cation and methods of desalination for the companies of thermal power, gas and petrochemical and other industries.

![](images/fecef7cb30552daff3aebc0dfff649794ef17565e5cf802915006825de0a5623.jpg)

## Specialization as per Water Treatment Technologies

## VNIIAM

## Ion-Exchanging Technologies:

• Counter fl ow and parallel fl ow ionization of water in fi lters.

## Diaphragm Technologies:

• <sub>Reverse</sub> <sub>osmosis;</sub>

• <sub>Nanofi</sub> <sub>ltration;</sub>

• <sub>Ultrafi</sub> <sub>ltration;</sub>

• <sub>Electric</sub> <sub>deionization.</sub>

## Reference Deliveries:

Tatneft OJSC. In 2010, turn-key delivery of automated water treatment plant for fi ne desalination of surface water and purifi cation of fuel oil contaminated condensates of petrochemical facilities of Taneko JSC;

Taif OJSC. Implementation in 2014–2018, development and stage by-stage delivery of purifi cation system for oil containing condensates to Nizhnekamskneftekhim OJSC.

![](images/f4cc125e25cb464b38948c1066a3948f73bebce03dd6fc15068cf927dd229703.jpg)

![](images/38ab327de81f96d7f31eddc858c5605dbfacdee27091ec178e972c2993b7951b.jpg)

![](images/3a72cef57c0a5048f00701ead9571b3db8137c3d0354ba525bacb4dd2182ae28.jpg)

![](images/b9121b2209b651023c1347ef0974edf1d9d704e2e57f8e8d21f377d6aac04132.jpg)

![](images/ce7c29fbe1fb05c2911992438cb19c2e6da99cb90eed0e8c9b79898e02dcba51.jpg)

SVERDNIIKHIMMASH

## Thermal Technologies:

• <sub>Evaporators;</sub>

• <sub>Evaporator</sub> <sub>vessels;</sub>

• <sub>Distilling</sub> <sub>desalination</sub> <sub>units.</sub>

![](images/1e0a43fa7c5ae6d0c7397255a3a45c3f9a6289fcd2043e242e9222301a836f39.jpg)

In 1989, National Research and Design Institute for Atomic Power Engineering (OJSC VNIIAM) developed the fi rst in the USSR industrial reverse osmosis plant ROP-50 (Russian: УОО-50) with capacity of 50m³/h for Zuyevskaya Experimental Combined Heat and Power Plant.

## Products and Technologies:

• <sub>Purifi</sub> <sub>cation</sub> <sub>of</sub> <sub>associated</sub> <sub>formation</sub> <sub>waters</sub> (ǽ ≤ 1.0 μS/cm);

• <sub>Production</sub> <sub>of</sub> <sub>desalinated</sub> <sub>water</sub> <sub>for</sub> <sub>power</sub> <sub>plants</sub> <sub>in</sub> <sub>oil</sub> and gas industry (ǽ ≤ 0.2 μS/cm);

• <sub>Water</sub> <sub>desalination</sub> <sub>systems,</sub> <sub>including</sub> <sub>potable</sub> <sub>water</sub> supply (SanPiN);

• <sub>Trapping</sub> <sub>radioactive</sub> <sub>elements.</sub>

![](images/78accefa2065df5719e0dd426413d204ce974aca31236f2336cd998919eb81ff.jpg)

1 Lukoil-Komi CJSC. Formation waters purifi cation with capacity 700 m³/h, ǽ ≤ 1.0 μS

2 Sibur-Khimprom CJSC. Water treatment for desalination, capacity 700 m³/m, ǽ ≤ 0.2 μS

3 Nizhnekamskneftekhim OJSC. Purifi cation system for oil containing condensates, capacity 800 m³/h, ТОС ≤ 200 μg /dm³

4 Tatneft OJSC. Petrochemical enterprises of Taneko OJSC. Water treatment for fi ne desalination of water, capacity 1,000 m³/h

# CONSTRUCTION AND ERECTION WORKS

AEM performs construction & erection and repair works at enterprises of power and oil and gas industries. Over the period of its activity the company proved itself as a reliable partner, stable in performing its liabilities to customers.

## Main Types of the Performed Works:

• <sub>General</sub> <sub>contractor</sub> <sub>functions;</sub>

• <sub>Construction,</sub> <sub>reconstruction</sub> <sub>and</sub> <sub>overhaul</sub> <sub>of</sub> process pipelines;

• <sub>Arrangement</sub> <sub>of</sub> <sub>clusters</sub> <sub>of</sub> <sub>wells</sub> <sub>after</sub> <sub>drilling,</sub> reconstruction of clusters of wells;

• <sub>Construction,</sub> <sub>reconstruction</sub> <sub>and</sub> <sub>overhaul</sub> <sub>of</sub> automated process control system;

• <sub>Installation</sub> <sub>of</sub> <sub>production</sub> <sub>equipment;</sub>

• <sub>Installation</sub> <sub>of</sub> <sub>utility</sub> <sub>systems</sub> <sub>and</sub> <sub>communications;</sub>

• <sub>Instrumentation</sub> <sub>for</sub> <sub>the</sub> <sub>sites</sub> <sub>of</sub> <sub>treatment</sub> <sub>and</sub> <sub>oil</sub> and gas extraction;

• <sub>Process</sub> <sub>equipment</sub> <sub>installation.</sub>

Construction and erection companies of AEM are equipped with all necessary production means, advanced equipment and technologies, including:

• <sub>Lifting</sub> <sub>and</sub> <sub>transport</sub> <sub>means;</sub>

Metal cutting, grinding and sheet bending machines;

• <sub>Press</sub> <sub>and</sub> <sub>welding</sub> <sub>equipment;</sub>

• <sub>Tooling</sub> <sub>and</sub> <sub>accessories.</sub>

## Key Projects:

• <sub>Reftinskaya</sub> <sub>GRES;</sub>

• <sub>Troitskaya</sub> <sub>GRES;</sub>

• <sub>Sredneuralskaya</sub> <sub>GRES;</sub>

• <sub>Ikryanskoye</sub> <sub>gold</sub> <sub>deposit;</sub>

• <sub>Urnenskoye</sub> <sub>deposit;</sub>

• <sub>Ust-Tegusskoye</sub> <sub>deposit;</sub>

• <sub>Processing</sub> <sub>enterprises.</sub>

![](images/bfe1fec3ff8da9f89bacb8783ae2d27d643c536996cf76ad438a9ee7f0e5353d.jpg)  
Construction and installation works. Troitskaya GRES

![](images/9dae3cd31b241577d21230f552e92af26215aad780ef0e6440833f9bab459d2b.jpg)  
Construction and installation works. Reftinskaya GRES

![](images/3b9f7f8d81f75a45db4d439713c4660575bbf1374aadd2c47406a5f411d40584.jpg)

![](images/45a85078e8f611183990bfc9a473dca3a66b554ad712b8b7fa0ddf044ff4351a.jpg)

# COMPANIES OF AEM

![](images/6f89da1cc3a12099151db0d7360b1e8b01683b6c240d8d7af684466a048cbafa.jpg)

![](images/d9ba683d0820c2eed2a75e7b3d17d0458bc0b8efe027414616a1e0c8d38d0f8c.jpg)

## Moscow, Russia1

Central Research Institute for Engineering Technology OJSC

Tel.: +7-495-675-83-02 Web-site: www.cniitmash.ru E-mail: cniitmash@cniitmash.ru

Institute OJSC Tel.: +7-495-988-80-50 Web-site: www.oaogspi.ru E-mail: info@oaogspi.ru

All-Russian Research and Design Institute for Atomic Power Engineering OJSC

Tel.: +7-495-748-86-54 Web-site: www.vniiam.ru E-mail: mail@vniiam.ru

CJSC Tel.: +7-495-540-10-86 Web-site: www.atom-tm.ru E-mail: atom@dol.ru

SNIIP OJSC Tel.: +7-499-198-97-64 Web-site: www.sniip.ru E-mail: info@sniip.ru

EMKO LLC Tel.: +7-495-789-97-15 E-mail: emko@aem-group.ru

Neftegazspetsstroy LLC Tel.: +7-495-971-98-91 Web-site: www.ngss-ltd.ru E-mail: info@ngss-ltd.ru

Technical Problems OJSC Tel.: +7-49621-6-27-89 Web-site: www.iftp.ru E-mail: iftp@dubna.ru

![](images/72b445d154c70b663a88edfee5311c8275cc63f930097c33447f073ed5a25ef5.jpg)

## Kramatorsk, Ukraine

Energomashspetsstal PJSC Tel.: +38-062-646-01-32 Web-site: www.emss.ua

## Podolsk, Russia3

Experimental Design Bureau OKB Gidropress JSC Tel.: +7-495-502-79-10 Web-site: www.gidropress.podolsk.ru E-mail: grpress@grpress.podolsk.ru

ZiO-Podolsk OJSC Tel.: +7-495-747-10-25 Web-site: www.aozio.ru E-mail: kd@eatom.ru

## ZIOMAR Engineering

Company OJSC Tel.: +7-495-747-10-17 Web-site: www.aozio.ru E-mail: kd@eatom.ru

![](images/22c7ca8c4e9be3bacaf95830d5579e624d8ec0d720e27ef6834231fefeb5eae3.jpg)

## Nizhniy Novgorod, Russia4

Joint Stock Company “Afrikantov Experimental Design Bureau for

Mechanical Engineering” Tel.: +7-831-241-87-72 Web-site: www.okbm.nnov.ru E-mail: okbm@okbm.nnov.ru

## Nizhnyaya Tura, Russia5

Venta OJSC Tel.: +7-343-422-30-20 Web-site: www.venta-nt.ru E-mail: venta@venta-nt.ru

![](images/9f1fb15dd06f0845d89b2b04a7468135bed421e0a032a6d44720365d4d67581e.jpg)

## St. Petersburg, Russia6

Central Mechanical Engineering Design Bureau

OJSC Tel.: +7-812-676-63-63 Web-site: www.ckbm.ru E-mail: postbox@ckbm.ru

AEM-technology OJSC Tel./fax: +7-812-457-05-88 Web-site: www.aemtech.ru E-mail: info@aemt.su

Alstom Atomenergomash LLC Tel.: +7-812-635-81-19 Web-site: www.alstom.com/russia/ru

VetroOGK CJSC Tel.: +7-812-386-00-31 Web-site: www.vetroogk.ru

![](images/52cea5d58f9d12f5869004d970ef895a752f08a98759767ed1cc5bc750cca742.jpg)

## Yekaterinburg, Russia

SverdNIIKhimmash OJSC Tel.: +7-343-263-90-91 Web-site: www.sverd.ru E-mail: niihm@ural.ru

![](images/f4a176240e95f4800ff7d4d03ba99a9b6779463068b7f3e9c53ff0aff13cbe70.jpg)

## 8 Petrozavodsk, Russia

AEM-technologies OJSC

subsidiary Tel.: +7-814-271-69-20 Web-site: www.pzm.su E-mail: info@pzm.su

## 9 Opava, the Czech Republic

ARAKO spol. s.r.o. Tel.: +420-553-694-111 Web-site: www.arako.cz E-mail: arako@arako.cz

## 10 Volgodonsk, Russia

AEM-technology ATOMMASH

OJSC subsidiary Tel.: +7-863-929-20-79 Web-site: www.atommash.ru E-mail: ofi ce@atommash.ru

## 11 Budapest, Hungary

Ganz EEM LLC Tel.: +36-1-872-58-00 Web-site: www.ganz-eem.com E-mail: info@ganz-eem.com

ATOMENERGOMASH JSC   
Nuclear and power engineering machine-building   
Address: Building 3, 28 Ozerkovskaya Naberezhnaya, Moscow, 115184   
Tel.: +7(495) 668-20-93   
Fax: +7(495) 668-20-95   
Web-site: www.aem-group.ru   
E-mail: aem@aem-group.ru